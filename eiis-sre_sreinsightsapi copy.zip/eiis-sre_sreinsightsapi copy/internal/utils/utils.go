package utils

import (
	"os"
)

func GetOptions(name, def string) string {
	if env := os.Getenv(name); env != "" {
		return env
	}
	return def
}
