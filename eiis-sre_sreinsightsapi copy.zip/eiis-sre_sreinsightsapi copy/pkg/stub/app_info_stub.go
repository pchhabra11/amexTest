package stub

import (
	"net/url"

	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
	"github.com/google/uuid"
)

type AppinfoRepositoryStub struct {
	appinfo []model.Appinfo
}

func (s AppinfoRepositoryStub) FindAll(params *url.Values) ([]model.Appinfo, error) {
	return s.appinfo, nil
}

func NewAppinfoRepositoryStub() AppinfoRepositoryStub {
	appinfo := []model.Appinfo{
		{App_id: uuid.New(), App_name: "EMN", App_type: "K8S", App_description: "ttesog app wpr"},
		{App_id: uuid.New(), App_name: "EMN", App_type: "VMS", App_description: "will check "},
	}
	return AppinfoRepositoryStub{appinfo}
}
