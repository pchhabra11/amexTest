package stub

import (
	"encoding/json"
	"io/ioutil"
	"log"

	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
)

type MetricReqRepositoryStub struct {
	metricReq model.MetricReq
}

func (s MetricReqRepositoryStub) GetMetricReq() (model.MetricReq, error) {
	return s.metricReq, nil
}

func NewMetricReqRepositoryStub() MetricReqRepositoryStub {

	content, err := ioutil.ReadFile("./pkg/jsondata/metric_table.json")

	if err != nil {
		log.Fatal("json file error", err)
	}

	var metricReq model.MetricReq
	errd := json.Unmarshal(content, &metricReq)

	if errd != nil {
		log.Fatal("json unmarshal error", errd)
	}

	return MetricReqRepositoryStub{metricReq}
}
