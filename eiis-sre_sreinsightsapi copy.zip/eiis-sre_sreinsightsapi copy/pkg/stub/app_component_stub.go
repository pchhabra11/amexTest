package stub

import (
	"encoding/json"
	"io/ioutil"
	"log"

	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
)

type AppComponentRepositoryStub struct {
	appinfo model.AppComponent
}

func (s AppComponentRepositoryStub) FindAllAppComp(level string) (model.AppComponent, error) {

	//var content []byte
	var content []byte
	var err error
	var payload model.AppComponent
	switch level {

	case "1":
		content, err = ioutil.ReadFile("./pkg/jsondata/app_component_details_level_1.json")

	case "2":
		content, err = ioutil.ReadFile("./pkg/jsondata/app_component_details_level_2.json")

	case "3":
		content, err = ioutil.ReadFile("./pkg/jsondata/app_component_details_level_3.json")

	case "4":
		content, err = ioutil.ReadFile("./pkg/jsondata/app_component_details_level_4.json")

	default:
		content, err = ioutil.ReadFile("./pkg/jsondata/app_component_details_level_0.json")

	}

	if err != nil {
		log.Fatal("json file error", err)
		return s.appinfo, err
	}
	errd := json.Unmarshal(content, &payload)

	if errd != nil {
		log.Fatal("json unmarshal error", errd)
	}

	return payload, nil

	//return s.appinfo, nil
}

func NewAppComponentRepositoryStubLevelOne() AppComponentRepositoryStub {
	//appinfo := Applist

	content, err := ioutil.ReadFile("./pkg/jsondata/app_component_details_level_0.json")

	if err != nil {
		log.Fatal("json file error", err)
	}

	var payload model.AppComponent
	errd := json.Unmarshal(content, &payload)

	if errd != nil {
		log.Fatal("json unmarshal error", errd)
	}

	return AppComponentRepositoryStub{payload}
}
