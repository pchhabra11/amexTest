package stub

import (
	"encoding/json"
	"io/ioutil"
	"log"

	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
)

type MetricBarColRepositoryStub struct {
	metricBarCol model.MetricBarCol
}

func (s MetricBarColRepositoryStub) GetMetricBarCol() (model.MetricBarCol, error) {
	return s.metricBarCol, nil
}

func NewMetricBarColRepositoryStub() MetricBarColRepositoryStub {

	content, err := ioutil.ReadFile("./pkg/jsondata/metric_space_column_bar.json")

	if err != nil {
		log.Fatal("json file error", err)
	}

	var metricBarCol model.MetricBarCol
	errd := json.Unmarshal(content, &metricBarCol)

	if errd != nil {
		log.Fatal("json unmarshal error", errd)
	}

	return MetricBarColRepositoryStub{metricBarCol}
}
