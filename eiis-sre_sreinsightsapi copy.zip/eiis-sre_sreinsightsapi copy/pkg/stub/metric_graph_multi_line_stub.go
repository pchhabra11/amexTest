package stub

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"

	"math/rand"

	"time"

	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
)

type MetricGraphMultiLineRepositoryStub struct {
	metricGraphMultiLine model.MetricGraphMultiLine
}

func (s MetricGraphMultiLineRepositoryStub) GetMetricGraphMultiLine() (model.MetricGraphMultiLine, error) {

	var ycord []model.MetricGraphMultiLineY
	var values model.MetricGraphMultiLineValue
	var metricGraphMultiLine model.MetricGraphMultiLine

	var epochtime = time.Now().Unix()

	var timeseries []int64

	for j := 1; j < 6; j++ {

		ycord = append(ycord, model.MetricGraphMultiLineY{
			Title: fmt.Sprintf("Pod %d", j),
		})

	}

	for i := 1; i < 12; i++ {

		timese := epochtime + int64(i*10)
		timeseries = append(timeseries, timese)

		for k := 0; k < 5; k++ {
			randNum := rand.Intn(99-1) + 1

			ycord[k].Value = append(ycord[k].Value, randNum)
		}

	}

	var intvetadta = []string{
		"5m",
		"1d",
		"1M",
	}

	values = model.MetricGraphMultiLineValue{
		Unit:            "mm",
		ReloadTime:      30,
		DefaultInterval: "5m",
		TimeStamp:       time.Now().Unix(),
		Intervals:       intvetadta,
		X:               timeseries,
		Y:               ycord,
		Request:         7,
	}

	metricGraphMultiLine = model.MetricGraphMultiLine{
		Type:  "multiLine",
		Title: "Title",
		Value: values,
	}

	return metricGraphMultiLine, nil
	//return s.metricGraphMultiLine, nil
}

func NewMetricGraphMultiLineRepositoryStub() MetricGraphMultiLineRepositoryStub {

	content, err := ioutil.ReadFile("./pkg/jsondata/metric_multi_line.json")

	if err != nil {
		log.Fatal("json file error", err)
	}

	var metricGraphMultiLine model.MetricGraphMultiLine
	errd := json.Unmarshal(content, &metricGraphMultiLine)

	if errd != nil {
		log.Fatal("json unmarshal error", errd)
	}

	return MetricGraphMultiLineRepositoryStub{metricGraphMultiLine}
}
