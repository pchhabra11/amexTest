package stub

import (
	"encoding/json"
	"io/ioutil"
	"log"
	"math/rand"
	"time"

	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
)

type MetricGraphSingleLineRepositoryStub struct {
	metricGraphSingleLine model.MetricGraphSingleLine
}

func (s MetricGraphSingleLineRepositoryStub) GetMetricGraphSingleLine() (model.MetricGraphSingleLine, error) {

	var ycord model.MetricGraphSingleLineY
	var values model.MetricGraphSingleLineValue
	var metricGraphSingleLine model.MetricGraphSingleLine

	var epochtime = time.Now().Unix()

	var timeseries []int64

	ycord = model.MetricGraphSingleLineY{
		Title: "Pod 1",
	}

	for i := 1; i < 12; i++ {

		timese := epochtime + int64(i*10)
		timeseries = append(timeseries, timese)

		randNum := rand.Intn(99-1) + 1

		ycord.Value = append(ycord.Value, randNum)

	}

	var intvetadta = []string{
		"5m",
		"1d",
		"1M",
	}

	values = model.MetricGraphSingleLineValue{
		Unit:            "mm",
		ReloadTime:      30,
		DefaultInterval: "5m",
		TimeStamp:       time.Now().Unix(),
		Intervals:       intvetadta,
		X:               timeseries,
		Y:               ycord,
		Request:         7,
	}

	metricGraphSingleLine = model.MetricGraphSingleLine{
		Type:  "multiLine",
		Title: "Title",
		Value: values,
	}

	return metricGraphSingleLine, nil

	//return s.metricGraphSingleLine, nil
}

func NewMetricGraphSingleLineRepositoryStub() MetricGraphSingleLineRepositoryStub {

	content, err := ioutil.ReadFile("./pkg/jsondata/metric_single_line.json")

	if err != nil {
		log.Fatal("json file error", err)
	}

	var metricGraphSingleLine model.MetricGraphSingleLine
	errd := json.Unmarshal(content, &metricGraphSingleLine)

	if errd != nil {
		log.Fatal("json unmarshal error", errd)
	}

	return MetricGraphSingleLineRepositoryStub{metricGraphSingleLine}
}
