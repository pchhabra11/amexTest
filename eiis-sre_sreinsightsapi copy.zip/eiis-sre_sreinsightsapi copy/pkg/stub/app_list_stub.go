package stub

import (
	"encoding/json"
	"io/ioutil"
	"log"

	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
)

type ApplistRepositoryStub struct {
	appinfo model.Applist
}

func (s ApplistRepositoryStub) FindAllComp() (model.Applist, error) {
	return s.appinfo, nil
}

func NewApplistRepositoryStub() ApplistRepositoryStub {
	//appinfo := Applist

	content, err := ioutil.ReadFile("./pkg/jsondata/app_list.json")

	if err != nil {
		log.Fatal("json file error", err)
	}

	var payload model.Applist
	errd := json.Unmarshal(content, &payload)

	if errd != nil {
		log.Fatal("json unmarshal error", errd)
	}

	return ApplistRepositoryStub{payload}
}
