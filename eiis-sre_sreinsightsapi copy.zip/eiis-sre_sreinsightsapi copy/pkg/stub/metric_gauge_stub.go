package stub

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"math/rand"
	"net/url"

	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
)

type MetricGaugeRepositoryStub struct {
	metricGauge model.MetricGauge
}

func (s MetricGaugeRepositoryStub) GetMetricGauge(quriesData *url.Values) (model.MetricGauge, error) {

	current := rand.Intn(99-1) + 1
	subtitle := fmt.Sprintf("%d of 100 core used", current)
	//log.Printf("current %d and sunbi %s", current, subtitle)
	metricGauge := model.MetricGauge{
		Type: "gauge", Title: "CPU Usage", Value: model.MetricGaugeValue{
			Title:    "CPU Usage",
			SubTitle: subtitle,
			Min:      0,
			Max:      100,
			Current:  current,
			Request:  7,
		},
	}

	return metricGauge, nil
}

func NewMetricGaugeRepositoryStub() MetricGaugeRepositoryStub {

	content, err := ioutil.ReadFile("./pkg/jsondata/metric_gauge.json")

	if err != nil {
		log.Fatal("json file error", err)
	}

	var metricGauge model.MetricGauge
	errd := json.Unmarshal(content, &metricGauge)

	if errd != nil {
		log.Fatal("json unmarshal error", errd)
	}

	return MetricGaugeRepositoryStub{metricGauge}
}
