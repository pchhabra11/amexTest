package stub

import (
	"encoding/json"
	"io/ioutil"
	"log"

	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
)

type MetricTableRepositoryStub struct {
	metricTable model.MetricTable
}

func (s MetricTableRepositoryStub) GetMetricTable(id string) (model.MetricTable, error) {

	//content, err := ioutil.ReadFile("./pkg/jsondata/metric_table.json")

	var content []byte
	var err error
	switch id {
	case "app_1_name_space_1":
		content, err = ioutil.ReadFile("./pkg/jsondata/metric_table_1.json")
	case "app_1_service_1":
		content, err = ioutil.ReadFile("./pkg/jsondata/metric_table_2.json")
	case "app_4_table_1":
		content, err = ioutil.ReadFile("./pkg/jsondata/metric_table_app_4.json")
	case "app_4_name_space_1":
		content, err = ioutil.ReadFile("./pkg/jsondata/metric_table_app4_space.json")

	default:
		content, err = ioutil.ReadFile("./pkg/jsondata/metric_table.json")

	}

	if err != nil {
		log.Fatal("json file error", err)
	}

	var metricTable model.MetricTable
	errd := json.Unmarshal(content, &metricTable)

	if errd != nil {
		log.Fatal("json unmarshal error", errd)
	}

	return metricTable, nil

	//return s.metricTable, nil
}

func NewMetricTableRepositoryStub() MetricTableRepositoryStub {

	content, err := ioutil.ReadFile("./pkg/jsondata/metric_table.json")

	if err != nil {
		log.Fatal("json file error", err)
	}

	var metricTable model.MetricTable
	errd := json.Unmarshal(content, &metricTable)

	if errd != nil {
		log.Fatal("json unmarshal error", errd)
	}

	return MetricTableRepositoryStub{metricTable}
}
