/*
Package app is the primary runtime application package for applications using the Go Paved Road template application.

This package hosts all of the primary runtime logic including HTTP Handlers, Logging, DB Calls, etc.
*/
package app

import (
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"github.aexp.com/amex-eng/eiis-sre_redis-lib/pkg/config"
	"github.aexp.com/amex-eng/eiis-sre_redis-lib/pkg/models"
	"github.aexp.com/amex-eng/eiis-sre_redis-lib/pkg/queryCache"
	"github.aexp.com/amex-eng/go-paved-road/pkg/api"
	"github.aexp.com/amex-eng/go-paved-road/pkg/constant"
	"github.aexp.com/amex-eng/go-paved-road/pkg/db"
	hapi "github.aexp.com/amex-eng/go-paved-road/pkg/handlerapi"
	"github.aexp.com/amex-eng/go-paved-road/pkg/logging"
	"github.aexp.com/amex-eng/go-paved-road/pkg/stub"
	"github.aexp.com/amex-eng/go-steamroller/server"
	"github.com/julienschmidt/httprouter"
	//"database/sql"
	//_ "github.com/lib/pq"
)

// Application creates an instance of the custom user application. Users can use this type to store instance level
// information that can be access across routines & handlers.
type Application struct {
	*server.Server
}

// oneBillion is used to convert seconds to nanoseconds.
const oneBillion = 1000000000

// Start is used to start up the customer application. Use this to dial connections or startup any custom listeners.
//
// nolint:typecheck // methods from the underlying Server type are not found, causing the typecheck to fail
func (app *Application) Start() {
	// Wait for Server Shutdown

	//appinfo := hapi.AppInfoHandler{api.NewAppinfoApi(model.NewAppinfoRepositoryStub())}

	//app.HTTPServer.Listen()

	//appinfo := hapi.AppInfoHandler{Apiservice: api.NewAppinfoApi(db.AllAppinfoRepositoryDb())}

	dbe := app.GetGormDB()

	//defer dbe.Close()
	applist := hapi.ApplistHandler{Applistservice: api.NewApplistApi(db.NewApplistRepositoryDb(dbe))}
	appcomp1 := hapi.AppComponentHandler{AppCompservice: api.NewAppComponentApi(db.NewAppComponentRepositoryDbLevelOne(dbe))}

	appMetric := hapi.MetricReqHandler{
		MetricReqservice:             api.NewMetricReqApi(stub.NewMetricReqRepositoryStub()),
		MetricBarColService:          api.NewMetricBarColApi(stub.NewMetricBarColRepositoryStub()),
		MetricGaugeService:           api.NewMetricGaugeApi(db.NewMetricGaugeRepositoryDb(dbe)),
		MetricGraphMultiLineService:  api.NewMetricGraphMultiLineApi(db.NewMetricGraphMultiLineRepositoryDb(dbe)),
		MetricGraphSingleLineService: api.NewMetricGraphSingleLineApi(db.NewMetricGraphSingleLineRepositoryDb(dbe)),
		MetricTableService:           api.NewMetricTableApi(db.NewMetricTableRepositoryDb(dbe)),
	}

	dbe2 := dbe

	if app.Config.GetString("ENV") == "e1e2test" {
		logging.Infof("test in e1e2test")
		dbe2 = app.GetGormDBE2()
		//defer dbe2.Close()
	}

	//Redis connection
	// logging.Infof("Initiating Redis Connection!")
	// app.SetRedis()

	appMetricNew := hapi.MetricReqHandlerRef{
		MetricReqservice:                api.NewMetricReqApi(stub.NewMetricReqRepositoryStub()),
		MetricBarColService:             api.NewMetricBarColApi(stub.NewMetricBarColRepositoryStub()),
		MetricGaugeService:              api.NewMetricGaugeApi(db.NewMetricGaugeRepositoryDb(dbe2)),
		MetricGraphMultiLineService:     api.NewMetricGraphMultiLineApi(db.NewMetricGraphMultiLineRepositoryDb(dbe2)),
		MetricGraphSingleLineService:    api.NewMetricGraphSingleLineApi(db.NewMetricGraphSingleLineRepositoryDb(dbe2)),
		MetricTableService:              api.NewMetricTableApi(db.NewMetricTableRepositoryDb(dbe2)),
		ItsmMetricService:               api.NewItsmMetricApi(db.NewItsmMetricRepositoryDb(dbe2)),
		MetricNonAggregatedTableService: api.NewMetricNonAggregatedTableApi(db.NewMetricNonAggregatedTableDb(dbe2)),
	}

	// appMetricNew := hapi.MetricReqHandlerRef{
	// 	MetricReqservice:             api.NewMetricReqApi(stub.NewMetricReqRepositoryStub()),
	// 	MetricBarColService:          api.NewMetricBarColApi(stub.NewMetricBarColRepositoryStub()),
	// 	MetricGaugeService:           api.NewMetricGaugeApi(db.NewMetricGaugeRepositoryDb(app.GetGormDB())),
	// 	MetricGraphMultiLineService:  api.NewMetricGraphMultiLineApi(db.NewMetricGraphMultiLineRepositoryDb(app.GetGormDB())),
	// 	MetricGraphSingleLineService: api.NewMetricGraphSingleLineApi(db.NewMetricGraphSingleLineRepositoryDb(app.GetGormDB())),
	// 	MetricTableService:           api.NewMetricTableApi(db.NewMetricTableRepositoryDb(app.GetGormDB())),
	// 	ItsmMetricService:            api.NewItsmMetricApi(db.NewItsmMetricRepositoryDb(app.GetGormDB())),
	// }

	//app.HTTPServer.RegisterHandler(http.MethodGet, "/appinfo", appinfo.GetAllAppInfo)
	app.HTTPServer.RegisterHandler(http.MethodGet, "/app_list", applist.GetAllAppComp)

	app.HTTPServer.RegisterHandler(http.MethodGet, "/service_map", applist.GetServiceMapData)
	app.HTTPServer.RegisterHandler(http.MethodGet, "/service_map/:service_id", applist.GetServiceMapData)
	app.HTTPServer.RegisterHandler(http.MethodGet, "/check_service_map/:service_id", applist.CheckServiceMap)

	app.HTTPServer.RegisterHandler(http.MethodGet, "/journey_itsm_details", applist.GetJourneyDetails)
	app.HTTPServer.RegisterHandler(http.MethodGet, "/journey_list", applist.GetJourneyList)

	app.HTTPServer.RegisterHandler(http.MethodGet, "/entity_layout_detail", appcomp1.GetAllAppComp)
	app.HTTPServer.RegisterHandler(http.MethodGet, "/metric_req", appMetric.GetMetricReq)
	app.HTTPServer.RegisterHandler(http.MethodPost, "/metric_req_new", appMetricNew.GetMetricReqNew)
	app.HTTPServer.RegisterHandler(http.MethodOptions, "/metric_req_new", appMetricNew.GetMetricReqNew)

	app.HTTPServer.RegisterHandler(http.MethodGet, "/app_component_details", appcomp1.GetAllAppComp)

	app.HTTPServer.RegisterHandler(http.MethodGet, "/fetch-entity-tree", appcomp1.GetMetricsMetadata)

	app.HTTPServer.RegisterHandler(http.MethodGet, "/color-code-service-map", applist.ColorCodeServiceMap)

	//heath ready
	app.HTTPServer.RegisterHandler(http.MethodGet, "/ready", app.HealthHandler)
	//app.HTTPServer.RegisterHandler(http.MethodGet, "/health", app.ReadyHandler)
	app.HTTPServer.RegisterHandler(http.MethodGet, "/dbhealth", app.DbhealthHandler)
	// app.HTTPServer.RegisterHandler(http.MethodGet, "/redishealth", app.RedishealthHandler)
	app.HTTPServer.RegisterHandler(http.MethodGet, "/flush_layout_caches", app.FlushLayoutCachesHandler)

	logging.Infof("Server started")

	//app.HTTPServer.Listen("8080")

	<-app.Graceful.Done()
}

func CheckError(err error) {
	if err != nil {
		panic(err)
	}
}

// func transConfig(int d, string s, error err) {
// 	logging.Infof(d, s, err)
// }

// Shutdown will trigger a shutdown of anything started within the Start() method.
//
// nolint:typecheck // methods from the underlying Server type are not found, causing the typecheck to fail
func (app *Application) Shutdown() {
	defer app.Stop()
}

// CustomHandler is a sample Handler that returns nothing but a 200 OK
//
// nolint // methods from the underlying Server type are not found, causing the typecheck to fail
func (app *Application) CustomHandler(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {
	t := time.Now()

	//fmt.Fprintf(w, "%s", "custom hajj")
	// Add Logic Here

	if app.Config.GetBool("enable_metrics") {
		// Measure Latency for this request (in ns)
		app.Metrics.Latency.WithStringObserve(float64(time.Since(t))/oneBillion, r.URL.Path, "http")
	}
}

func (app *Application) HealthHandler(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {
	w.Header().Add("Content-Type", "application/json")
	w.Header().Add("Access-Control-Allow-Headers", "*")
	w.Header().Add("Access-Control-Allow-Methods", "*")
	w.Header().Add("Access-Control-Allow-Origin", "*")
	//w.Write(appinfo)

	resp := make(map[string]string)
	resp["health"] = "ok"
	jsonResp, err := json.Marshal(resp)
	if err != nil {
		logging.Errorf("Error happened in JSON marshal. Err: %s", err)
		return
	}
	w.Write(jsonResp)
}

func (app *Application) ReadyHandler(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {

	w.Header().Add("Content-Type", "application/json")
	w.Header().Add("Access-Control-Allow-Headers", "*")
	w.Header().Add("Access-Control-Allow-Methods", "*")
	w.Header().Add("Access-Control-Allow-Origin", "*")
	//w.Write(appinfo)

	resp := make(map[string]string)
	resp["ready"] = "ok"
	jsonResp, err := json.Marshal(resp)
	if err != nil {
		logging.Errorf("Error happened in JSON marshal. Err: %s", err)
		return
	}
	w.Write(jsonResp)

}

func (app *Application) DbhealthHandler(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {

	w.Header().Add("Content-Type", "application/json")
	w.Header().Add("Access-Control-Allow-Headers", "*")
	w.Header().Add("Access-Control-Allow-Methods", "*")
	w.Header().Add("Access-Control-Allow-Origin", "*")
	//w.Write(appinfo)

	psqlconn := getConnectionString(app)

	resp := make(map[string]string)
	_, err := app.GetCheckGormDB()
	resp["dbstring"] = psqlconn
	resp["maxOpenConns"] = fmt.Sprintf("%d", app.Config.GetInt("MAX_OPEN_CONNS"))
	resp["maxIdleConns"] = fmt.Sprintf("%d", app.Config.GetInt("MAX_IDLE_CONNS"))
	if err != nil {
		resp["error"] = err.Error()
	} else {
		resp["db"] = "connected"
	}

	jsonResp, err := json.Marshal(resp)
	if err != nil {
		logging.Errorf("Error happened in JSON marshal. Err: %s", err)
		return
	}
	w.Write(jsonResp)

}

func (app *Application) RedishealthHandler(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {
	w.Header().Add("Content-Type", "application/json")
	w.Header().Add("Access-Control-Allow-Headers", "*")
	w.Header().Add("Access-Control-Allow-Methods", "*")
	w.Header().Add("Access-Control-Allow-Origin", "*")

	redisConfig := models.RedisConfig{
		RedisAddress:    app.Config.GetString("REDIS_ADDR"),
		RedisUser:       app.Config.GetString("REDIS_USER"),
		RedisPassword:   app.Config.GetString("REDIS_PASS"),
		RedisDbnumber:   0,
		RedisClientCert: app.Config.GetString("REDIS_CLIENT_CERT"),
	}

	redisconn := fmt.Sprintf("RedisAddress: %s , RedisUser: %s , isRedisLocal: %s", redisConfig.RedisAddress, redisConfig.RedisUser, app.Config.GetString("REDIS_LOCAL"))
	queryCachingConfig := models.QueryCachingConfig{MaxCacheSize: constant.MAX_CACHE_SIZE, CacheTimeout: constant.CACHETIMEOUT, SortedSetName: constant.SORTED_SET_NAME_LRU}

	resp := make(map[string]string)
	err := config.InitRedis(redisConfig, nil, &queryCachingConfig, app.Config.GetBool("REDIS_LOCAL"))
	resp["redisString"] = redisconn

	if err != nil {
		resp["error"] = err.Error()
	} else {
		resp["redis"] = "connected"
	}

	jsonResp, err := json.Marshal(resp)
	if err != nil {
		logging.Errorf("Error happened in JSON marshal. Err: %s", err)
		return
	}
	w.Write(jsonResp)
}

func (app *Application) FlushLayoutCachesHandler(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {
	w.Header().Add("Content-Type", "application/json")
	w.Header().Add("Access-Control-Allow-Headers", "*")
	w.Header().Add("Access-Control-Allow-Methods", "*")
	w.Header().Add("Access-Control-Allow-Origin", "*")

	err := queryCache.FlushCaches(constant.WILDCARD_CACHE_KEY, constant.SORTED_SET_NAME_LRU)
	resp := make(map[string]string)
	resp["wildcard"] = constant.WILDCARD_CACHE_KEY
	if err != nil {
		resp["error"] = err.Error()
	} else {
		resp["success"] = "flushed"
	}

	jsonResp, err := json.Marshal(resp)
	if err != nil {
		logging.Errorf("Error happened in JSON marshal. Err: %s", err)
		return
	}
	w.Write(jsonResp)
}
