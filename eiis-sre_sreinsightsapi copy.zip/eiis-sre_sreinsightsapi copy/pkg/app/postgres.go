package app

import (
	"database/sql"
	"fmt"
	"log"
	"os"
	"sync"
	"time"

	"github.aexp.com/amex-eng/go-paved-road/pkg/logging"
	_ "github.com/lib/pq"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
	"gorm.io/gorm/schema"
	"gorm.io/plugin/dbresolver"
)

var (
	dbPq    *sql.DB
	oncedb  sync.Once
	gormDb  *gorm.DB
	oncegdb sync.Once
	errorDb error

	dbPqE    *sql.DB
	oncedbE  sync.Once
	gormDbE  *gorm.DB
	oncegdbE sync.Once
	errorDbE error
)

func getConnectionString(app *Application) string {

	useTLS := "disable" //app.Config.GetBool("postgres_tls")
	if app.Config.GetBool("POSTGRES_TLS") {
		useTLS = app.Config.GetString("POSTGRES_SSL_MODE")
	}

	psqlconn := fmt.Sprintf("host=%s port=%d user=%s password=%s dbname=%s sslmode=%s",
		app.Config.GetString("POSTGRES_HOST"),     // app.Config.GetString("postgres_host"),
		app.Config.GetInt64("POSTGRES_PORT"),      // app.Config.GetInt64("postgres_port"),
		app.Config.GetString("POSTGRES_USER"),     // app.Config.GetString("postgres_user"),
		app.Config.GetString("POSTGRES_PASSWORD"), // app.Config.GetString("postgres_password"),
		app.Config.GetString("POSTGRES_DB"),       // app.Config.GetString("postgres_db"),
		useTLS)

	if len(app.Config.GetString("postgres_password")) == 0 {
		psqlconn = fmt.Sprintf("host=%s port=%d user=%s dbname=%s sslmode=%s",
			app.Config.GetString("POSTGRES_HOST"), // app.Config.GetString("postgres_host"),
			app.Config.GetInt64("POSTGRES_PORT"),  // app.Config.GetInt64("postgres_port"),
			app.Config.GetString("POSTGRES_USER"), // app.Config.GetString("postgres_user"),
			app.Config.GetString("POSTGRES_DB"),   // app.Config.GetString("postgres_db"),
			useTLS)
	}

	return psqlconn
}

func (app *Application) GetDB() *sql.DB {

	oncedb.Do(func() {

		// const (
		// 	host     = "pgbouncer"
		// 	port     = 5432
		// 	user     = "postgres"
		// 	password = "password"
		// 	dbname   = "metrics_dashboard"
		// )

		logging.Infof("database initail")

		// psqlconn := fmt.Sprintf("host=%s port=%d user=%s password=%s dbname=%s sslmode=disable", host, port, user, password, dbname)
		psqlconn := getConnectionString(app)

		logging.Infof("connection string:%s", psqlconn)

		// open database
		//db := app.DB
		var err error
		dbPq, err = sql.Open("postgres", psqlconn)

		//maxOpenConns
		//maxIdleConns
		maxOpenConns := app.Config.GetInt("MAX_OPEN_CONNS")
		maxIdleConns := app.Config.GetInt("MAX_IDLE_CONNS")
		logging.Infof("maxOpenConns %d", maxOpenConns)
		logging.Infof("maxIdleConns %d", maxIdleConns)

		dbPq.SetMaxOpenConns(maxOpenConns)
		dbPq.SetMaxIdleConns(maxIdleConns)

		if err != nil {
			panic(fmt.Sprintf("Unable to connection to database: %v\n", err))
		}

		// gormDB, err := gorm.Open(postgres.New(postgres.Config{
		// 	Conn: db,
		// }), &gorm.Config{})

		if err != nil {
			panic(fmt.Sprintf("Unable to connection to database GORM:  %v\n", err))
		}

		logging.Infof("Connected!")

	})

	return dbPq
}

func (app *Application) GetGormDB() *gorm.DB {

	oncegdb.Do(func() {

		newLogger := logger.New(
			log.New(os.Stdout, "\r\n", log.LstdFlags), // io writer
			logger.Config{
				SlowThreshold:             time.Second, // Slow SQL threshold
				LogLevel:                  logger.Info, // Log level
				IgnoreRecordNotFoundError: false,       // Ignore ErrRecordNotFound error for logger
				ParameterizedQueries:      false,       // Don't include params in the SQL log
				Colorful:                  false,       // Disable color
			},
		)

		//nameingSchema := schema.NamingStrategy{TablePrefix: "public."} // schema name

		var err error
		gormDb, errorDb = gorm.Open(postgres.New(postgres.Config{
			Conn: app.GetDB(),
		}), &gorm.Config{
			Logger:      newLogger,
			PrepareStmt: true,

			//NamingStrategy: nameingSchema,
		})

		gormDb.Use(dbresolver.Register(dbresolver.Config{}).SetConnMaxIdleTime(time.Hour).SetConnMaxLifetime(24 * time.Hour).SetMaxIdleConns(100).SetMaxOpenConns(200))

		if err != nil {
			panic(fmt.Sprintf("Unable to connection to database: %v\n", err))
		}
	})

	return gormDb
}

func (app *Application) GetCheckGormDB() (*gorm.DB, error) {

	oncegdb.Do(func() {

		newLogger := logger.New(
			log.New(os.Stdout, "\r\n", log.LstdFlags), // io writer
			logger.Config{
				SlowThreshold:             time.Second, // Slow SQL threshold
				LogLevel:                  logger.Info, // Log level
				IgnoreRecordNotFoundError: false,       // Ignore ErrRecordNotFound error for logger
				ParameterizedQueries:      false,       // Don't include params in the SQL log
				Colorful:                  false,       // Disable color
			},
		)

		nameingSchema := schema.NamingStrategy{TablePrefix: "public."} // schema name

		//var err error
		gormDb, errorDb = gorm.Open(postgres.New(postgres.Config{
			Conn: app.GetDB(),
		}), &gorm.Config{
			Logger:         newLogger,
			NamingStrategy: nameingSchema,
			PrepareStmt:    true,
		})

	})

	return gormDb, errorDb
}

func getConnectionString_e2(app *Application) string {

	useTLS := "disable" //app.Config.GetBool("postgres_tls")
	if app.Config.GetBool("POSTGRES_TLS") {
		useTLS = app.Config.GetString("POSTGRES_SSL_MODE")
	}

	psqlconn := fmt.Sprintf("host=%s port=%d user=%s password=%s dbname=%s sslmode=%s",
		app.Config.GetString("POSTGRES_HOST_E2"),     // app.Config.GetString("postgres_host"),
		app.Config.GetInt64("POSTGRES_PORT_E2"),      // app.Config.GetInt64("postgres_port"),
		app.Config.GetString("POSTGRES_USER_E2"),     // app.Config.GetString("postgres_user"),
		app.Config.GetString("POSTGRES_PASSWORD_E2"), // app.Config.GetString("postgres_password"),
		app.Config.GetString("POSTGRES_DB_E2"),       // app.Config.GetString("postgres_db"),
		useTLS)

	if len(app.Config.GetString("postgres_password")) == 0 {
		psqlconn = fmt.Sprintf("host=%s port=%d user=%s dbname=%s sslmode=%s",
			app.Config.GetString("POSTGRES_HOST_E2"), // app.Config.GetString("postgres_host"),
			app.Config.GetInt64("POSTGRES_PORT_E2"),  // app.Config.GetInt64("postgres_port"),
			app.Config.GetString("POSTGRES_USER_E2"), // app.Config.GetString("postgres_user"),
			app.Config.GetString("POSTGRES_DB_E2"),   // app.Config.GetString("postgres_db"),
			useTLS)
	}

	return psqlconn
}

func (app *Application) GetDBE2() *sql.DB {

	oncedbE.Do(func() {

		// const (
		// 	host     = "pgbouncer"
		// 	port     = 5432
		// 	user     = "postgres"
		// 	password = "password"
		// 	dbname   = "metrics_dashboard"
		// )

		logging.Infof("database initail")

		// psqlconn := fmt.Sprintf("host=%s port=%d user=%s password=%s dbname=%s sslmode=disable", host, port, user, password, dbname)
		psqlconn := getConnectionString_e2(app)

		logging.Infof("connection string:%s", psqlconn)

		// open database
		//db := app.DB
		var err error
		dbPqE, err = sql.Open("postgres", psqlconn)

		if err != nil {
			panic(fmt.Sprintf("Unable to connection to database: %v\n", err))
		}

		// gormDB, err := gorm.Open(postgres.New(postgres.Config{
		// 	Conn: db,
		// }), &gorm.Config{})

		if err != nil {
			panic(fmt.Sprintf("Unable to connection to database GORM:  %v\n", err))
		}

		logging.Infof("Connected!")

	})

	return dbPqE
}

func (app *Application) GetGormDBE2() *gorm.DB {

	oncegdbE.Do(func() {

		newLogger := logger.New(
			log.New(os.Stdout, "\r\n", log.LstdFlags), // io writer
			logger.Config{
				SlowThreshold:             time.Second, // Slow SQL threshold
				LogLevel:                  logger.Info, // Log level
				IgnoreRecordNotFoundError: false,       // Ignore ErrRecordNotFound error for logger
				ParameterizedQueries:      false,       // Don't include params in the SQL log
				Colorful:                  false,       // Disable color
			},
		)

		//nameingSchema := schema.NamingStrategy{TablePrefix: "public."} // schema name

		var err error
		gormDbE, errorDbE = gorm.Open(postgres.New(postgres.Config{
			Conn: app.GetDBE2(),
		}), &gorm.Config{
			Logger:      newLogger,
			PrepareStmt: true,

			//NamingStrategy: nameingSchema,
		})

		gormDbE.Use(dbresolver.Register(dbresolver.Config{}).SetConnMaxIdleTime(time.Hour).SetConnMaxLifetime(24 * time.Hour).SetMaxIdleConns(100).SetMaxOpenConns(200))

		if err != nil {
			panic(fmt.Sprintf("Unable to connection to database: %v\n", err))
		}
	})

	return gormDbE
}
