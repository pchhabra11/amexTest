package app

import (
	"context"
	"net/http"
	"testing"
	"time"

	"github.aexp.com/amex-eng/go-steamroller/server"
	"github.com/spf13/viper"
)

func TestAppHandler(t *testing.T) {
	srv, err := server.New(server.Config{Config: viper.New()})
	if err != nil {
		t.Errorf("Unable to create new Server")
	}

	// Create internal srv instance for handlers
	a := &Application{Server: srv}

	// Register Custom HTTP Handler
	srv.HTTPServer.RegisterHandler("GET", "/", a.CustomHandler)

	ctx, cancel := context.WithCancel(context.Background())

	go func() {
		err := srv.Start()
		if err != server.ErrShutdown {
			t.Logf("Server shutdown for unexpected reasons")

			return
		}
		cancel()
	}()
	defer srv.Stop()

	<-time.After(5 * time.Second)

	t.Run("Verify Server is up and able to respond", func(t *testing.T) {
		r, err := http.Get("http://localhost:8080/")
		if err != nil {
			t.Errorf("HTTP Client received the following error when calling server - %s", err)
			t.FailNow()
		}
		if r.StatusCode != 200 {
			t.Errorf("HTTP Client received unexpected StatusCode %d, expected 200", r.StatusCode)
		}
	})
	srv.Stop()

	select {
	case <-ctx.Done():

		return
	case <-time.After(10 * time.Second):
		t.Errorf("Server Startup timed out")
	}

}
