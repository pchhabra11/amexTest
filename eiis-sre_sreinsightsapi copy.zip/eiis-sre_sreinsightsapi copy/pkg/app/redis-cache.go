package app

import (
	"github.aexp.com/amex-eng/eiis-sre_redis-lib/pkg/config"
	"github.aexp.com/amex-eng/eiis-sre_redis-lib/pkg/models"
	"github.aexp.com/amex-eng/go-paved-road/pkg/constant"
	"github.aexp.com/amex-eng/go-paved-road/pkg/logging"
	_ "github.com/lib/pq"
)

func (app *Application) SetRedis() {

	redisConfig := models.RedisConfig{
		RedisAddress:    app.Config.GetString("REDIS_ADDR"),
		RedisUser:       app.Config.GetString("REDIS_USER"),
		RedisPassword:   app.Config.GetString("REDIS_PASS"),
		RedisDbnumber:   0,
		RedisClientCert: app.Config.GetString("REDIS_CLIENT_CERT"),
	}

	queryCachingConfig := models.QueryCachingConfig{MaxCacheSize: constant.MAX_CACHE_SIZE, CacheTimeout: constant.CACHETIMEOUT, SortedSetName: constant.SORTED_SET_NAME_LRU}

	err := config.InitRedis(redisConfig, nil, &queryCachingConfig, app.Config.GetBool("REDIS_LOCAL"))
	if err != nil {
		logging.Errorf("Redis Connection Error: %s", err.Error())
	}
	logging.Infof("RedisAddress: %s , RedisUser: %s, isRedisLocal: %s", redisConfig.RedisAddress, redisConfig.RedisUser, app.Config.GetString("REDIS_LOCAL"))
}
