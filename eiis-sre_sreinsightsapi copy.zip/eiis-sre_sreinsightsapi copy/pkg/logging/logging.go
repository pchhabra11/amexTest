package logging

import (
	"fmt"
	"log"
	"log/slog"
	"os"

	"github.aexp.com/amex-eng/go-paved-road/internal/utils"
	"github.aexp.com/amex-eng/go-steamroller/logging/dave"
)

var (
	// logger is a shared implementation which prevents issues of some logs being printed while others are not
	logger  *slog.Logger
	leveler *slog.LevelVar
)

const (
	carIDAltEnvKey  = "CARID"
	appNameEnvKey   = "APP_NAME"
	namespaceEnvKey = "NAMESPACE"
	clusterEnv      = "CLUSTER_ENV"
)

//
// [ELF]: https://github.aexp.com/pages/amex-eng/observability/docs/elf/
// [dave]: https://github.aexp.com/amex-eng/go-steamroller/tree/main/logging/dave
func init() {

	banner := `
		╭━━━╮╭━━╮╭━━╮╭━━━╮
		┃╭━━╯╰┫┣╯╰┫┣╯┃╭━╮┃
		┃╰━━╮╱┃┃╱╱┃┃╱┃╰━━╮
		┃╭━━╯╱┃┃╱╱┃┃╱╰━━╮┃
		┃╰━━╮╭┫┣╮╭┫┣╮┃╰━╯┃
		╰━━━╯╰━━╯╰━━╯╰━━━╯
	`
	log.Default().Printf(banner)
	hostname, _ := os.Hostname()

	logger, leveler = dave.New(dave.Config{Template: dave.Template{
		Environment: dave.Environment{
			Name: utils.GetOptions(clusterEnv, ""),
			Host: hostname,
		},
		Application: dave.Application{
			Name:      utils.GetOptions(appNameEnvKey, ""),
			NameSpace: utils.GetOptions(namespaceEnvKey, ""),
			CarID:     utils.GetOptions(carIDAltEnvKey, ""),
		},
	}})

	leveler.Set(slog.LevelDebug)
	logger = logger.WithGroup("tags")
}

func Infof(format string, v ...any) {
	logger.Info(fmt.Sprintf(format, v...), nil)
}

func Errorf(format string, v ...any) {
	logger.Error(fmt.Sprintf(format, v...), nil)
}
