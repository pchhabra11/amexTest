package model

import (
	"net/url"

	"github.aexp.com/amex-eng/go-paved-road/pkg/entity"
	"github.com/google/uuid"
)

type MetricGauge struct {
	Type       string                              `json:"type,omitempty"`
	Title      string                              `json:"title,omitempty"`
	Value      MetricGaugeValue                    `json:"value,omitempty"`
	MetricIds  []uuid.UUID                         `json:"metric_ids"`
	MetricData []entity.MetricsAggregatedPerMinute `json:"metric_agg"`
}
type MetricGaugeValue struct {
	Title    string `json:"title,omitempty"`
	SubTitle string `json:"subTitle,omitempty"`
	Min      int    `json:"min,omitempty"`
	Max      int    `json:"max,omitempty"`
	Current  int    `json:"current,omitempty"`
	Request  int    `json:"request,omitempty"`
}

type GaugeRequest struct {
	Type      string          `json:"type"`
	Interval  string          `json:"interval"`
	After     string          `json:"after"`
	Before    string          `json:"before"`
	TimeRange string          `json:"time_range"`
	EntityId  []GaugeEntityId `json:"entity_ids"`
}

type GaugeEntityId struct {
	Id        string      `json:"id"`
	MetricIds []uuid.UUID `json:"metric_ids"`
}

type MetricGaugeRepository interface {
	GetMetricGauge(data *url.Values) (MetricGauge, error)
	GetMetricGaugeJson(gaugeRequest *GraphRequest) (MetricGauge, error)
}
