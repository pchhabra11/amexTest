package model

import "github.aexp.com/amex-eng/go-paved-road/pkg/entity"

type Applist struct {
	Layout []ApplistLayout `json:"layout"`
}
type ApplistHeader struct {
	ID        string `json:"id"`
	Header    string `json:"header"`
	SubHeader string `json:"subHeader"`
}

type ApplistValue struct {
	DefaultVisible []string           `json:"defaultVisible"`
	Header         []ApplistHeader    `json:"header"`
	Content        [][]ContentApplist `json:"content"`
}
type ApplistLayout struct {
	Type  string       `json:"type"`
	Title string       `json:"title"`
	Value ApplistValue `json:"value"`
}

type ContentApplist struct {
	Type     string `json:"type"`
	Value    string `json:"value"`
	Redirect string `json:"redirect"`
}

type ApplistRepository interface {
	FindAllComp() (Applist, error)
	FindServiceMapData(serviceId string) ([]ServiceInfoRes, error)
	CheckServiceMapByServiceId(serviceId string) (*ServiceInfo, error)
	// FindMetricsMetadata(requested_entity_id string, entity_types []string) ([]MetricMetadataResponse, error)
	FindJourneyDetails(params entity.JourneyParams) ([]entity.JourneyItsmDetailsRes, error)
	FindJourneyList() ([]entity.JourneyListRes, error)
}
