package model

import (
	"net/url"

	"github.com/google/uuid"
)

type Appinfo struct {
	App_id          uuid.UUID
	App_name        string
	App_type        string
	App_description string
	Components      interface{} `json:"components,omitempty"`
	Metricinfo      interface{} `json:"metric_infos,omitempty"`
}

type AppinfoRepository interface {
	FindAll(params *url.Values) ([]Appinfo, error)
}
