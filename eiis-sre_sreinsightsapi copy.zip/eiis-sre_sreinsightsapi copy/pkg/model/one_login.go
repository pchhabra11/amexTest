package model

import "github.com/google/uuid"

type OneLogin struct {
	EntityId   uuid.UUID `json:"entity_id"`
	EntityName string    `json:"entity_name"`
	GraphType  string    `json:"graph_type"`
	GraphSort  string    `json:"graph_sort"`
}
