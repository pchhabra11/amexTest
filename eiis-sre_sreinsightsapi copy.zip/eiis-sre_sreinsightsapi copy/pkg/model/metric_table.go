package model

import (
	"net/url"

	"github.aexp.com/amex-eng/go-paved-road/pkg/entity"
	"github.com/google/uuid"
)

type MetricTable struct {
	Type       string                              `json:"type,omitempty"`
	Title      string                              `json:"title,omitempty"`
	Value      MetricTableValue                    `json:"value,omitempty"`
	MetricIds  []uuid.UUID                         `json:"metric_ids"`
	MetricData []entity.MetricsAggregatedPerMinute `json:"metric_agg"`
}
type MetricTableHeader struct {
	ID        string   `json:"id"`
	Header    string   `json:"header"`
	SubHeader string   `json:"subHeader"`
	Static    bool     `json:"static"`
	MetricIds []string `json:"metricIds"`
}

//	type MetricTableContent struct {
//		Type     string `json:"type"`
//		Value    string `json:"value"`
//		Redirect string `json:"redirect"`
//	}
type MetricTableValue struct {
	ReloadTime     int                    `json:"reloadTime"`
	DefaultVisible []string               `json:"defaultVisible"`
	Header         []MetricTableHeader    `json:"header"`
	Content        [][]MetricTableContent `json:"content"`
}

type MetricTableContent struct {
	Type     string `json:"type"`
	Value    string `json:"value"`
	Redirect string `json:"redirect"`
	MetricId string `json:"metricId"`
	EntityId string `json:"entityId"`
}

type MetricTableRepository interface {
	GetMetricTable(id *url.Values) (MetricTable, error)
	GetMetricTableJson(graphRequest *GraphRequest) (MetricTable, error)
	GetMetricTableMetric(graphRequest *GraphRequest) (MetricTable, error)
	//GetMetricJsonTable(id *url.Values) (MetricTable, error)
}
