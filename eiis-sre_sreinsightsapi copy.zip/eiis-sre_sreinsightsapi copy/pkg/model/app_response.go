package model

import (
	"encoding/json"
	"time"
)

type AppResponse struct {
	Status         int64           `json:"status"`
	Message        string          `json:"message"`
	Data           interface{}     `json:"data,omitempty"`
	Start          string          `json:"start,omitempty"`
	End            string          `json:"end,omitempty"`
	Offset         int             `json:"offset,omitempty"`
	Limit          int             `json:"limit,omitempty"`
	TimeFromClient time.Time       `json:"client_time,omitempty"`
	TimeStart      time.Time       `json:"server_time_start,omitempty"`
	TimeEnd        time.Time       `json:"server_time_end,omitempty"`
	ReqData        json.RawMessage `json:"req_data,omitempty"`
}
