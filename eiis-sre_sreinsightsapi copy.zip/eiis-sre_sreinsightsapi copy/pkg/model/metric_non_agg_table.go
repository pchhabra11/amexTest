package model

import (
	"github.aexp.com/amex-eng/go-paved-road/pkg/entity"
)

type MetricNonAggregatedTable struct {
	Type       string                       `json:"type,omitempty"`
	MetricData []entity.MetricNonAggregated `json:"metric_agg,omitempty"`
}

type MetricNonAggregatedTableRepository interface {
	GetMetricData(graphRequest *GraphRequest) (MetricNonAggregatedTable, error)
}
