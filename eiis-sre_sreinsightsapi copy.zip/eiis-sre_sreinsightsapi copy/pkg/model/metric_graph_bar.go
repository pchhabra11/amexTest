package model

type MetricBarCol struct {
	Type  string            `json:"type"`
	Title string            `json:"title"`
	Value MetricBarColValue `json:"value"`
}
type MetricBarColY struct {
	Title string `json:"title"`
	Value []int  `json:"value"`
}
type MetricBarColValue struct {
	Unit            string          `json:"unit"`
	ReloadTime      int             `json:"reloadTime"`
	DefaultInterval string          `json:"defaultInterval"`
	TimeStamp       int64           `json:"timeStamp"`
	Intervals       []string        `json:"intervals"`
	X               []int64         `json:"x"`
	Y               []MetricBarColY `json:"y"`
	Request         int             `json:"request"`
}

type MetricBarColRepository interface {
	GetMetricBarCol() (MetricBarCol, error)
}
