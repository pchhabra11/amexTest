package model

import (
	"fmt"
)

func (gp *GraphRequest) GetQueryMetricNonAgg() string {

	queryString := fmt.Sprintf(`SELECT 
	id,
	entity_id,
	metric_id,
	aggregate_interval_start,
	metadata
	FROM %s 
	WHERE
		entity_id in (?) and 
		metric_id in (?) and 
		aggregate_interval_start between  to_timestamp(?) and  to_timestamp(?)  
	ORDER BY aggregate_interval_start asc `, "non_aggregated_metrics")
	return queryString
}
