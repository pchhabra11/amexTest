package model

import (
	"encoding/json"
	"time"

	"github.aexp.com/amex-eng/go-paved-road/pkg/entity"
	"github.com/google/uuid"
)

type MetricGraphMultiLine struct {
	Type       string                              `json:"type,omitempty"`
	Title      string                              `json:"title,omitempty"`
	Value      MetricGraphMultiLineValue           `json:"value,omitempty"`
	MetricIds  []uuid.UUID                         `json:"metric_ids,omitempty"`
	MetricData []entity.MetricsAggregatedPerMinute `json:"metric_agg,omitempty"`
}

type PodMetricGraphMultiLine struct {
	Type          string                                 `json:"type,omitempty"`
	Title         string                                 `json:"title,omitempty"`
	Value         MetricGraphMultiLineValue              `json:"value,omitempty"`
	MetricIds     []uuid.UUID                            `json:"metric_ids,omitempty"`
	MetricData    []MultiPodDynamic                      `json:"metric_agg,omitempty"`
	MetricDataAgg []entity.MetricsAggregatedPerMinutePod `json:"metric_proxy_agg,omitempty"`
}

type MetricGraphMultiLineY struct {
	Title string `json:"title"`
	Value []int  `json:"value"`
}
type MetricGraphMultiLineValue struct {
	Unit            string                  `json:"unit"`
	ReloadTime      int                     `json:"reloadTime"`
	DefaultInterval string                  `json:"defaultInterval"`
	TimeStamp       int64                   `json:"timeStamp"`
	Intervals       []string                `json:"intervals"`
	X               []int64                 `json:"x"`
	Y               []MetricGraphMultiLineY `json:"y"`
	Request         int                     `json:"request"`
}

type MetricGraphMultiLineRepository interface {
	GetMetricGraphMultiLine() (MetricGraphMultiLine, error)
	GetMetricGraphMultiLineJson(graphRequest *GraphRequest) (MetricGraphMultiLine, error)
	GetMetricGraphMultiLineMetric(graphRequest *GraphRequest) (MetricGraphMultiLine, error)
	GetMetricGraphMultiLineDynamic(graphRequest *GraphRequest) (PodMetricGraphMultiLine, error)
	GetMetricGraphMultiLineSelective(graphRequest *GraphRequest) (PodMetricGraphMultiLine, error)
}

type MultiPodDynamic struct {
	EntityID               uuid.UUID       `json:"entity_id"`
	MetricID               uuid.UUID       `json:"metric_id"`
	AggregateIntervalStart time.Time       `json:"aggregate_interval_start"`
	AggregateIntervalEnd   time.Time       `json:"aggregate_interval_end"`
	DynamicValue           json.RawMessage `json:"dynamic_value"`
}

// type DynamicValueObject struct {
// 	AvgValue    float32 `json:"avg_value"`
// 	MinValue    float32 `json:"min_value"`
// 	MaxValue    float32 `json:"max_value"`
// 	Count       int     `json:"count"`
// 	OldestValue float32 `json:"oldest_value"`
// 	LatestValue float32 `json:"latest_value"`
// 	Trend       float32 `json:"trend"`
// 	TotalValue  float32 `json:"total_value"`
// }
