package model

import (
	"github.com/google/uuid"
	"github.com/lib/pq"
)

type ServiceInfoRes struct {
	ServiceId          uuid.UUID      `gorm:"column:service_id;type:uuid"`
	ServiceName        string         `gorm:"column:service_name"`
	ServiceType        string         `gorm:"column:service_type"`
	ServiceDescription string         `gorm:"column:service_description"`
	HasChild           bool           `gorm:"-"`
	Depth              int            `gorm:"column:depth"`
	Path               pq.StringArray `gorm:"column:path"`
	EntityRefId        uuid.UUID      `gorm:"column:entity_ref_id;type:uuid"`
	ServiceNames       pq.StringArray `gorm:"column:service_names"`
}

type ServiceInfo struct {
	ServiceId          uuid.UUID `gorm:"column:service_id;type:uuid"`
	ParentserviceId    uuid.UUID `gorm:"column:parent_service_id;type:uuid"`
	ServiceName        string    `gorm:"column:service_name"`
	ServiceType        string    `gorm:"column:service_type"`
	ServiceDescription string    `gorm:"column:service_description"`
	HasChild           bool      `gorm:"column:has_child"`
	EntityRefId        uuid.UUID `gorm:"column:entity_ref_id;type:uuid"`
}

func (ServiceInfo) TableName() string {
	return "service_info"
}
