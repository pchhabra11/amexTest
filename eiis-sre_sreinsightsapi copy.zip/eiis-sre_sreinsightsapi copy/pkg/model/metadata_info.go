package model

import "time"

type MetricMetadataResponse struct {
	ServiceName    string                     `json:"service_name,omitempty"`
	EntityID       string                     `json:"entity_id,omitempty"`
	EntityNames    []string                   `json:"entity_names,omitempty"`
	EntityType     string                     `json:"entity_type,omitempty"`
	MetricIds      []string                   `json:"metric_ids,omitempty"`
	MetricNames    []string                   `json:"metric_names,omitempty"`
	ParentEntityID string                     `json:"parent_entity_id,omitempty"`
	Children       [][]MetricMetadataResponse `json:"children"`
	DeeplinkIDs    []string                   `json:"deeplink_ids"`
}

type MetricMetadataPageLayout struct {
	Status  int    `json:"status"`
	Message string `json:"message"`
	Data    struct {
		PageLayout []struct {
			PageSort int    `json:"page_sort"`
			Title    string `json:"title"`
			Layout   []struct {
				Type     string `json:"type"`
				Title    string `json:"title"`
				ID       string `json:"id"`
				Col      int    `json:"col"`
				Children []struct {
					Type       string `json:"type"`
					Title      string `json:"title"`
					ID         string `json:"id"`
					Col        int    `json:"col"`
					Sort       int    `json:"sort"`
					LastNode   bool   `json:"last_node"`
					LayoutInfo []struct {
						LayoutID   int      `json:"layout_id"`
						EntityID   string   `json:"entity_id"`
						EntityName string   `json:"entity_name"`
						EntityType string   `json:"entity_type"`
						MetricIds  []string `json:"metric_ids"`
						MetaData   []struct {
							ID   string `json:"id"`
							Data struct {
								Type          string      `json:"type"`
								FetchType     string      `json:"fetch_type"`
								MaxThreshold  interface{} `json:"max_threshold"`
								MinThreshold  interface{} `json:"min_threshold"`
								IsCollapsible bool        `json:"is_collapsible"`
							} `json:"data"`
						} `json:"meta_data"`
						GraphSort   string `json:"graph_sort"`
						ColSpan     string `json:"col_span"`
						MetricName  string `json:"metric_name"`
						MetricClass string `json:"metric_class"`
						DeeplinkID  string `json:"deeplink_id"`
						PageClass   string `json:"page_class"`
						PageTitle   string `json:"page_title"`
						PageSort    string `json:"page_sort"`
						MetricUnit  string `json:"metric_unit"`
					} `json:"layout_info"`
					PageSort int `json:"page_sort"`
				} `json:"children"`
				Sort     int  `json:"sort"`
				LastNode bool `json:"last_node"`
				PageSort int  `json:"page_sort"`
			} `json:"layout"`
		} `json:"page_layout"`
	} `json:"data"`
	Start           string    `json:"start"`
	End             string    `json:"end"`
	ClientTime      time.Time `json:"client_time"`
	ServerTimeStart time.Time `json:"server_time_start"`
	ServerTimeEnd   time.Time `json:"server_time_end"`
}
