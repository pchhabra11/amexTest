package model

import (
	"net/url"

	"github.aexp.com/amex-eng/go-paved-road/pkg/entity"
)

type AppComponent struct {
	Navigation []AppComponentNavigation `json:"navigation,omitempty"`
	Layout     []AppComponentLayout     `json:"layout,omitempty"`
	PageLayout []AppPageLayout          `json:"page_layout,omitempty"`
}

type AppComponentNavigation struct {
	Title string `json:"title"`
	Href  string `json:"href"`
}

type AppComponentChildren struct {
	Type            string `json:"type"`
	Title           string `json:"title"`
	ID              string `json:"id"`
	Col             int    `json:"col"`
	ReloadTime      int    `json:"reloadTime"`
	DefaultInterval string `json:"defaultInterval"`
}
type AppComponentLayout struct {
	Type            string                 `json:"type"`
	Title           string                 `json:"title"`
	ID              string                 `json:"id"`
	IsCollapsible   bool                   `json:"is_collapsible,omitempty"`
	Col             int64                  `json:"col"`
	ReloadTime      int                    `json:"reloadTime,omitempty"`
	DefaultInterval string                 `json:"defaultInterval,omitempty"`
	Children        interface{}            `json:"old_children,omitempty"`
	NewChildren     []AppComponentLayout   `json:"children,omitempty"`
	RowCount        int                    `json:"rowCount,omitempty"`
	Data            map[string]interface{} `json:"data,omitempty"`
	SortValue       int64                  `json:"sort,omitempty"`
	ContainerClass  string                 `json:"container_class,omitempty"`
	ContainerName   string                 `json:"container_name,omitempty"`
	LastNode        bool                   `json:"last_node"`
	LayoutInfo      []entity.LayoutInfo    `json:"layout_info,omitempty"`
	PageClass       string                 `json:"page_class,omitempty"`
	PageTitle       string                 `json:"page_title,omitempty"`
	PageSort        int64                  `json:"page_sort,omitempty"`
	//LayoutInfo      json.RawMessage        `json:"layout_info,omitempty"`

}

type AppComponentRepository interface {
	FindAllAppComp(level *url.Values) (AppComponent, error)
	GetMetricsMetadata(requested_entity_id string, entity_types []string) ([]MetricMetadataResponse, error)
}

type BySortValue []AppComponentLayout

func (ac BySortValue) Len() int           { return len(ac) }
func (ac BySortValue) Less(i, j int) bool { return ac[i].SortValue < ac[j].SortValue }
func (ac BySortValue) Swap(i, j int)      { ac[i], ac[j] = ac[j], ac[i] }

type AppPageLayout struct {
	PageSort  int64                `json:"page_sort"`
	PageTitle string               `json:"title"`
	Layout    []AppComponentLayout `json:"layout,omitempty"`
}

type ByPageSortValue []AppPageLayout

func (ac ByPageSortValue) Len() int           { return len(ac) }
func (ac ByPageSortValue) Less(i, j int) bool { return ac[i].PageSort < ac[j].PageSort }
func (ac ByPageSortValue) Swap(i, j int)      { ac[i], ac[j] = ac[j], ac[i] }

type MetadataComponent struct {
	ID   string `json:"id"`
	Data struct {
		Type          string `json:"type"`
		FetchType     string `json:"fetch_type"`
		MaxThreshold  *int   `json:"max_threshold"`
		MinThreshold  *int   `json:"min_threshold"`
		IsCollapsible bool   `json:"is_collapsible"`
	} `json:"data"`
}

type LayoutResponse struct {
	Containers []AppComponentLayout `json:"containers"`
}
