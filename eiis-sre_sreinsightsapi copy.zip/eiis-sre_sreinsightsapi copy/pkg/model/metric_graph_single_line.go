package model

import (
	"net/url"

	"github.aexp.com/amex-eng/go-paved-road/pkg/entity"
	"github.com/google/uuid"
)

type MetricGraphSingleLine struct {
	Type       string                              `json:"type,omitempty"`
	Title      string                              `json:"title,omitempty"`
	Value      MetricGraphSingleLineValue          `json:"value,omitempty"`
	MetricIds  []uuid.UUID                         `json:"metric_ids"`
	MetricData []entity.MetricsAggregatedPerMinute `json:"metric_agg"`
}
type MetricGraphSingleLineY struct {
	Title string `json:"title,omitempty"`
	Value []int  `json:"value,omitempty"`
}
type MetricGraphSingleLineValue struct {
	Unit            string                 `json:"unit,omitempty"`
	ReloadTime      int                    `json:"reloadTime,omitempty"`
	DefaultInterval string                 `json:"defaultInterval,omitempty"`
	TimeStamp       int64                  `json:"timeStamp,omitempty"`
	Intervals       []string               `json:"intervals,omitempty"`
	X               []int64                `json:"x,omitempty"`
	Y               MetricGraphSingleLineY `json:"y,omitempty"`
	Request         int                    `json:"request,omitempty"`
}

type MetricGraphSingleLineRepository interface {
	GetMetricGraphSingleLine(queryValue *url.Values) (MetricGraphSingleLine, error)
	GetMetricGraphSingleLineJson(graphRequest *GraphRequest) (MetricGraphSingleLine, error)
}
