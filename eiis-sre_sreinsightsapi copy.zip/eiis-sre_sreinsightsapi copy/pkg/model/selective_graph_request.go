package model

import (
	"fmt"
)

func (gp *GraphRequest) GetQueryStringSelective() string {

	// queryString := fmt.Sprintf(`SELECT
	// entity_id,
	// metric_id,
	// aggregate_interval_start , aggregate_interval_end,
	// -- avg_value, min_value, max_value,
	// -- count, oldest_value, latest_value,
	// -- trend, is_processed,  inserted_at,
	// -- total_value ,
	// dynamic_value
	// FROM %s
	// WHERE
	// 	entity_id in (?) and
	// 	metric_id in (?) and
	// 	aggregate_interval_start between  to_timestamp(?) and  to_timestamp(?)
	// ORDER BY aggregate_interval_start asc `, gp.GetTable())

	queryString := fmt.Sprintf(`SELECT 
            entity_id, 
            metric_id, 
            aggregate_interval_start,
            aggregate_interval_end,
            jsonb_object_agg(pod_name, pod_agg) FILTER (WHERE pod_name IS NOT NULL) as dynamic_value
        FROM (           
            SELECT 
                entity_id,
                metric_id,
                aggregate_interval_start, 
                aggregate_interval_end, 
                pod_name,
                jsonb_build_object( 
					
                    'avg_value', pod_data->>'avg_value',
                    'min_value', pod_data->>'min_value',
                    'max_value', pod_data->>'max_value',
                    'count', pod_data->>'count',
                    'oldest_value', pod_data->>'oldest_value' ,
                    'latest_value', pod_data->>'latest_value' ,
                    'trend', pod_data->>'avg_value',
                    'total_value', pod_data->>'total_value'
                 ) as pod_agg
            FROM (
                    SELECT 
                        entity_id,
                        metric_id,
                        aggregate_interval_start , aggregate_interval_end,
                        --dynamic_value,
                        (jsonb_each(dynamic_value)).key as pod_name,
                        (jsonb_each(dynamic_value)).value as pod_data
					FROM %s
                    WHERE
                            entity_id in (?) and 
                            metric_id in (?) and 
                            aggregate_interval_start between  to_timestamp(?) and  to_timestamp(?)
                ) as exapanded_data
            GROUP BY entity_id, metric_id, aggregate_interval_start, aggregate_interval_end, pod_name, pod_data
            ) AS distinct_rows
        GROUP BY entity_id, metric_id, aggregate_interval_start, aggregate_interval_end 
        ORDER BY aggregate_interval_start asc `, gp.GetTable())

	return queryString
}

func (gp *GraphRequest) GetQueryStringSelectiveTable() string {

	queryString := fmt.Sprintf(`
    SELECT  
        'selective_table_agg',
        entity_id, 
        metric_id, 
        pod_name,
        to_timestamp(?) as aggregate_interval_start, 
        to_timestamp(?) as aggregate_interval_end,
        avg(avg_value) as avg_value,
        min(min_value) as min_value, 
        max(max_value) as max_value, 
        sum(count) as count,
        sum(total_value) as total_value
    FROM
        (
            SELECT 
                entity_id,
                metric_id,
                aggregate_interval_start , aggregate_interval_end,
                (jsonb_each(dynamic_value)).key as pod_name,
                ((jsonb_each(dynamic_value)).value->>'avg_value' )::double precision	 as avg_value,
                ((jsonb_each(dynamic_value)).value->>'min_value')::double precision	 as min_value,
                ((jsonb_each(dynamic_value)).value->>'max_value' )::double precision	 as max_value,
                ((jsonb_each(dynamic_value)).value->>'count')::double precision	 as count,
                ((jsonb_each(dynamic_value)).value->>'latest_value')::double precision	 as latest_value ,
                ((jsonb_each(dynamic_value)).value->>'total_value')::double precision	 as total_value
            FROM 
            %s
            WHERE
                entity_id in (?) and 
                metric_id in (?) and 
                aggregate_interval_start between  to_timestamp(?) and  to_timestamp(?)
        ) as exapanded_data
    GROUP BY 
	metric_id , entity_id , pod_name;`, gp.GetTable())

	return queryString
}
