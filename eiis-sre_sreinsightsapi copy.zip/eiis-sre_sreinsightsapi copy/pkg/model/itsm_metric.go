package model

import (
	"github.aexp.com/amex-eng/go-paved-road/pkg/entity"
)

type ItsmMetric struct {
	Type       string                        `json:"type,omitempty"`
	MetricData []entity.NonMetricQueryResult `json:"metric_agg,omitempty"`
}

type ItsmMetricRepository interface {
	GetItsmMetric() (ItsmMetric, error)
	GetItsmMetricJson(graphRequest *GraphRequest) (ItsmMetric, error)
	//GetItsmMetricMetric(graphRequest *GraphRequest) (ItsmMetric, error)
}
