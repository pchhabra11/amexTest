package model

import (
	"encoding/json"
	"fmt"
	"strings"

	"github.aexp.com/amex-eng/go-paved-road/pkg/entity"
	"github.com/google/uuid"
)

type GraphRequest struct {
	Type             string          `json:"type"`
	Interval         string          `json:"interval"`
	After            int64           `json:"after"`
	Before           int64           `json:"before"`
	TimeRange        string          `json:"time_range"`
	EntityId         []GraphEntityId `json:"entity_ids"`
	TimeStamp        int64           `json:"time_stamp,omitempty"`
	CurrentTimestamp int64           `json:"currenttimestamp,omitempty"`
	ReqData          json.RawMessage `json:"req_data,omitempty"`
	SortFlag         string          `json:"sort_flag,omitempty"`
	SortValue        string          `json:"sort_value,omitempty"`
}

type GraphEntityId struct {
	Id        uuid.UUID   `json:"id"`
	MetricIds []uuid.UUID `json:"metric_ids"`
}

func (gp *GraphRequest) GetModel() interface{} {

	switch gp.Interval {
	case "5m":
		return &entity.MetricsAggregatedPerFiveMinute{}
	case "10m":
		return &entity.MetricsAggregatedPerTenMinute{}
	case "15m":
		return &entity.MetricsAggregatedPerFifteenMinute{}
	case "30m":
		return &entity.MetricsAggregatedPerThirtyMinute{}
	case "1h":
		return &entity.MetricsAggregatedPerHour{}
	default:
		return &entity.MetricsAggregatedPerMinute{}
	}
}

func (gp *GraphRequest) GetTable() string {

	tableName := "metrics_aggregated_per_minute"
	switch gp.Interval {
	case "5m":
		tableName = "metrics_aggregated_per_5_minute"
	case "10m":
		tableName = "metrics_aggregated_per_10_minute"
	case "15m":
		tableName = "metrics_aggregated_per_15_minute"
	case "30m":
		tableName = "metrics_aggregated_per_30_minute"
	case "1h", "1d":
		tableName = "metrics_aggregated_per_hour"
	default:
		tableName = "metrics_aggregated_per_minute"
	}

	return tableName
}

func (gp *GraphRequest) GetTableInterval() string {

	interval := "1"
	switch gp.Interval {
	case "5m":
		interval = "5"
	case "10m":
		interval = "10"
	case "15m":
		interval = "15"
	case "30m":
		interval = "30"
	case "1h", "1d":
		interval = "60"
	default:
		interval = "1"
	}

	return interval
}

func (gp *GraphRequest) GetQueryString() string {

	queryString := fmt.Sprintf(`SELECT 
	entity_id,
	metric_id,
	aggregate_interval_start , aggregate_interval_end,
	avg_value, min_value, max_value,
	count, oldest_value, latest_value,
	trend, is_processed,  inserted_at,
	total_value
	FROM %s 
	WHERE
		entity_id in (?) and 
		metric_id in (?) and 
		aggregate_interval_start between  to_timestamp(?) and  to_timestamp(?)  
	ORDER BY aggregate_interval_start asc `, gp.GetTable())
	return queryString
}

func (gp *GraphRequest) GetQueryTableString() string {

	queryString := fmt.Sprintf(`SELECT  
	entity_id, 
	metric_id, 
	(array_agg(aggregate_interval_start))[1] as aggregate_interval_start, 
	(array_agg(aggregate_interval_end))[1] as aggregate_interval_end, 
	avg(avg_value) as avg_value, 
	min(min_value) as min_value, 
	max(max_value) as max_value, 
	-- (array_agg(count))[1] as count, 
	-- (array_agg(oldest_value))[1] as oldest_value, 
	-- (array_agg(trend))[1] as trend, 
	-- (array_agg(is_processed))[1] as is_processed, 
	-- (array_agg(inserted_at))[1] as inserted_at,
	sum(count) as count,
	(array_agg(oldest_value ORDER BY aggregate_interval_start))[1] as oldest_value,
    (array_agg(avg_value ORDER BY aggregate_interval_start))[count(*)] - (array_agg(avg_value ORDER BY aggregate_interval_start))[1] as trend,
    (array_agg(is_processed ORDER BY is_processed ))[1] as is_processed, 
	(array_agg(inserted_at ORDER BY inserted_at ))[1] as inserted_at,
	sum(total_value) as total_value
FROM 
	%s
WHERE 
	entity_id IN ? and
	metric_id IN ? and 
	aggregate_interval_start 
	between  to_timestamp(?) and  to_timestamp(?)
GROUP BY 
	metric_id , entity_id`, gp.GetTable())
	return queryString
}

func (gp *GraphRequest) GetQueryStringWithFilledData(val string) string {

	queryString := fmt.Sprintf(`WITH CTE AS (
						SELECT 
							t.i::uuid as idmetric,
							t.e::uuid as identity,
							timeseriesdata
						FROM  generate_series(
							to_timestamp(?) ,
							to_timestamp(?) ,
									INTERVAL '%s minute'
								) AS timeseriesdata 
						CROSS  JOIN ( %s ) t(e,i)
				)
				SELECT 
					timeseriesdata AS aggregate_interval_start,
					--entity_id,
					c.idmetric as metric_id,
					c.identity as entity_id,
					--metric_id,
					--aggregate_interval_start , 
					COALESCE ( aggregate_interval_end , timeseriesdata ) as aggregate_interval_end,
					COALESCE (avg_value, 0) as avg_value,
					COALESCE (min_value, 0) as min_value,
					COALESCE (max_value,0) as max_value,
					COALESCE (count, 0) as count,
					COALESCE (oldest_value, 0) as oldest_value,
					COALESCE (latest_value,0) as latest_value ,
					COALESCE (trend, 0) as trend,
					is_processed ,
					COALESCE (inserted_at , timeseriesdata) as inserted_at
				FROM CTE c
				LEFT JOIN
						%s  maggone
				ON ( c.timeseriesdata = maggone.aggregate_interval_start ) 
				WHERE 
								maggone.entity_id in (?) 
						and 
								aggregate_interval_start between  to_timestamp(?) and  to_timestamp(?)  
						and 
								c.idmetric = maggone.metric_id
						or 
								maggone.metric_id IS NULL
				ORDER BY
						c.idmetric desc,
						aggregate_interval_start asc ;`, gp.GetTableInterval(), val, gp.GetTable())
	return queryString
}

func (gp *GraphRequest) GetTableIntervalInt() int64 {

	var interval int64 = 1
	switch gp.Interval {
	case "5m":
		interval = 5
	case "10m":
		interval = 10
	case "15m":
		interval = 15
	case "30m":
		interval = 30
	case "1h", "1d":
		interval = 60
	default:
		interval = 1
	}

	return interval
}

func (gp *GraphRequest) GetIntevalTime(timeStamp int64) int64 {
	intervalDataWork := gp.GetTableIntervalInt() * 60

	return timeStamp - (timeStamp % intervalDataWork) + intervalDataWork
}

func (gp *GraphRequest) GetIntevalTimeBef(timeStamp int64) int64 {

	return timeStamp
	//intervalDataWork := gp.GetTableIntervalInt() * 60

	//return timeStamp - (timeStamp % intervalDataWork) + intervalDataWork
}

func (gp *GraphRequest) GetValuesString(valueData []string) string {

	return fmt.Sprintf(`Values %s`, strings.Join(valueData[:], " , "))
}

func (gp *GraphRequest) GetItsmMetricsString() string {

	queryString := fmt.Sprintf(`
		SELECT 	 
			entity_id,
		 	json_agg(non_metric)  as metric
		FROM 
		(
			SELECT 
					(array_agg(entity_id))[1] AS entity_id ,
					json_build_object(
								'metric_id' , metric_id,
								'non_metric' , json_agg(non_metric)
							) as non_metric
			FROM
				(	
					SELECT 	
						(array_agg(entity_id))[1] AS entity_id , 
						metric_id  , 
						json_build_object(
							'non_metric_id' , non_aggregated_metric_id,
							'tickets_timeline' , json_agg(obj)
						) as non_metric
					FROM (
						SELECT 	entity_id, 
								metric_id,  
								non_aggregated_metric_id, 
								id, 
								json_build_object(
									'id', id,
									'non_aggregated_metric_id', non_aggregated_metric_id,
									'description',description,
									'start_time',start_time,
									'end_time',end_time,
									'timestamp',timestamp,
									'updated_timestamp',updated_timestamp,
									'incident_status',incident_status,
									'change_status', change_status
								) as obj   		
						FROM 
							%s 
						WHERE 
							entity_id IN ? and
							metric_id IN ? and 
							start_time 
							between  to_timestamp(?) and  to_timestamp(?)
						ORDER BY 
							id, non_aggregated_metric_id asc
						) tmp
					GROUP by metric_id, non_aggregated_metric_id 
				) tmpm 
			GROUP by metric_id
		) tmpe 
		GROUP by entity_id;`, "non_aggregated_itsm_metrics")
	return queryString
}

func (gp *GraphRequest) GetQueryStringDynamic() string {

	queryString := fmt.Sprintf(`SELECT 
	entity_id,
	metric_id,
	aggregate_interval_start , aggregate_interval_end,
	-- avg_value, min_value, max_value,
	-- count, oldest_value, latest_value,
	-- trend, is_processed,  inserted_at,
	-- total_value , 
	dynamic_value
	FROM %s 
	WHERE
		entity_id in (?) and 
		metric_id in (?) and 
		aggregate_interval_start between  to_timestamp(?) and  to_timestamp(?)  
	ORDER BY aggregate_interval_start asc `, gp.GetTable())
	return queryString
}
