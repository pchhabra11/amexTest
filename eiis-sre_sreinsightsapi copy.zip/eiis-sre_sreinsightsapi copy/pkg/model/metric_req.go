package model

type MetricReq interface{}

type MetricReqRepository interface {
	GetMetricReq() (MetricReq, error)
}
