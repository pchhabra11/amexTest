package entity

import (
	"time"

	"github.com/google/uuid"
)

type MetricsAggregatedPerMinute struct {
	//gorm.Model
	EntityId               uuid.UUID `json:"entity_id"`
	MetricId               uuid.UUID `json:"metric_id"`
	AggregateIntervalStart time.Time `json:"aggregate_interval_start"`
	AggregateIntervalEnd   time.Time `json:"aggregate_interval_end"`
	AvgValue               float32   `json:"avg_value"`
	MinValue               float32   `json:"min_value"`
	MaxValue               float32   `json:"max_value"`
	Count                  int       `json:"count"`
	OldestValue            float32   `json:"oldest_value"`
	LatestValue            float32   `json:"latest_value"`
	Trend                  float32   `json:"trend"`
	TotalValue             float32   `json:"total_value"`
	// TypeTable              string    `gorm:"default:1m"`
}

// TableName overrides the table name
func (m MetricsAggregatedPerMinute) TableName() string {

	return "metrics_aggregated_per_minute"
	// fmt.Println("key for metric", m.TypeTable)
	// switch m.TypeTable {
	// case "5m":
	// 	return "metrics_aggregated_per_5_minute"
	// case "10m":
	// 	return "metrics_aggregated_per_10_minute"
	// case "15m":
	// 	return "metrics_aggregated_per_15_minute"
	// case "30m":
	// 	return "metrics_aggregated_per_30_minute"
	// case "1h":
	// 	return "metrics_aggregated_per_hour"
	// default:
	// 	return "metrics_aggregated_per_minute"
	// }

}

type MetricsAggregatedPerFiveMinute struct {
	MetricsAggregatedPerMinute
}

// TableName overrides the table name
func (MetricsAggregatedPerFiveMinute) TableName() string {
	return "metrics_aggregated_per_5_minute"
}

type MetricsAggregatedPerTenMinute struct {
	MetricsAggregatedPerMinute
}

// TableName overrides the table name
func (MetricsAggregatedPerTenMinute) TableName() string {
	return "metrics_aggregated_per_10_minute"
}

type MetricsAggregatedPerFifteenMinute struct {
	MetricsAggregatedPerMinute
}

// TableName overrides the table name
func (MetricsAggregatedPerFifteenMinute) TableName() string {
	return "metrics_aggregated_per_15_minute"
}

type MetricsAggregatedPerThirtyMinute struct {
	MetricsAggregatedPerMinute
}

// TableName overrides the table name
func (MetricsAggregatedPerThirtyMinute) TableName() string {
	return "metrics_aggregated_per_30_minute"
}

type MetricsAggregatedPerThirtySeconds struct {
	MetricsAggregatedPerMinute
}

// TableName overrides the table name
func (MetricsAggregatedPerThirtySeconds) TableName() string {
	return "metrics_aggregated_per_30_seconds"
}

type MetricsAggregatedPerHour struct {
	MetricsAggregatedPerMinute
}

// TableName overrides the table name
func (MetricsAggregatedPerHour) TableName() string {
	return "metrics_aggregated_per_hour"
}

type MetricsAggregatedPerMinutePod struct {
	MetricsAggregatedPerMinute
	PodName string `json:"pod_name"`
}
