package entity

import (
	"encoding/json"

	"github.com/google/uuid"
)

type LayoutInfo struct {
	LayoutId       int64           `gorm:"primary_key;auto_increment;not_null" json:"layout_id"`
	EntityId       uuid.UUID       `json:"entity_id"`
	EntityName     string          `json:"entity_name"`
	EntityType     string          `json:"entity_type"`
	MetricIds      json.RawMessage `json:"metric_ids"`
	MetricNames    json.RawMessage `json:"metric_names,omitempty"`
	GraphType      string          `json:"graph_type,omitempty"`
	Metadata       json.RawMessage `json:"meta_data"`
	ColClass       string          `json:"col_class,omitempty"`
	GraphSort      string          `json:"graph_sort"`
	ContainerClass string          `json:"container_class,omitempty"`
	ContainerName  string          `json:"container_name,omitempty"`
	ColSpan        string          `json:"col_span"`
	MetricName     string          `json:"metric_name"`
	MetricClass    string          `json:"metric_class,omitempty"`
	DeeplinkId     uuid.UUID       `json:"deeplink_id"`
	PageClass      string          `json:"page_class"`
	PageTitle      string          `json:"page_title"`
	PageSort       string          `json:"page_sort"`
	MetricUnit     string          `json:"metric_unit"`
	ParentEntityId uuid.UUID       `json:"parent_entity_id"`
	//EntityInfo  EntityInfo      `gorm:"foreignKey:EntityId;references:EntityId" json:"entity_info,omitempty"`
}

type LayoutTable interface {
	TableName() string
}

// TableName overrides the table name used by User to `profiles`
func (LayoutInfo) TableName() string {
	return "layout_info"
}

type LayoutInfoExtend struct {
	LayoutInfo
	// Count      int64           `json:"count"`
	ColClasses json.RawMessage `json:"col_classes"`
	LayoutIds  json.RawMessage `json:"layout_ids"`
}

type LayoutInfoDataExtend struct {
	LayoutInfo
	MetricClasses  json.RawMessage `json:"metric_classes"`
	LayoutIds      json.RawMessage `json:"layout_ids"`
	LayoutInfoData json.RawMessage `json:"layout_info_data,omitempty"`
}
