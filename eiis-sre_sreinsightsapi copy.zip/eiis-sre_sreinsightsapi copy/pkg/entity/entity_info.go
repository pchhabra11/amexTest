package entity

import (
	"net/url"

	"github.aexp.com/amex-eng/go-paved-road/pkg/utils"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type CheckLayout struct {
	EntityId    uuid.UUID
	LayoutCount int64
}

type CheckLayoutParent struct {
	EntityId       uuid.UUID
	LayoutCount    int64
	ParentEntityId uuid.UUID
}

type EntityInfo struct {
	//gorm.Model
	EntityId          uuid.UUID    `gorm:"type:uuid;default:uuid_generate_v4();primary_key`
	ParentEntityId    uuid.UUID    `json:"parent_entity_id"`
	EntityName        string       `json:"entity_name"`
	EntityType        string       `json:"entity_type"`
	EntityDescription string       `json:"entity_description"`
	HasChild          bool         `json:"has_child"`
	MetricInfos       []MetricInfo `gorm:"foreignKey:EntityId;references:EntityId"`
	Components        []EntityInfo `gorm:"foreignKey:ParentEntityId;references:EntityId"`
	ParentInfo        []EntityInfo `gorm:"foreignKey:EntityId;references:ParentEntityId"`
	LayoutsInfos      []LayoutInfo `gorm:"foreignKey:EntityId;references:EntityId"`
	//ComponentInfos []ComponentInfo `gorm:"foreignKey:AppId;references:AppId"`
}

type EntiyTable interface {
	TableName() string
}

// TableName overrides the table name used by User to `profiles`
func (EntityInfo) TableName() string {
	return "entity_info"
}

func GetAllEntities(dbCon *gorm.DB) ([]EntityInfo, *utils.AppError) {

	var appInfos []EntityInfo

	result := dbCon.Model(&EntityInfo{}).Find(&appInfos)

	if result.Error != nil {
		return nil, utils.NewNotFoundError("records no found")
	}

	return appInfos, nil
}

func GetAllEntitiesParams(dbCon *gorm.DB, level *url.Values) ([]EntityInfo, *utils.AppError) {

	var appInfos []EntityInfo
	var result *gorm.DB
	//switch level.ke
	switch level.Get("level") {
	//case "no":
	//result = dbCon.Model(&EntityInfo{ParentEntityId: level.Get("app_id")}).Find(&appInfos)
	case "1", "2", "3", "parent_id":

		result = dbCon.Preload("Components").Preload("MetricInfos").Where(&EntityInfo{EntityId: uuid.MustParse(level.Get("app_id"))}).Find(&appInfos)

		// if result.RowsAffected == 0 {
		// 	result = dbCon.Where(&EntityInfo{EntityId: uuid.MustParse(level.Get("app_id"))}).Preload("MetricInfos").Find(&appInfos)
		// }

	// case "2":
	// 	result = dbCon.Model(&EntityInfo{}).Preload("ComponentInfos", "component_type NOT LIKE ? ", "aggregated%").Preload("ComponentInfos.MetricInfos").Find(&appInfos, []string{level.Get("app_id")})
	// case "3":
	// 	result = dbCon.Model(&EntityInfo{}).Preload("ComponentInfos", "component_id = ?", level.Get("component_id")).Preload("ComponentInfos.MetricInfos").Find(&appInfos, []string{level.Get("app_id")})

	default:
		result = dbCon.Preload("Components").Preload("MetricInfos").Find(&appInfos, []string{level.Get("app_id")})

	}

	if result.Error != nil {
		return nil, utils.NewNotFoundError("records no found")
	}

	return appInfos, nil
}
