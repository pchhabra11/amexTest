package entity

import (
	"github.com/google/uuid"
)

type ComponentInfo struct {
	//gorm.Model
	ComponentId          uuid.UUID `gorm:"type:uuid;default:uuid_generate_v4();primary_key`
	ComponentName        string
	ComponentType        string
	ComponentDescription string
	AppId                uuid.UUID
	MetricInfos          []MetricInfo `gorm:"foreignKey:ComponentId;references:ComponentId"`
}

type CompTabler interface {
	TableName() string
}

// TableName overrides the table name used by User to `profiles`
func (ComponentInfo) TableName() string {
	return "component_info"
}
