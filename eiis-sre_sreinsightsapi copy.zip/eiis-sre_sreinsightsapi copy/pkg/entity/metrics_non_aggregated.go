package entity

import (
	"encoding/json"
	"time"

	"github.com/google/uuid"
)

type MetricNonAggregated struct {
	//gorm.Model
	Id                     uuid.UUID       `json:"id"`
	EntityId               uuid.UUID       `json:"entity_id"`
	MetricId               uuid.UUID       `json:"metric_id"`
	AggregateIntervalStart time.Time       `json:"aggregate_interval_start"`
	Metadata               json.RawMessage `json:"metadata"`
}

// TableName overrides the table name
func (m MetricNonAggregated) TableName() string {

	return "non_aggregated_metrics"

}
