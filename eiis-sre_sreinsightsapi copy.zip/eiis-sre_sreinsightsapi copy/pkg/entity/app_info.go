package entity

import (
	"net/url"

	"github.aexp.com/amex-eng/go-paved-road/pkg/utils"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type AppInfo struct {
	//gorm.Model
	AppId          uuid.UUID `gorm:"type:uuid;default:uuid_generate_v4();primary_key`
	AppName        string
	AppType        string
	AppDescription string
	ComponentInfos []ComponentInfo `gorm:"foreignKey:AppId;references:AppId"`
}

type Tabler interface {
	TableName() string
}

// TableName overrides the table name used by User to `profiles`
func (AppInfo) TableName() string {
	return "app_info"
}

func GetAllAppInfos(dbCon *gorm.DB) ([]AppInfo, *utils.AppError) {

	var appInfos []AppInfo

	result := dbCon.Model(&AppInfo{}).Find(&appInfos)

	if result.Error != nil {
		return nil, utils.NewNotFoundError("records no found")
	}

	return appInfos, nil
}

func GetAllAppInfosParams(dbCon *gorm.DB, level *url.Values) ([]AppInfo, *utils.AppError) {

	var appInfos []AppInfo
	var result *gorm.DB
	//switch level.ke
	switch level.Get("level") {
	case "no":
		result = dbCon.Model(&AppInfo{}).Preload("ComponentInfos", "component_type LIKE ? ", "aggregated%").Find(&appInfos, []string{level.Get("app_id")})
	case "1":
		result = dbCon.Model(&AppInfo{}).Preload("ComponentInfos", "component_type LIKE ? ", "aggregated%").Preload("ComponentInfos.MetricInfos").Find(&appInfos, []string{level.Get("app_id")})
	case "2":
		result = dbCon.Model(&AppInfo{}).Preload("ComponentInfos", "component_type NOT LIKE ? ", "aggregated%").Preload("ComponentInfos.MetricInfos").Find(&appInfos, []string{level.Get("app_id")})
	case "3":
		result = dbCon.Model(&AppInfo{}).Preload("ComponentInfos", "component_id = ?", level.Get("component_id")).Preload("ComponentInfos.MetricInfos").Find(&appInfos, []string{level.Get("app_id")})

		// for i, metric := range appInfos[0].ComponentInfos[0].MetricInfos {

		// 	//var metricLay []MetricLayout
		// 	var graphType string
		// 	switch metric.MetricName {
		// 	case "CPUUsage":

		// 		graphType = "gauge,singleLine"

		// 	case "MemoryUsage":

		// 		graphType = "gauge,singleLine"

		// 	case "DiskIO":

		// 		graphType = "gauge,singleLine"

		// 	case "Latency":

		// 		graphType = "gauge"

		// 	case "Traffic":

		// 		graphType = "singleLine"

		// 	case "Error":

		// 		graphType = "singleLine"

		// 	default:

		// 		graphType = ""
		// 		//metricLay = make([]MetricLayout, 0)
		// 	}

		// 	//metric.MetricType = metricLay
		// 	//metricLay
		// 	//appInfos[0].ComponentInfos[0].MetricInfos[i].MetricType = graphType

		// }

	default:
		result = dbCon.Find(&appInfos)

	}

	if result.Error != nil {
		return nil, utils.NewNotFoundError("records no found")
	}

	return appInfos, nil
}
