package entity

import (
	"time"

	"github.com/google/uuid"
)

type Metric struct {
	//gorm.Model
	ID          uint
	MetricId    uuid.UUID
	AppId       uuid.UUID
	ComponentId uuid.UUID
	Value       string
	Timestamp   time.Time
	IsProcessed bool
}

// type MetricinfoTabler interface {
// 	TableName() string
// }

// // TableName overrides the table name
// func (MetricInfo) TableName() string {
// 	return "metric_info"
// }
