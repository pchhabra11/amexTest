package entity

import (
	"encoding/json"

	"github.com/google/uuid"
)

type MetricLayoutInfo struct {
	LayoutId       int64           `json:"layout_id,omitempty"`
	EntityId       string          `json:"entity_id"`
	EntityName     string          `json:"entity_name"`
	EntityType     string          `json:"entity_type"`
	MetricIds      json.RawMessage `json:"metric_ids"`
	MetricNames    json.RawMessage `json:"metric_names,omitempty"`
	GraphType      string          `json:"graph_type,omitempty"`
	Metadata       json.RawMessage `json:"meta_data"`
	ColClass       string          `json:"col_class,omitempty"`
	GraphSort      string          `json:"graph_sort"`
	ContainerClass string          `json:"container_class,omitempty"`
	ContainerName  string          `json:"container_name,omitempty"`
	ColSpan        string          `json:"col_span"`
	MetricName     string          `json:"metric_name"`
	MetricClass    string          `json:"metric_class,omitempty"`
	DeeplinkId     uuid.UUID       `json:"deeplink_id"`
	PageClass      string          `json:"page_class"`
	PageTitle      string          `json:"page_title"`
	PageSort       string          `json:"page_sort"`
	MetricUnit     string          `json:"metric_unit"`
	ParentEntityId uuid.UUID       `json:"parent_entity_id"`
	MetricType     json.RawMessage `json:"metric_type,omitempty"`
	Sorts          string          `json:"sorts,omitempty"`
	HasChild       bool            `json:"has_child,omitempty"`
	MetricId       string          `json:"metric_id,omitempty"`
	MinThreshold   *int            `json:"min_threshold,omitempty"`
	MaxThreshold   *int            `json:"max_threshold,omitempty"`
}

type GraphTypeInfo struct {
	Type           string `json:"type"`
	Sort           string `json:"sort"`
	Title          string `json:"title"`
	ContainerClass string `json:"container_class"`
	ContainerName  string `json:"container_name"`
	MetricClass    string `json:"metric_class"`
	DataType       string `json:"data_type"`
	FetchType      string `json:"fetch_type"`
	ColSpan        string `json:"col_span"`
	PageClass      string `json:"page_class"`
	PageTitle      string `json:"page_title"`
	PageSort       string `json:"page_sort"`
	IsCollapsible  bool   `json:"is_collapsible"`
}

type MetricInfo struct {
	//gorm.Model
	EntityId          uuid.UUID
	MetricId          uuid.UUID
	MetricName        string
	MetricDescription string
	MetricUnit        string `json:"metric_unit"`
	MetricSource      string
	MetricType        JSON                   `sql:"type:jsonb"` //[]MetricLayout `gorm:"type:bytes;serializer:gob"`
	LayoutInfo        map[string]interface{} `gorm:"serializer:json"`
	EntityInfoDetail  EntityInfo             `gorm:"foreignKey:EntityId;references:EntityId"`
}

type LayoutInfoMetric struct {
	Type    string `json:"type"`
	Count   int    `json:"count"`
	Col     int    `json:"col"`
	ColType string `json:"coltype"`
	Split   int    `json:"split"`
}

type MetricLayout struct {
	Level string
	Graph []GraphLayout
	Table []TableLayout
}

type GraphLayout struct {
	GraphType string
	SortBy    int
}

type TableLayout struct {
	TableColumn string
	Column      string
	SortBy      int
}

type MetricinfoTabler interface {
	TableName() string
}

// TableName overrides the table name
func (MetricInfo) TableName() string {
	return "metric_info"
}
