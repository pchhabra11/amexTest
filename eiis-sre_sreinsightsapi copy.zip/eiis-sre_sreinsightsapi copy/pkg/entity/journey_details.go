package entity

import (
	"encoding/json"

	"github.com/google/uuid"
)

type JourneyItsmDetailsRes struct {
	JourneyId         uuid.UUID       `json:"journey_id"`
	StartDate         string          `json:"start_date"`
	EndDate           string          `json:"end_date"`
	ChangeNumber      string          `json:"change_number"`
	ChangeDescription string          `json:"change_description"`
	ItsmMetaData      json.RawMessage `gorm:"column:itsm_metadata_aggregated" json:"itsm_metadata_aggregated"`
}

type JourneyParams struct {
	JourneyId string
	Offset    int
	Limit     int
	StartDate string
	EndDate   string
}

type JourneyListRes struct {
	JourneyId   uuid.UUID `json:"journey_id"`
	JourneyName string    `json:"journey_name"`
}
