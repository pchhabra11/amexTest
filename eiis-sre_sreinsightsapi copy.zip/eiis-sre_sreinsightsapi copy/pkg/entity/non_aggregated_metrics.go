package entity

import (
	"encoding/json"
	"time"

	"github.com/google/uuid"
)

type NonAggregatedMetrics struct {
	//gorm.Model
	Id                    int64     `json:"id"`
	NonAggregatedMetricId string    `json:"non_aggregated_metric_id"`
	EntityId              uuid.UUID `json:"entity_id"`
	MetricId              uuid.UUID `json:"metric_id"`
	Description           string    `json:"description"`
	StartTime             time.Time `json:"start_time"`
	EndTime               time.Time `json:"end_time"`
	Timestamp             time.Time `json:"timestamp"`
	UpdatedTimestamp      time.Time `json:"updated_timestamp"`
	IncidentStatus        time.Time `json:"incident_status"`
	ChangeStatus          string    `json:"change_status"`
}

type NonMetricQueryResult struct {
	EntityId uuid.UUID       `json:"entity_id"`
	Metric   json.RawMessage `json:"metric"`
}

// TableName overrides the table name
func (m NonAggregatedMetrics) TableName() string {

	return "non_aggregated_itsm_metrics"

}
