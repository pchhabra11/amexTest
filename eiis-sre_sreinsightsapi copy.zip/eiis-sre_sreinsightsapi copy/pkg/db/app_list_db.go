package db

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/url"
	"slices"
	"strings"

	"github.aexp.com/amex-eng/go-paved-road/pkg/entity"
	"github.aexp.com/amex-eng/go-paved-road/pkg/logging"
	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
	"gorm.io/gorm"
)

type ApplistRepositoryDb struct {
	appinfo model.Applist
	getGorm *gorm.DB
}

func (s ApplistRepositoryDb) FindAllComp() (model.Applist, error) {

	var entityList model.Applist

	entityList, err := getApplistData(s.getGorm)

	if err != nil {
		logging.Errorf("Error %s", err.Error())
	}

	return entityList, nil

	//return s.appinfo, nil
}

func (s ApplistRepositoryDb) FindServiceMapData(serviceId string) ([]model.ServiceInfoRes, error) {

	var serviceInfoRes []model.ServiceInfoRes

	whereclause := `WHERE parent_service_id = '00000000-0000-0000-0000-000000000000'`

	if serviceId != "" {
		whereclause = `WHERE service_id = ?`
	}

	query := fmt.Sprintf(`WITH RECURSIVE service_hierarchy AS (
		SELECT
		  service_id,
		  service_name,
		  service_description,
		  service_type,
		  entity_ref_id,
		  1 AS depth,
		  ARRAY[service_id]::uuid[] AS path,
		  ARRAY[service_name]::varchar[] AS service_names
		FROM service_info %s 
	UNION ALL
		SELECT DISTINCT ON (si.service_id, si.parent_service_id)
		  si.service_id,
		  si.service_name,
		  si.service_description,
		  si.service_type,
		  si.entity_ref_id,
		  sh.depth + 1,
		  sh.path || si.service_id,
		  sh.service_names || si.service_name
		FROM service_info si
		JOIN service_hierarchy sh ON si.parent_service_id = sh.service_id
	  )
	  SELECT * FROM service_hierarchy;`, whereclause)

	if serviceId != "" {
		if err := s.getGorm.Raw(query, serviceId).Scan(&serviceInfoRes).Error; err != nil {
			return nil, err
		}
	} else {
		if err := s.getGorm.Raw(query).Scan(&serviceInfoRes).Error; err != nil {
			return nil, err
		}
	}
	if len(serviceInfoRes) == 0 {
		return nil, errors.New("record not found")
	}
	return serviceInfoRes, nil
}

func (s AppComponentRepositoryDb) GetMetricsMetadata(requested_entity_id string, entity_types []string) ([]model.MetricMetadataResponse, error) {

	metricMetadataRes := CreateJSON(s, requested_entity_id, entity_types)

	return metricMetadataRes, nil
}

func CreateJSON(s AppComponentRepositoryDb, deeplink string, entity_types []string) []model.MetricMetadataResponse {

	urlValues := url.Values{}
	urlValues.Add("component_id", deeplink)

	lay, err := s.FindAllAppComp(&urlValues)

	if err != nil {
		logging.Errorf("Here in making req in func:%v", err)
	}

	var output []model.MetricMetadataResponse

	for plIdx := range lay.PageLayout {

		// fmt.Println("lay.Data.PageLayout[plIdx].Title", lay.PageLayout[plIdx].PageTitle)
		// fmt.Println("lay.Data.PageLayout[plIdx].Title", lay.Data.PageLayout[plIdx].Title)

		for lytIdx := range lay.PageLayout[plIdx].Layout {

			for cldrnIdx := range lay.PageLayout[plIdx].Layout[lytIdx].NewChildren {
				op := model.MetricMetadataResponse{
					ParentEntityID: deeplink,
					ServiceName:    lay.PageLayout[plIdx].Layout[lytIdx].Title,
				}
				metricnames := []string{}
				entitynames := []string{}
				deeplinks := []string{}

				for lytIdx2 := range lay.PageLayout[plIdx].Layout[lytIdx].NewChildren[cldrnIdx].LayoutInfo {

					children_local := []model.MetricMetadataResponse{}

					op.EntityID = lay.PageLayout[plIdx].Layout[lytIdx].NewChildren[cldrnIdx].LayoutInfo[lytIdx2].EntityId.String()

					var metricIds []string

					err := json.Unmarshal(lay.PageLayout[plIdx].Layout[lytIdx].NewChildren[cldrnIdx].LayoutInfo[lytIdx2].MetricIds, &metricIds)
					if err != nil {
						logging.Errorf("Here in unmarshall e in func: %v", err)
					}

					op.MetricIds = append(op.MetricIds, metricIds...)
					// op.MetricIds = append(op.MetricIds, string(lay.PageLayout[plIdx].Layout[lytIdx].NewChildren[cldrnIdx].LayoutInfo[lytIdx2].MetricIds))

					if !slices.Contains(entitynames, lay.PageLayout[plIdx].Layout[lytIdx].NewChildren[cldrnIdx].LayoutInfo[lytIdx2].EntityName) {
						entitynames = append(entitynames, lay.PageLayout[plIdx].Layout[lytIdx].NewChildren[cldrnIdx].LayoutInfo[lytIdx2].EntityName)
					}
					metricnames = append(metricnames, lay.PageLayout[plIdx].Layout[lytIdx].NewChildren[cldrnIdx].LayoutInfo[lytIdx2].MetricName)
					deeplinks = append(deeplinks, lay.PageLayout[plIdx].Layout[lytIdx].NewChildren[cldrnIdx].LayoutInfo[lytIdx2].DeeplinkId.String())

					if strings.Contains(strings.ToLower(lay.PageLayout[plIdx].Layout[lytIdx].Title), "itsm") {

						op.EntityType = "ITSM"
					} else if strings.HasPrefix(strings.ToLower(lay.PageLayout[plIdx].PageTitle), "cbis infra") {
						op.EntityType = "TIMS-Infra"
					} else if strings.Contains(strings.ToLower(lay.PageLayout[plIdx].PageTitle), "kubernetes") {
						op.EntityType = "EPaaS-Infra"
					} else {
						op.EntityType = "App"
					}
					if strings.Contains(strings.ToLower(lay.PageLayout[plIdx].Layout[lytIdx].NewChildren[cldrnIdx].LayoutInfo[lytIdx2].MetricName), "avai") && lay.PageLayout[plIdx].Layout[lytIdx].NewChildren[cldrnIdx].LayoutInfo[lytIdx2].DeeplinkId.String() != "00000000-0000-0000-0000-000000000000" {
						for _, v := range CreateJSON(s, lay.PageLayout[plIdx].Layout[lytIdx].NewChildren[cldrnIdx].LayoutInfo[lytIdx2].DeeplinkId.String(), entity_types) {
							children_local = append(children_local, v)
						}
						// children_local = append(children_local, CreateJSON(lay.Data.PageLayout[plIdx].Layout[lytIdx].Children[cldrnIdx].LayoutInfo[lytIdx2].DeeplinkID, entity_types)...)
						op.Children = append(op.Children, children_local)

					}

				}
				op.DeeplinkIDs = deeplinks
				op.MetricNames = metricnames
				op.EntityNames = entitynames

				// logging.Infof("Entity_types= ", entity_types)
				// logging.Infof("op.EntityType=", op.EntityType)

				if slices.Contains(entity_types, op.EntityType) {
					// logging.Infof("here", op.EntityType)
					output = append(output, op)

				}

			}
		}
	}
	// fmt.Println("output======", output)

	return output
}

func (s ApplistRepositoryDb) CheckServiceMapByServiceId(serviceId string) (*model.ServiceInfo, error) {
	var serviceInfo model.ServiceInfo

	if err := s.getGorm.Model(&serviceInfo).Where("service_id = ?", serviceId).Find(&serviceInfo).Error; err != nil {
		logging.Errorf("errrrr %v", err)
		return nil, err
	}
	if serviceInfo == (model.ServiceInfo{}) {
		return nil, errors.New("record not found")
	}

	return &serviceInfo, nil
}

func (s ApplistRepositoryDb) FindJourneyDetails(params entity.JourneyParams) ([]entity.JourneyItsmDetailsRes, error) {
	var dateFilter string

	if params.StartDate != "" && params.EndDate != "" {
		dateFilter = fmt.Sprintf(`and start_date between to_timestamp(%s) and to_timestamp(%s)`, params.StartDate, params.EndDate)
	} else {
		if params.StartDate != "" {
			dateFilter = fmt.Sprintf(`and start_date >= to_timestamp(%s)`, params.StartDate)
		}
		if params.EndDate != "" {
			dateFilter = fmt.Sprintf(`and start_date <= to_timestamp(%s)`, params.EndDate)
		}
	}
	var JourneyDetailsRes []entity.JourneyItsmDetailsRes
	offset := (params.Limit * params.Offset) - params.Limit
	query := fmt.Sprintf(`WITH extracted_data AS (
		SELECT 
			journey_id,
			start_date,
			end_date,
			itsm_metadata ->> 'number' AS change_number,
			itsm_metadata ->> 'short_description' AS change_description,
			jsonb_strip_nulls(itsm_metadata - 'number' - 'short_description') AS itsm_metadata_remaining
		FROM journey_itsm_data
		WHERE journey_id='%s' %s
	)
	SELECT
		journey_id,
		start_date,
		end_date,
		change_number,
		change_description,
		jsonb_agg(itsm_metadata_remaining) AS itsm_metadata_aggregated
	FROM
		extracted_data
	GROUP BY
		journey_id,
		start_date,
		end_date,
		change_number,
		change_description
	ORDER BY
		start_date DESC
	LIMIT %d OFFSET %d`, params.JourneyId, dateFilter, params.Limit, offset)

	if err := s.getGorm.Debug().Raw(query).Scan(&JourneyDetailsRes).Error; err != nil {
		return nil, err
	}
	return JourneyDetailsRes, nil
}

func (s ApplistRepositoryDb) FindJourneyList() ([]entity.JourneyListRes, error) {

	var journeyListRes []entity.JourneyListRes
	if err := s.getGorm.Raw("select distinct journey_id,journey_name from journey_carid_mapping").Scan(&journeyListRes).Error; err != nil {
		return nil, err
	}
	return journeyListRes, nil
}

func NewApplistRepositoryDb(gormDb *gorm.DB) ApplistRepositoryDb {

	var entityList model.Applist
	return ApplistRepositoryDb{entityList, gormDb}
}

func getApplistData(getGorm *gorm.DB) (model.Applist, error) {

	var entityList model.Applist
	var entitylistValues model.ApplistValue

	entitylistValues.DefaultVisible = make([]string, 0)
	entitylistValues.Content = make([][]model.ContentApplist, 0)

	var entityInfos []entity.EntityInfo
	//dbCon := getGorm // getGormDB()

	// Todd where parentid null , remove table conditions
	//results := dbCon.Preload("MetricInfos", "metric_type like ? ", "%table%").Where("parent_entity_id is null").Find(&entityInfos)

	if err := getGorm.Preload("LayoutsInfos", "graph_type = ?", "table").Where("parent_entity_id is null").Find(&entityInfos).Error; err != nil {
		// error handling...
		return entityList, err
	}

	//entitylistValues.DefaultVisible

	entitylistValues.DefaultVisible = append(entitylistValues.DefaultVisible, strings.ToLower("SrNo"))
	entitylistValues.Header = append(entitylistValues.Header, model.ApplistHeader{
		ID: strings.ToLower("SrNo"), Header: "SrNo", SubHeader: "",
	})

	entitylistValues.DefaultVisible = append(entitylistValues.DefaultVisible, strings.ToLower("Name"))
	entitylistValues.Header = append(entitylistValues.Header, model.ApplistHeader{
		ID: strings.ToLower("Name"), Header: "Name", SubHeader: "",
	})

	var headerFlag = false

	for i, result := range entityInfos {

		var contentApp = make([]model.ContentApplist, 0)

		//logging.Errorf("result value %v", result)

		contentApp = append(contentApp, model.ContentApplist{Type: "string", Value: fmt.Sprintf("%d", i+1), Redirect: "-"})

		contentApp = append(contentApp, model.ContentApplist{Type: "string", Value: result.EntityName, Redirect: fmt.Sprintf("/%s?component_id=%s", result.EntityId.String(), result.EntityId.String())})

		if len(result.LayoutsInfos) == 0 {
			CreateLayoutInfo(result.EntityId, getGorm)

		} else {
			for _, reMr := range result.LayoutsInfos {

				if !headerFlag {
					entitylistValues.DefaultVisible = append(entitylistValues.DefaultVisible, strings.ToLower(reMr.ColClass))
					entitylistValues.Header = append(entitylistValues.Header, model.ApplistHeader{
						ID: strings.ToLower(reMr.ColClass), Header: reMr.ColClass, SubHeader: "",
					})

				}

				contentApp = append(contentApp, model.ContentApplist{Type: "string", Value: "-", Redirect: "-"})

			}

			headerFlag = true
		}

		entitylistValues.Content = append(entitylistValues.Content, contentApp)

	}
	entityList.Layout = append(entityList.Layout, model.ApplistLayout{
		Type:  "table_app_list",
		Title: "Framework",
		Value: entitylistValues,
	})

	//logging.Errorf("applisy value %v", entityList)

	return entityList, nil
}
