package db

import (
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"math/rand"
	"net/url"
	"time"

	"github.aexp.com/amex-eng/go-paved-road/pkg/entity"
	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type MetricGraphSingleLineRepositoryDb struct {
	metricGraphSingleLine model.MetricGraphSingleLine
	getGorm               *gorm.DB
}

func (s MetricGraphSingleLineRepositoryDb) GetMetricGraphSingleLine(queryValue *url.Values) (model.MetricGraphSingleLine, error) {

	var ycord model.MetricGraphSingleLineY
	var values model.MetricGraphSingleLineValue
	var metricGraphSingleLine model.MetricGraphSingleLine

	var epochtime = time.Now().Unix()

	var timeseries []int64

	ycord = model.MetricGraphSingleLineY{
		Title: "Pod 1",
	}

	for i := 1; i < 12; i++ {

		timese := epochtime + int64(i*10)
		timeseries = append(timeseries, timese)

		randNum := rand.Intn(99-1) + 1

		ycord.Value = append(ycord.Value, randNum)

	}

	var intvetadta = []string{
		"5m",
		"1d",
		"1M",
	}

	values = model.MetricGraphSingleLineValue{
		Unit:            "mm",
		ReloadTime:      30,
		DefaultInterval: "5m",
		TimeStamp:       time.Now().Unix(),
		Intervals:       intvetadta,
		X:               timeseries,
		Y:               ycord,
		Request:         7,
	}

	metricGraphSingleLine = model.MetricGraphSingleLine{
		Type:  "multiLine",
		Title: "Title",
		Value: values,
	}

	return metricGraphSingleLine, nil
}

func NewMetricGraphSingleLineRepositoryDb(gormDb *gorm.DB) MetricGraphSingleLineRepositoryDb {

	content, err := ioutil.ReadFile("./pkg/jsondata/metric_single_line.json")

	if err != nil {
		log.Fatal("json file error", err)
	}

	var metricGraphSingleLine model.MetricGraphSingleLine
	errd := json.Unmarshal(content, &metricGraphSingleLine)

	if errd != nil {
		log.Fatal("json unmarshal error", errd)
	}

	return MetricGraphSingleLineRepositoryDb{metricGraphSingleLine, gormDb}
}

func (s MetricGraphSingleLineRepositoryDb) GetMetricGraphSingleLineJson(graphRequest *model.GraphRequest) (model.MetricGraphSingleLine, error) {

	context, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	dbCon := s.getGorm.WithContext(context)
	metricsIds := make([]uuid.UUID, 0)
	entityIds := make([]uuid.UUID, 0)
	valueData := make([]string, 0)
	for _, layout := range graphRequest.EntityId {

		metricsIds = append(metricsIds, layout.MetricIds...)
		entityIds = append(entityIds, layout.Id)

		for _, metricId := range layout.MetricIds {
			valueData = append(valueData, fmt.Sprintf(`( '%s' , '%s')`, layout.Id.String(), metricId.String()))
		}
	}

	var ycord model.MetricGraphSingleLineY
	var values model.MetricGraphSingleLineValue
	var metricGraphSingleLine model.MetricGraphSingleLine

	var metricsAggregatedPerMinute []entity.MetricsAggregatedPerMinute

	// if resultApp := dbCon.Model(graphRequest.GetModel()).Where("metric_id in ?", metricsIds).Limit(10).Order("aggregate_interval_start asc").Find(&metricsAggregatedPerMinute).Error; resultApp != nil {
	// 	return metricGraphSingleLine, resultApp
	// }

	// if resultApp := dbCon.Raw(graphRequest.GetQueryString(), entityIds, metricsIds, graphRequest.After, graphRequest.Before).Find(&metricsAggregatedPerMinute).Error; resultApp != nil {
	// 	return metricGraphSingleLine, resultApp
	// }

	// if resultApp := dbCon.Raw(graphRequest.GetQueryStringWithFilledData(graphRequest.GetValuesString(valueData)), graphRequest.GetIntevalTime(graphRequest.After), graphRequest.GetIntevalTimeBef(graphRequest.Before), entityIds, graphRequest.After, graphRequest.Before).Find(&metricsAggregatedPerMinute).Error; resultApp != nil {
	// 	return metricGraphSingleLine, resultApp
	// }

	// if resultApp.Error != nil {
	// 	return metricGraphSingleLine, resultApp.Error
	// }

	if resultApp := dbCon.Raw(graphRequest.GetQueryString(), entityIds, metricsIds, graphRequest.After, graphRequest.Before).Find(&metricsAggregatedPerMinute).Error; resultApp != nil {
		return metricGraphSingleLine, resultApp
	}

	var timeseries []int64
	ycord = model.MetricGraphSingleLineY{
		Title: "",
	}

	for _, data := range metricsAggregatedPerMinute {
		//log.Printf("data index %d , time data %v , data with %v", i, data.AggregateIntervalStart, data.AvgValue)
		timeseries = append(timeseries, data.AggregateIntervalStart.UTC().UnixMilli())
		ycord.Value = append(ycord.Value, int(data.AvgValue))
	}

	var intvetadta = []string{
		"5m",
		"1d",
		"1M",
	}

	values = model.MetricGraphSingleLineValue{
		Unit:            "mm",
		ReloadTime:      30,
		DefaultInterval: "1m",
		TimeStamp:       time.Now().Unix(),
		Intervals:       intvetadta,
		X:               timeseries,
		Y:               ycord,
		Request:         7,
	}

	metricGraphSingleLine = model.MetricGraphSingleLine{
		Type:  "entity-singleline",
		Title: "Title",
		Value: values,
	}

	metricGraphSingleLine.MetricIds = metricsIds
	metricGraphSingleLine.MetricData = metricsAggregatedPerMinute

	return metricGraphSingleLine, nil

}
