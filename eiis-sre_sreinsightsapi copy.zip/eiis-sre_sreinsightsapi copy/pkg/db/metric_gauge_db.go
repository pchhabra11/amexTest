package db

import (
	"context"
	"encoding/json"
	"fmt"
	"math/rand"
	"net/url"
	"strings"
	"time"

	"github.aexp.com/amex-eng/go-paved-road/pkg/entity"
	"github.aexp.com/amex-eng/go-paved-road/pkg/logging"
	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type MetricGaugeRepositoryDb struct {
	metricGauge model.MetricGauge
	getGorm     *gorm.DB
}

func (s MetricGaugeRepositoryDb) GetMetricGauge(queryValue *url.Values) (model.MetricGauge, error) {

	context, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	dbCon := s.getGorm.WithContext(context)
	// dbCon := s.getGorm //getGormDB()

	// var layoutId = queryValue.Get("graph_key")
	// var layoutData []entity.LayoutInfo
	// current := 0
	// subtitle := fmt.Sprintf("%d of 100 core used", current)
	// max := 0

	// var metricsAggregatedPerMinute entity.MetricsAggregatedPerMinute
	//var appType []uuid.UUID

	// resultLayout := dbCon.Where(&entity.LayoutInfo{ParentLayoutId: uuid.MustParse(layoutId)}).Find(&layoutData)
	// //resultMetrix := dbCon.Model(&entity.EntityInfo{}).Where(&entity.EntityInfo{ParentEntityId: uuid.MustParse(component_id)}).Distinct().Pluck("EntityType", &appType)

	// if resultLayout.Error == nil {
	// 	for _, layout := range layoutData {
	// 		if layout.DataType == "current" {
	// 			resultApp := dbCon.Model(&entity.MetricsAggregatedPerMinute{}).Where(&entity.MetricsAggregatedPerMinute{MetricId: layout.MetricId}).Last(&metricsAggregatedPerMinute)

	// 			if resultApp.Error == nil {
	// 				current = int(metricsAggregatedPerMinute.AvgValue)
	// 			}
	// 		}

	// 		if layout.DataType == "total" {
	// 			resultApp := dbCon.Model(&entity.MetricsAggregatedPerMinute{}).Where(&entity.MetricsAggregatedPerMinute{MetricId: layout.MetricId}).Last(&metricsAggregatedPerMinute)

	// 			if resultApp.Error == nil {
	// 				max = 100 + int(metricsAggregatedPerMinute.LatestValue)

	// 				subtitle = fmt.Sprintf("%d of %d core used", current, max)
	// 			}
	// 		}
	// 	}
	// }

	//logging.Errorf("current %d and sunbi %s", current, subtitle)
	// metricGauge := model.MetricGauge{
	// 	Type: "gauge", Title: "CPU Usage", Value: model.MetricGaugeValue{
	// 		Title:    "CPU Usage",
	// 		SubTitle: subtitle,
	// 		Min:      0,
	// 		Max:      max,
	// 		Current:  current,
	// 		Request:  7,
	// 	},
	// }

	//return metricGauge, nil

	current := rand.Intn(99-1) + 1
	subtitle := fmt.Sprintf("%d of 100 core used", current)
	//logging.Errorf("current %d and sunbi %s", current, subtitle)
	metricGauge := model.MetricGauge{
		Type: "metric-gauge", Title: "CPU Usage", Value: model.MetricGaugeValue{
			Title:    "CPU Usage",
			SubTitle: subtitle,
			Min:      0,
			Max:      100,
			Current:  current,
			Request:  7,
		},
	}

	var layoutData []entity.LayoutInfo

	graph_key := queryValue.Get("graph_key")

	idSplit := strings.Split(graph_key, "-")

	if err := dbCon.Where("layout_id  = ?", idSplit[2]).Find(&layoutData).Error; err != nil {
		logging.Errorf("Error found %v", err)
		return metricGauge, err
	}

	metricsIds := make([]uuid.UUID, 0)
	for _, layout := range layoutData {

		Ids := make([]uuid.UUID, 0)
		if err := json.Unmarshal(layout.MetricIds, &Ids); err != nil {
			logging.Errorf("Error found %v", err)
		}

		metricsIds = append(metricsIds, Ids...)
	}

	var metricsAggregatedPerMinutes []entity.MetricsAggregatedPerMinute

	if err := dbCon.Raw(` SELECT metrics_aggregated_per_minute.* 
							FROM metrics_aggregated_per_minute , 
				(SELECT entity_id, metric_id , max(aggregate_interval_start) as ains 
					FROM "metrics_aggregated_per_minute" WHERE metric_id IN ? 
					GROUP BY metric_id , entity_id) max_metricagg 
					WHERE  metrics_aggregated_per_minute.metric_id = max_metricagg.metric_id 
							and metrics_aggregated_per_minute.entity_id = max_metricagg.entity_id
							and metrics_aggregated_per_minute.aggregate_interval_start = max_metricagg.ains;`, metricsIds).Find(&metricsAggregatedPerMinutes).Error; err != nil {
		return metricGauge, err
	}

	metricGauge.MetricIds = metricsIds
	metricGauge.MetricData = metricsAggregatedPerMinutes

	return metricGauge, nil
}

func NewMetricGaugeRepositoryDb(gormDb *gorm.DB) MetricGaugeRepositoryDb {

	var metricGauge model.MetricGauge

	return MetricGaugeRepositoryDb{metricGauge, gormDb}
}

func (s MetricGaugeRepositoryDb) GetMetricGaugeJson(gaugeRequest *model.GraphRequest) (model.MetricGauge, error) {

	context, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	dbCon := s.getGorm.WithContext(context)

	metricGauge := model.MetricGauge{}
	//dbCon := s.getGorm //getGormDB()
	metricsIds := make([]uuid.UUID, 0)
	entityIds := make([]uuid.UUID, 0)
	for _, layout := range gaugeRequest.EntityId {

		metricsIds = append(metricsIds, layout.MetricIds...)
		entityIds = append(entityIds, layout.Id)
	}

	var metricsAggregatedPerMinutes []entity.MetricsAggregatedPerMinute

	if err := dbCon.Raw(gaugeRequest.GetQueryTableString(), entityIds, metricsIds, gaugeRequest.After, gaugeRequest.Before).Find(&metricsAggregatedPerMinutes).Error; err != nil {
		return metricGauge, err
	}

	metricGauge.MetricIds = metricsIds
	metricGauge.MetricData = metricsAggregatedPerMinutes

	//logging.Errorf("current %d and sunbi %s", current, subtitle)

	return metricGauge, nil
}
