package db

import (
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"math/rand"
	"time"

	"github.aexp.com/amex-eng/go-paved-road/pkg/entity"
	"github.aexp.com/amex-eng/go-paved-road/pkg/logging"
	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type MetricGraphMultiLineRepositoryDb struct {
	metricGraphMultiLine model.MetricGraphMultiLine
	getGorm              *gorm.DB
}

func (s MetricGraphMultiLineRepositoryDb) GetMetricGraphMultiLine() (model.MetricGraphMultiLine, error) {

	var ycord []model.MetricGraphMultiLineY
	var values model.MetricGraphMultiLineValue
	var metricGraphMultiLine model.MetricGraphMultiLine

	var epochtime = time.Now().Unix()

	var timeseries []int64

	for j := 1; j < 6; j++ {

		ycord = append(ycord, model.MetricGraphMultiLineY{
			Title: fmt.Sprintf("Pod %d", j),
		})

	}

	for i := 1; i < 12; i++ {

		timese := epochtime + int64(i*10)
		timeseries = append(timeseries, timese)

		for k := 0; k < 5; k++ {
			randNum := rand.Intn(99-1) + 1

			ycord[k].Value = append(ycord[k].Value, randNum)
		}

	}

	var intvetadta = []string{
		"5m",
		"1d",
		"1M",
	}

	values = model.MetricGraphMultiLineValue{
		Unit:            "mm",
		ReloadTime:      30,
		DefaultInterval: "5m",
		TimeStamp:       time.Now().Unix(),
		Intervals:       intvetadta,
		X:               timeseries,
		Y:               ycord,
		Request:         7,
	}

	metricGraphMultiLine = model.MetricGraphMultiLine{
		Type:  "multiLine",
		Title: "Title",
		Value: values,
	}

	return metricGraphMultiLine, nil
}

func NewMetricGraphMultiLineRepositoryDb(gormDb *gorm.DB) MetricGraphMultiLineRepositoryDb {

	content, err := ioutil.ReadFile("./pkg/jsondata/metric_multi_line.json")

	if err != nil {
		log.Fatal("json file error", err)
	}

	var metricGraphMultiLine model.MetricGraphMultiLine
	errd := json.Unmarshal(content, &metricGraphMultiLine)

	if errd != nil {
		log.Fatal("json unmarshal error", errd)
	}

	return MetricGraphMultiLineRepositoryDb{metricGraphMultiLine, gormDb}
}

func (s MetricGraphMultiLineRepositoryDb) GetMetricGraphMultiLineJson(graphRequest *model.GraphRequest) (model.MetricGraphMultiLine, error) {

	// dbCon := s.getGorm
	context, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	dbCon := s.getGorm.WithContext(context)
	metricsIds := make([]uuid.UUID, 0)
	entityIds := make([]uuid.UUID, 0)
	valueData := make([]string, 0)
	for _, layout := range graphRequest.EntityId {

		metricsIds = append(metricsIds, layout.MetricIds...)
		entityIds = append(entityIds, layout.Id)

		for _, metricId := range layout.MetricIds {
			valueData = append(valueData, fmt.Sprintf(`( '%s' , '%s')`, layout.Id.String(), metricId.String()))
		}
	}

	//var ycord model.MetricGraphMultiLineY
	var metricGraphMultiLine model.MetricGraphMultiLine

	var metricsAggregatedPerMinute []entity.MetricsAggregatedPerMinute

	// if resultApp := dbCon.Model(graphRequest.GetModel()).Where("metric_id in ? and aggregate_interval_start between  to_timestamp(?) and  to_timestamp(?) ", metricsIds, graphRequest.After, graphRequest.Before).Order("aggregate_interval_start asc").Find(&metricsAggregatedPerMinute).Error; resultApp != nil {
	// 	return metricGraphMultiLine, resultApp
	// }

	// if resultApp := dbCon.Raw(graphRequest.GetQueryString(), entityIds, metricsIds, graphRequest.After, graphRequest.Before).Find(&metricsAggregatedPerMinute).Error; resultApp != nil {
	// 	return metricGraphMultiLine, resultApp
	// }

	// if resultApp.Error != nil {

	// 	return metricGraphMultiLine, resultApp.Error
	// }

	// var timeseries []int64
	// ycord = model.MetricGraphMultiLineY{
	// 	Title: "",
	// }

	// for _, data := range metricsAggregatedPerMinute {
	// 	//logging.Errorf("data index %d , time data %v , data with %v", i, data.AggregateIntervalStart, data.AvgValue)
	// 	timeseries = append(timeseries, data.AggregateIntervalStart.UTC().UnixMilli())
	// 	ycord.Value = append(ycord.Value, int(data.AvgValue))
	// }

	// each minute point 10 nov
	// if resultApp := dbCon.Raw(graphRequest.GetQueryStringWithFilledData(graphRequest.GetValuesString(valueData)), graphRequest.GetIntevalTime(graphRequest.After), graphRequest.GetIntevalTimeBef(graphRequest.Before), entityIds, graphRequest.After, graphRequest.Before).Find(&metricsAggregatedPerMinute).Error; resultApp != nil {
	// 	return metricGraphMultiLine, resultApp
	// }

	if resultApp := dbCon.Raw(graphRequest.GetQueryString(), entityIds, metricsIds, graphRequest.After, graphRequest.Before).Find(&metricsAggregatedPerMinute).Error; resultApp != nil {
		return metricGraphMultiLine, resultApp
	}

	metricGraphMultiLine = model.MetricGraphMultiLine{
		Type: "entity-multiline",
	}

	metricGraphMultiLine.MetricIds = metricsIds
	metricGraphMultiLine.MetricData = metricsAggregatedPerMinute

	return metricGraphMultiLine, nil

}

func (s MetricGraphMultiLineRepositoryDb) GetMetricGraphMultiLineMetric(graphRequest *model.GraphRequest) (model.MetricGraphMultiLine, error) {

	// dbCon := s.getGorm
	context, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	dbCon := s.getGorm.WithContext(context)
	metricsIds := make([]uuid.UUID, 0)
	entityIds := make([]uuid.UUID, 0)
	valueData := make([]string, 0)
	for _, layout := range graphRequest.EntityId {

		metricsIds = append(metricsIds, layout.MetricIds...)
		entityIds = append(entityIds, layout.Id)

		for _, metricId := range layout.MetricIds {
			valueData = append(valueData, fmt.Sprintf(`( '%s' , '%s')`, layout.Id.String(), metricId.String()))
		}
	}

	//valueQueryString := graphRequest.GetValuesString(valueData)

	var metricGraphMultiLine model.MetricGraphMultiLine

	var metricsAggregatedPerMinute []entity.MetricsAggregatedPerMinute

	// tableName := graphRequest.GetTable()

	// if resultApp := dbCon.Raw(`SELECT * FROM ? WHERE metric_id in (?) and aggregate_interval_start between  to_timestamp(?) and  to_timestamp(?)  ORDER BY aggregate_interval_start asc `, tableName, metricsIds, graphRequest.After, graphRequest.Before).Find(&metricsAggregatedPerMinute).Error; resultApp != nil {
	// 	return metricGraphMultiLine, resultApp
	// }

	// if resultApp := dbCon.Model(graphRequest.GetModel()).Where("metric_id in ? and aggregate_interval_start between  to_timestamp(?) and  to_timestamp(?) ", metricsIds, graphRequest.After, graphRequest.Before).Order("aggregate_interval_start asc").Find(&metricsAggregatedPerMinute).Error; resultApp != nil {
	// 	return metricGraphMultiLine, resultApp
	// }

	// if resultApp.Error != nil {

	// 	return metricGraphMultiLine, resultApp.Error
	// }

	// if resultApp := dbCon.Raw(graphRequest.GetQueryString(), entityIds, metricsIds, graphRequest.After, graphRequest.Before).Find(&metricsAggregatedPerMinute).Error; resultApp != nil {
	// 	return metricGraphMultiLine, resultApp
	// }

	// intervalData, err := strconv.ParseInt(graphRequest.GetTableInterval(), 10, 64)
	// if err != nil {
	// 	logging.Errorf("Error : %s", err.Error())
	// }

	// logging.Errorf("%T, %v\n", intervalData, intervalData)

	//intervalDataWork := intervalData * 60
	//newAfter := graphRequest.GetIntevalTime(graphRequest.After)   //graphRequest.After - (graphRequest.After % intervalDataWork) + intervalDataWork
	//newBefore := graphRequest.GetIntevalTime(graphRequest.Before) //graphRequest.Before - (graphRequest.Before % intervalDataWork) + intervalDataWork

	// if resultApp := dbCon.Raw(graphRequest.GetQueryStringWithFilledData(valueQueryString), newAfter, newBefore, entityIds, graphRequest.After, graphRequest.Before).Find(&metricsAggregatedPerMinute).Error; resultApp != nil {
	// 	return metricGraphMultiLine, resultApp
	// }

	// comment 10 nov each point
	// if resultApp := dbCon.Raw(graphRequest.GetQueryStringWithFilledData(graphRequest.GetValuesString(valueData)), graphRequest.GetIntevalTime(graphRequest.After), graphRequest.GetIntevalTimeBef(graphRequest.Before), entityIds, graphRequest.After, graphRequest.Before).Find(&metricsAggregatedPerMinute).Error; resultApp != nil {
	// 	return metricGraphMultiLine, resultApp
	// }

	logging.Infof("%v", dbCon.Config)
	logging.Infof("%v", dbCon)
	if resultApp := dbCon.Raw(graphRequest.GetQueryString(), entityIds, metricsIds, graphRequest.After, graphRequest.Before).Find(&metricsAggregatedPerMinute).Error; resultApp != nil {
		return metricGraphMultiLine, resultApp
	}

	metricGraphMultiLine = model.MetricGraphMultiLine{
		Type: "metric-multiline",
	}

	metricGraphMultiLine.MetricIds = metricsIds
	metricGraphMultiLine.MetricData = metricsAggregatedPerMinute

	return metricGraphMultiLine, nil

}

func (s MetricGraphMultiLineRepositoryDb) GetMetricGraphMultiLineDynamic(graphRequest *model.GraphRequest) (model.PodMetricGraphMultiLine, error) {

	//dbCon := s.getGorm

	context, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	dbCon := s.getGorm.WithContext(context)

	metricsIds := make([]uuid.UUID, 0)
	entityIds := make([]uuid.UUID, 0)
	valueData := make([]string, 0)
	for _, layout := range graphRequest.EntityId {

		metricsIds = append(metricsIds, layout.MetricIds...)
		entityIds = append(entityIds, layout.Id)

		for _, metricId := range layout.MetricIds {
			valueData = append(valueData, fmt.Sprintf(`( '%s' , '%s')`, layout.Id.String(), metricId.String()))
		}
	}
	var metricGraphMultiLine model.PodMetricGraphMultiLine

	var metricsAggregatedPerMinute []model.MultiPodDynamic

	if resultApp := dbCon.Raw(graphRequest.GetQueryStringDynamic(), entityIds, metricsIds, graphRequest.After, graphRequest.Before).Find(&metricsAggregatedPerMinute).Error; resultApp != nil {
		return metricGraphMultiLine, resultApp
	}

	// for i := graphRequest.After; i < graphRequest.Before; i = i + 60 {

	// 	dynamic_valueS := make(map[string]model.DynamicValueObject, 0)

	// 	mapString := []string{
	// 		"stepup-authn-b-deployment-43-nxf5z",
	// 		"stepup-authn-b-deployment-43-jf2sm",
	// 		"stepup-authn-b-deployment-43-r5m5l",
	// 		"stepup-authn-b-deployment-43-fk5h4",
	// 		"stepup-authn-b-deployment-43-686tl",
	// 		"stepup-authn-b-deployment-43-vb625",
	// 		"stepup-authn-b-deployment-43-kkdvd",
	// 		"stepup-authn-b-deployment-43-szsgl",
	// 		"stepup-authn-b-deployment-43-xjxhg"}

	// 	for _, mapD := range mapString {

	// 		dynamic_value := model.DynamicValueObject{
	// 			AvgValue:    rand.Float32(),
	// 			MinValue:    rand.Float32(),
	// 			MaxValue:    rand.Float32(),
	// 			Count:       rand.Int(),
	// 			OldestValue: rand.Float32(),
	// 			LatestValue: rand.Float32(),
	// 			Trend:       rand.Float32(),
	// 			TotalValue:  rand.Float32(),
	// 		}

	// 		dynamic_valueS[mapD] = dynamic_value
	// 	}

	// 	metricsAggregatedPerMinute = append(metricsAggregatedPerMinute, model.MultiPodDynamic{
	// 		EntityID:               entityIds[0],
	// 		MetricID:               metricsIds[0],
	// 		AggregateIntervalStart: time.Unix(i, 0),
	// 		AggregateIntervalEnd:   time.Unix(i+59, 0),
	// 		DynamicValue:           dynamic_valueS,
	// 	})
	// }

	metricGraphMultiLine = model.PodMetricGraphMultiLine{
		Type: "dynamic-metric-multiline",
	}

	metricGraphMultiLine.MetricIds = metricsIds
	metricGraphMultiLine.MetricData = metricsAggregatedPerMinute

	return metricGraphMultiLine, nil

}

func (s MetricGraphMultiLineRepositoryDb) GetMetricGraphMultiLineSelective(graphRequest *model.GraphRequest) (model.PodMetricGraphMultiLine, error) {

	dbCon := s.getGorm
	metricsIds := make([]uuid.UUID, 0)
	entityIds := make([]uuid.UUID, 0)
	valueData := make([]string, 0)
	for _, layout := range graphRequest.EntityId {

		metricsIds = append(metricsIds, layout.MetricIds...)
		entityIds = append(entityIds, layout.Id)

		for _, metricId := range layout.MetricIds {
			valueData = append(valueData, fmt.Sprintf(`( '%s' , '%s')`, layout.Id.String(), metricId.String()))
		}
	}
	var metricGraphMultiLine model.PodMetricGraphMultiLine

	var metricsAggregatedTable []entity.MetricsAggregatedPerMinutePod

	var metricsAggregatedPerMinute []model.MultiPodDynamic

	if len(graphRequest.SortFlag) == 0 {
		graphRequest.SortFlag = "false"
	}

	if len(graphRequest.SortValue) == 0 {
		graphRequest.SortValue = "0"
	}

	if resultApp := dbCon.Raw(graphRequest.GetQueryStringSelective(), entityIds, metricsIds, graphRequest.After, graphRequest.Before).Find(&metricsAggregatedPerMinute).Error; resultApp != nil {
		return metricGraphMultiLine, resultApp
	}

	if resultAppAgg := dbCon.Raw(graphRequest.GetQueryStringSelectiveTable(), graphRequest.After, graphRequest.Before, entityIds, metricsIds, graphRequest.After, graphRequest.Before).Find(&metricsAggregatedTable).Error; resultAppAgg != nil {
		return metricGraphMultiLine, resultAppAgg
	}

	metricGraphMultiLine = model.PodMetricGraphMultiLine{
		Type: "selective-metric-multiline",
	}

	metricGraphMultiLine.MetricIds = metricsIds
	metricGraphMultiLine.MetricData = metricsAggregatedPerMinute
	metricGraphMultiLine.MetricDataAgg = metricsAggregatedTable

	return metricGraphMultiLine, nil

}
