package db

import (
	"context"
	"encoding/json"
	"io/ioutil"
	"log"
	"time"

	"github.aexp.com/amex-eng/go-paved-road/pkg/entity"
	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type ItsmMetricRepositoryDb struct {
	itsmMetric model.ItsmMetric
	getGorm    *gorm.DB
}

func (s ItsmMetricRepositoryDb) GetItsmMetric() (model.ItsmMetric, error) {

	var itsmMetric model.ItsmMetric
	itsmMetric = model.ItsmMetric{
		Type: "itsm-metric",
	}

	return itsmMetric, nil
}

func NewItsmMetricRepositoryDb(gormDb *gorm.DB) ItsmMetricRepositoryDb {

	content, err := ioutil.ReadFile("./pkg/jsondata/metric_single_line.json")

	if err != nil {
		log.Fatal("json file error", err)
	}

	var itsmMetric model.ItsmMetric
	errd := json.Unmarshal(content, &itsmMetric)

	if errd != nil {
		log.Fatal("json unmarshal error", errd)
	}

	return ItsmMetricRepositoryDb{itsmMetric, gormDb}
}

func (s ItsmMetricRepositoryDb) GetItsmMetricJson(graphRequest *model.GraphRequest) (model.ItsmMetric, error) {

	//dbCon := s.getGorm

	context, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	dbCon := s.getGorm.WithContext(context)

	metricsIds := make([]uuid.UUID, 0)
	entityIds := make([]uuid.UUID, 0)
	//valueData := make([]string, 0)
	for _, layout := range graphRequest.EntityId {

		metricsIds = append(metricsIds, layout.MetricIds...)
		entityIds = append(entityIds, layout.Id)

		// for _, metricId := range layout.MetricIds {
		// 	valueData = append(valueData, fmt.Sprintf(`( '%s' , '%s')`, layout.Id.String(), metricId.String()))
		// }
	}

	var itsmMetric model.ItsmMetric

	var result []entity.NonMetricQueryResult

	if resultApp := dbCon.Raw(graphRequest.GetItsmMetricsString(), entityIds, metricsIds, graphRequest.After, graphRequest.Before).Find(&result).Error; resultApp != nil {
		return itsmMetric, resultApp
	}

	itsmMetric.MetricData = result

	return itsmMetric, nil

}
