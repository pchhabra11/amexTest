package db

import (
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/url"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.aexp.com/amex-eng/go-paved-road/pkg/entity"
	"github.aexp.com/amex-eng/go-paved-road/pkg/logging"
	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
	"github.aexp.com/amex-eng/go-paved-road/pkg/utils"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type AppComponentRepositoryDb struct {
	appinfo model.AppComponent
	getGorm *gorm.DB
}

func (s AppComponentRepositoryDb) FindAllAppComp(level *url.Values) (model.AppComponent, error) {

	var err error
	var payload model.AppComponent

	app_id := level.Get("app_id")
	// skipRedis := false

	if strings.Compare(app_id, level.Get("component_id")) != 0 {
		app_id = level.Get("component_id")
	}

	// if level.Get("skipRedis") == "true" {
	// 	skipRedis = true
	// }
	//payload, err = getComponentList(app_id)

	//payload, err = getLayoutData(app_id, s.getGorm)

	context, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	dbCon := s.getGorm.WithContext(context)

	payload, err = getNewLayoutData(app_id, dbCon)
	// payload, err = getLayoutCacheData(app_id, &s, skipRedis)

	if err != nil {
		return payload, err
	}

	return payload, nil

	//return s.appinfo, nil
}

func NewAppComponentRepositoryDbLevelOne(gormDb *gorm.DB) AppComponentRepositoryDb {
	//appinfo := Applist

	content, err := ioutil.ReadFile("./pkg/jsondata/app_component_details_level_0.json")

	if err != nil {
		log.Fatal("json file error", err)
	}

	var payload model.AppComponent
	errd := json.Unmarshal(content, &payload)

	if errd != nil {
		log.Fatal("json unmarshal error", errd)
	}

	return AppComponentRepositoryDb{payload, gormDb}
}

func getBreadCumb(entity_id uuid.UUID, navigation []entity.EntityInfo, getGorm *gorm.DB) ([]entity.EntityInfo, int) {

	var entityData entity.EntityInfo
	// dbCon := getGorm //getGormDB()
	context, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	dbCon := getGorm.WithContext(context)

	results := dbCon.Where(&entity.EntityInfo{EntityId: entity_id}).First(&entityData)

	if results.Error == nil {
		if strings.Compare(entityData.EntityType, "framework") == 0 {
			navigation = append([]entity.EntityInfo{entityData}, navigation...)

			return navigation, len(navigation)
		} else {
			navigation = append([]entity.EntityInfo{entityData}, navigation...)

		}
	}

	return getBreadCumb(entityData.ParentEntityId, navigation, getGorm)

}

func getComponentList(app_id string, getGorm *gorm.DB) (model.AppComponent, error) {
	var payload model.AppComponent
	// colMap := utils.ColMap{
	// 	Data: make([]utils.ColMapData, 0),
	// }

	var entityInfos []entity.EntityInfo
	var entityType []string
	// dbCon := getGorm // getGormDB()
	context, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	dbCon := getGorm.WithContext(context)

	colMap := utils.ColMap{Data: make(map[string]utils.ColMapData, 0)}

	//results := dbCon.Preload("MetricInfos").Where(&entity.EntityInfo{EntityId: uuid.MustParse(app_id)}).Find(&entityInfos)

	// navigation, _ := getBreadCumb(uuid.MustParse(app_id), make([]entity.EntityInfo, 0))

	//logging.Errorf("navigation %v and drill level %d", navigation, dril)

	// for i, nav := range navigation {

	// 	payload.Navigation = append(payload.Navigation, model.AppComponentNavigation{
	// 		Title: nav.EntityName, Href: fmt.Sprintf("/%s?drill_level=%d&app_id=%s", navigation[0].EntityId.String(), i+1, nav.EntityId.String()),
	// 	})

	// }

	payload.Navigation = make([]model.AppComponentNavigation, 0)

	resultApp := dbCon.Model(&entity.EntityInfo{}).Where(&entity.EntityInfo{ParentEntityId: uuid.MustParse(app_id)}).Distinct().Pluck("EntityType", &entityType)

	appType := make(map[string]int, 0)
	singleTableFlag := true
	if resultApp.RowsAffected != 0 {
		//logging.Errorf("app type data %v", entityType)
		//var garph utils.GraphSort = utils.Table
		for _, apd := range entityType {

			//colMap.Data[strings.ToLower(garph.String())] = utils.ColGraphTypeIncrement(colMap, strings.ToLower(garph.String()))
			//m := map[string]interface{}{}

			entityTypeIds := make([]uuid.UUID, 0)
			if resultCol := dbCon.Model(&entity.EntityInfo{}).Where(&entity.EntityInfo{ParentEntityId: uuid.MustParse(app_id), EntityType: apd}).Distinct().Pluck("EntityId", &entityTypeIds).Error; resultCol != nil {
				return payload, resultCol
			}

			tableLayoutIds := make([]entity.LayoutInfo, 0)

			if resultLayoutIds := dbCon.Model(&entity.LayoutInfo{}).Where("entity_id in ? and graph_type = ?", entityTypeIds, "table").Distinct().Find(&tableLayoutIds).Error; resultLayoutIds != nil {
				return payload, resultLayoutIds
			}

			if len(tableLayoutIds) == 0 {

				for _, entituyId := range entityTypeIds {
					CreateLayoutInfo(entituyId, getGorm)
				}

				if resultLayoutIds := dbCon.Model(&entity.LayoutInfo{}).Where("entity_id in ? and graph_type = ?", entityTypeIds, "table").Distinct().Find(&tableLayoutIds).Error; resultLayoutIds != nil {
					return payload, resultLayoutIds
				}
			}

			payload.Layout = append(payload.Layout, model.AppComponentLayout{Type: "table", Title: strings.ToUpper(apd), ID: fmt.Sprintf("%s-%s", apd, app_id), Col: 12, ReloadTime: 30, DefaultInterval: "5m", SortValue: 1, Data: map[string]interface{}{"entity_type": apd, "parent_id": app_id}, LayoutInfo: tableLayoutIds})
			appType[apd] = 0

			colMap.Data["table"] = utils.ColGraphTypeIncrement(colMap, "table")
		}

		singleTableFlag = false
	}

	//if results.Error == nil {
	if err := dbCon.Preload("LayoutsInfos").Preload("Components").Preload("Components.LayoutsInfos").Where(&entity.EntityInfo{EntityId: uuid.MustParse(app_id)}).Find(&entityInfos).Error; err != nil {
		// error handling...
		return payload, err
	}

	for _, result := range entityInfos {

		if len(result.LayoutsInfos) == 0 {
			CreateLayoutInfo(result.EntityId, getGorm)
		}

		if singleTableFlag {

			tableLayoutIds := make([]entity.LayoutInfo, 0)

			if resultLayoutIds := dbCon.Model(&entity.LayoutInfo{}).Where("entity_id = ? and graph_type = ?", result.EntityId, "table").Distinct().Find(&tableLayoutIds).Error; resultLayoutIds != nil {
				return payload, resultLayoutIds
			}

			payload.Layout = append(payload.Layout, model.AppComponentLayout{Type: "table", Title: strings.ToUpper(result.EntityType), ID: fmt.Sprintf("%s-%s", result.EntityType, result.EntityId.String()), Col: 12, ReloadTime: 30, DefaultInterval: "5m", SortValue: 1, LayoutInfo: tableLayoutIds, Data: map[string]interface{}{"entity_type": result.EntityType, "parent_id": result.EntityId.String()}})
			colMap.Data["table"] = utils.ColGraphTypeIncrement(colMap, "table")
		}

		plotGraphCheck := map[string]string{"multiLine": "1"}
		if len(result.Components) == 0 {

			plotGraphCheck = map[string]string{"singleLine": "1", "gauge": "1"}

			if len(result.LayoutsInfos) == 0 {
				CreateLayoutInfo(result.EntityId, getGorm)
				graphLayoutIds := make([]entity.LayoutInfo, 0)

				if resultLayoutIds := dbCon.Model(&entity.LayoutInfo{}).Where("entity_id in ? ", result.EntityId).Find(&graphLayoutIds).Error; resultLayoutIds != nil {
					return payload, resultLayoutIds
				}

				for _, reLa := range graphLayoutIds {
					logging.Infof("Entity layout %s %s", reLa.GraphType, reLa.EntityName)

					if val, ok := plotGraphCheck[reLa.GraphType]; ok {
						//do something here
						if strings.Compare(val, "1") == 0 {

							//if appType[result.EntityType] == 0 {
							//graphEnum := utils.
							sort, _ := strconv.ParseInt(reLa.GraphSort, 0, 0)
							payload.Layout = append(payload.Layout, model.AppComponentLayout{Type: reLa.GraphType, Title: reLa.ColClass, ID: fmt.Sprintf("id-%s-%d", reLa.GraphType, reLa.LayoutId), Col: 6, ReloadTime: 30, DefaultInterval: "5m", SortValue: sort, LayoutInfo: []entity.LayoutInfo{reLa}})
							colMap.Data[strings.ToLower(reLa.GraphType)] = utils.ColGraphTypeIncrement(colMap, strings.ToLower(reLa.GraphType))
							//}

						}

					}

				}

			} else {
				for _, reLa := range result.LayoutsInfos {
					logging.Infof("Entity layout %s %s", reLa.GraphType, reLa.EntityName)

					if val, ok := plotGraphCheck[reLa.GraphType]; ok {
						//do something here
						if strings.Compare(val, "1") == 0 {

							//if appType[result.EntityType] == 0 {
							//graphEnum := utils.
							sort, _ := strconv.ParseInt(reLa.GraphSort, 0, 0)
							payload.Layout = append(payload.Layout, model.AppComponentLayout{Type: reLa.GraphType, Title: reLa.ColClass, ID: fmt.Sprintf("id-%s-%d", reLa.GraphType, reLa.LayoutId), Col: 6, ReloadTime: 30, DefaultInterval: "5m", SortValue: sort, LayoutInfo: []entity.LayoutInfo{reLa}})
							colMap.Data[strings.ToLower(reLa.GraphType)] = utils.ColGraphTypeIncrement(colMap, strings.ToLower(reLa.GraphType))
							//}

						}

					}

				}

			}

		}

		mapEntityMultiCol := make(map[string][]entity.LayoutInfo)
		for _, reComp := range result.Components {

			if len(reComp.LayoutsInfos) == 0 {
				CreateLayoutInfo(reComp.EntityId, getGorm)

				graphLayoutIds := make([]entity.LayoutInfo, 0)

				if resultLayoutIds := dbCon.Model(&entity.LayoutInfo{}).Where("entity_id = ? ", reComp.EntityId).Find(&graphLayoutIds).Error; resultLayoutIds != nil {
					return payload, resultLayoutIds
				}

				for _, reLa := range graphLayoutIds {
					logging.Infof("Entity layout %s %s", reLa.GraphType, reLa.EntityName)

					if val, ok := plotGraphCheck[reLa.GraphType]; ok {
						//do something here
						if strings.Compare(val, "1") == 0 {

							//if appType[result.EntityType] == 0 {
							//graphEnum := utils.
							sort, _ := strconv.ParseInt(reLa.GraphSort, 0, 0)
							payload.Layout = append(payload.Layout, model.AppComponentLayout{Type: reLa.GraphType, Title: reLa.ColClass, ID: fmt.Sprintf("id-%s-%d", reLa.GraphType, reLa.LayoutId), Col: 6, ReloadTime: 30, DefaultInterval: "5m", SortValue: sort, LayoutInfo: []entity.LayoutInfo{reLa}})
							colMap.Data[strings.ToLower(reLa.GraphType)] = utils.ColGraphTypeIncrement(colMap, strings.ToLower(reLa.GraphType))
							//}

						}

					}

				}

			} else {
				for _, reLa := range reComp.LayoutsInfos {

					logging.Infof("Entity layout %s %s", reLa.GraphType, reLa.EntityName)

					if val, ok := plotGraphCheck[reLa.GraphType]; ok {

						//do something here
						if strings.Compare(val, "1") == 0 {

							keyLay := fmt.Sprintf("%s%s", reLa.GraphType, reLa.ColClass)

							mapEntityMultiCol[keyLay] = append(mapEntityMultiCol[keyLay], reLa)

							if appType[reComp.EntityType] == 0 {

								logging.Infof("%v", appType[reComp.EntityType])
								sort, _ := strconv.ParseInt(reLa.GraphSort, 0, 0)
								payload.Layout = append(payload.Layout, model.AppComponentLayout{Type: reLa.GraphType, Title: reLa.ColClass, ID: fmt.Sprintf("id-%s-%d", reLa.GraphType, reLa.LayoutId), Col: 6, ReloadTime: 30, DefaultInterval: "5m", SortValue: sort, LayoutInfo: make([]entity.LayoutInfo, 0)})
								colMap.Data[strings.ToLower(reLa.GraphType)] = utils.ColGraphTypeIncrement(colMap, strings.ToLower(reLa.GraphType))
							}

						}

					}

				}

			}

			appType[reComp.EntityType] = appType[reComp.EntityType] + 1

		}

		for i, paLayout := range payload.Layout {

			keyLayCheck := fmt.Sprintf("%s%s", paLayout.Type, paLayout.Title)
			if val, ok := mapEntityMultiCol[keyLayCheck]; ok {
				payload.Layout[i].LayoutInfo = val
			}
		}

		var oneLogins []model.OneLogin
		if red := dbCon.Raw(`select
							entity_id ,
							entity_name ,
							graph_type,
							graph_sort
						from layout_info
						where graph_type in ('table_metric', 'multiLine_metric')
							and entity_id in (select entity_id from entity_info  where parent_entity_id = ? )
						group by entity_id , entity_name, graph_type, graph_sort;`, uuid.MustParse(app_id)).Find(&oneLogins).Error; red != nil {
			return payload, red
		}

		for j, oneLogin := range oneLogins {

			layoutMetric := make([]entity.LayoutInfo, 0)

			if resultLayoutIds := dbCon.Model(&entity.LayoutInfo{}).Where("entity_id = ? and graph_type = ?", oneLogin.EntityId, oneLogin.GraphType).Distinct().Find(&layoutMetric).Error; resultLayoutIds != nil {
				return payload, resultLayoutIds
			}

			sort, _ := strconv.ParseInt(oneLogin.GraphSort, 0, 0)
			payload.Layout = append(payload.Layout, model.AppComponentLayout{Type: oneLogin.GraphType, Title: oneLogin.EntityName, ID: fmt.Sprintf("id-%s-%d", oneLogin.GraphType, j), Col: 6, ReloadTime: 30, DefaultInterval: "5m", SortValue: sort, LayoutInfo: layoutMetric})
			colMap.Data[strings.ToLower(oneLogin.GraphType)] = utils.ColGraphTypeIncrement(colMap, strings.ToLower(oneLogin.GraphType))

		}

		sort.Sort(model.BySortValue(payload.Layout))
		colMap = utils.UpdateRows(colMap)

		//finalArr := utils.GetFinalColOrder(colMap)

		// logging.Errorf("col map %v \n %v \n", colMap, finalArr)

		// for i := range payload.Layout {
		// 	payload.Layout[i].Col = finalArr[i]
		// }

	}

	return payload, nil
}

func getLayoutData(parent_entity_id string, getGorm *gorm.DB) (model.AppComponent, error) {

	var payload model.AppComponent
	//payload.Navigation = make([]model.AppComponentNavigation, 0)
	payload.Layout = make([]model.AppComponentLayout, 0)
	layoutInfo := make([]entity.LayoutInfoDataExtend, 0)
	colMap := utils.ColMap{Data: make(map[string]utils.ColMapData, 0)}

	// dbCon := getGorm //getGormDB()

	context, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	dbCon := getGorm.WithContext(context)

	firstPage := false
	if len(strings.TrimSpace(parent_entity_id)) == 0 {
		firstPage = true
	}

	entityTypeIds := make([]uuid.UUID, 0)

	if firstPage {

		// if resultCol := dbCon.Model(&entity.EntityInfo{}).Where("parent_entity_id is null").Pluck("EntityId", &entityTypeIds).Error; resultCol != nil {
		// 	return payload, resultCol
		// }
		//var entityTypeIds  []uuid.UUID
		// if resultCol := dbCon.Model(&entity.EntityInfo{}).Where("entity_type = ?", "root").Pluck("EntityId", &entityTypeIds).Error; resultCol != nil {
		// 	return payload, resultCol
		// }
		parent_entity_id = "00000000-0000-0000-0000-000000000000"

		if resultCol := dbCon.Model(&entity.EntityInfo{}).Where("parent_entity_id = ?", "00000000-0000-0000-0000-000000000000").Pluck("EntityId", &entityTypeIds).Error; resultCol != nil {
			return payload, resultCol
		}

	} else {
		if resultCol := dbCon.Model(&entity.EntityInfo{}).Where(&entity.EntityInfo{ParentEntityId: uuid.MustParse(parent_entity_id)}).Distinct().Pluck("EntityId", &entityTypeIds).Error; resultCol != nil {
			return payload, resultCol
		}
	}

	if len(entityTypeIds) == 0 {
		if !firstPage {
			entityTypeIds = append(entityTypeIds, uuid.MustParse(parent_entity_id))
		}

	}

	// latest create layout code

	logging.Infof("%v", entityTypeIds)
	// checkLayoutEntityIds := make([]entity.CheckLayout, 0)

	checkLayoutParentEntityIds := make([]entity.CheckLayoutParent, 0)

	// if checkLayout := dbCon.Raw(`SELECT entity_info.entity_id as entity_id, entity_info.parent_entity_id as parent_entity_id,
	// 								count(layout_info.layout_id) as layout_count
	// 							FROM entity_info
	// 							LEFT JOIN layout_info
	//  					 			ON entity_info.entity_id  = layout_info.entity_id
	// 							Where entity_info.entity_id in ?
	// 							GROUP BY entity_info.entity_id , entity_info.parent_entity_id having  count(layout_info.layout_id) = 0`, entityTypeIds).Find(&checkLayoutEntityIds).Error; checkLayout != nil {
	// 	logging.Infof("error", checkLayout)
	// 	return payload, checkLayout
	// }

	if checkLayoutParent := dbCon.Raw(`SELECT entity_info.entity_id as entity_id, entity_info.parent_entity_id as parent_entity_id,
									count(layout_info.layout_id) as layout_count
								FROM entity_info 
								LEFT JOIN layout_info 
	 					 			ON entity_info.entity_id  = layout_info.entity_id and entity_info.parent_entity_id  = layout_info.parent_entity_id 
								Where entity_info.entity_id in ? and entity_info.parent_entity_id = ?
								GROUP BY entity_info.entity_id , entity_info.parent_entity_id having  count(layout_info.layout_id) = 0`, entityTypeIds, parent_entity_id).Find(&checkLayoutParentEntityIds).Error; checkLayoutParent != nil {
		logging.Errorf("error %v", checkLayoutParent)
		return payload, checkLayoutParent
	}

	//logging.Infof("checkLayoutEntityIds", checkLayoutEntityIds)

	// for _, checkLayoutEntityId := range checkLayoutEntityIds {
	// 	if checkLayoutEntityId.LayoutCount == 0 {
	// 		CreateLayoutInfo(checkLayoutEntityId.EntityId, getGorm)
	// 	}
	// }

	for _, checkLayoutParEntityId := range checkLayoutParentEntityIds {
		if checkLayoutParEntityId.LayoutCount == 0 {
			var queryEntities QueryEntities
			queryEntities.EntityID = checkLayoutParEntityId.EntityId
			queryEntities.ParentEntityId = checkLayoutParEntityId.ParentEntityId
			CreateLayoutInfoParentEntityId(queryEntities, getGorm)
		}
	}

	// for _, valId := range entityTypeIds {
	// 	tableLayoutIds := make([]entity.LayoutInfo, 0)
	// 	if resultLayoutIds := dbCon.Model(&entity.LayoutInfo{}).Where("entity_id = ? ", valId).First(&tableLayoutIds).Error; resultLayoutIds != nil {
	// 		logging.Infof(valId, "no record found")
	// 		return payload, resultLayoutIds
	// 	}

	// 	if len(tableLayoutIds) == 0 {

	// 		for _, entituyId := range entityTypeIds {
	// 			CreateLayoutInfo(entituyId, getGorm)
	// 		}
	// 	}
	// }

	// end

	var entityInfo entity.EntityInfo

	if firstPage {
		// if resultCol := dbCon.Model(&entity.EntityInfo{}).Where("parent_entity_id is null").First(&entityInfo).Error; resultCol != nil {
		// 	return payload, resultCol
		// }

		// if resultCol := dbCon.Model(&entity.EntityInfo{}).Where("entity_type = ?", "root").First(&entityInfo).Error; resultCol != nil {
		// 	return payload, resultCol
		// }

		if resultCol := dbCon.Model(&entity.EntityInfo{}).Where("parent_entity_id = ?", "00000000-0000-0000-0000-000000000000").First(&entityInfo).Error; resultCol != nil {
			return payload, resultCol
		}

	} else {
		if resultCol := dbCon.Model(&entity.EntityInfo{}).Where(&entity.EntityInfo{EntityId: uuid.MustParse(parent_entity_id)}).First(&entityInfo).Error; resultCol != nil {
			return payload, resultCol
		}
	}

	//"entity-table", "entity-multiline", "entity-singleline", "barcolumn", "metric-gauge", "metric-multiline", "metric-table"
	//subQuery := dbCon.Select("entity_id").Where("parent_entity_id is null").Table("entity_info")
	//subQuery := dbCon.Select("entity_id").Where("entity_type = ?", "root").Table("entity_info")

	subQuery := dbCon.Select("entity_id").Where("parent_entity_id = ?", "00000000-0000-0000-0000-000000000000").Table("entity_info")

	graphString := []string{"entity-table", "metric-multiline", "itsm-metrics", "dynamic-metric-multiline"}
	if !firstPage {
		subQuery = dbCon.Select("entity_id").Where("parent_entity_id = ?", uuid.MustParse(parent_entity_id)).Table("entity_info")
		//graphString = []string{"table_metric", "multiLine_metric", "table", "multiLine"}
		graphString = []string{"metric-table", "metric-multiline", "entity-table", "entity-multiline", "itsm-metrics", "dynamic-metric-multiline"}

	}

	flagLastNode := false
	if !entityInfo.HasChild {
		flagLastNode = true
		subQuery = dbCon.Select("entity_id").Where("entity_id = ?", uuid.MustParse(parent_entity_id)).Table("entity_info")
		//graphString = []string{"table_metric", "multiLine_metric", "table", "gauge", "singleLine"}
		graphString = []string{"metric-table", "metric-multiline", "entity-table", "metric-gauge", "entity-singleline", "itsm-metrics", "dynamic-metric-multiline"}
	}

	// if red := dbCon.Raw(`select
	// 		graph_type ,
	// 		entity_id,
	// 		-- entity_type,
	// 		(array_agg(entity_type))[1] AS entity_type ,
	// 		(array_agg(entity_name))[1] AS entity_name ,
	// 		(array_agg(container_class))[1] AS container_class,
	// 		(array_agg(container_name))[1] AS container_name ,
	// 		(array_agg(graph_sort))[1] AS graph_sort ,
	// 		json_agg(col_class) as col_classes,
	// 		json_agg(layout_id) as layout_ids,
	// 		(array_agg(layout_id))[1] as layout_id,
	// 		(array_agg(col_span))[1] as col_span
	// 	from layout_info
	// 	where entity_id in (?) and graph_type in ?
	// 	group by
	// 		graph_type ,
	// 		entity_id ,
	// 		-- entity_type ,
	// 		container_class
	// 	order by graph_sort asc
	// 	`, subQuery, graphString).Find(&layoutInfo).Error; red != nil {
	// 	logging.Infof("error", red)
	// 	return payload, red
	// }

	logging.Infof("%v", graphString)

	if red := dbCon.Raw(` select  	
							graph_type , 
							entity_id,
							(array_agg(entity_type))[1] AS entity_type , 
							(array_agg(entity_name))[1] AS entity_name , 
							(array_agg(deeplink_id))[1] AS deeplink_id , 
							(array_agg(container_class))[1] AS container_class, 
							(array_agg(container_name))[1] AS container_name ,
							(array_agg(graph_sort))[1] AS graph_sort ,
							-- json_agg(metric_class) as metric_classes,
							-- json_agg(layout_id) as layout_ids,
							(array_agg(layout_id))[1] as layout_id,
							(array_agg(col_span))[1] as col_span,
							(array_agg(page_class))[1] AS page_class ,
							(array_agg(page_title))[1] AS page_title ,
							(array_agg(page_sort))[1] AS page_sort ,
							json_agg(obj) as layout_info_data
						from (
							select
							"layout_id",
							"parent_entity_id",
							"entity_id", "entity_name", "entity_type", "deeplink_id",
							"metric_ids", "metric_names",
							"graph_type", "metadata", "col_class", "col_span", "graph_sort",
							"container_class", "container_name",
							"metric_class", "metric_name",
							"page_class", "page_title", "page_sort",
							json_build_object(
								'layout_id', layout_id,
								'entity_id', entity_id,
								'entity_name', entity_name,
								'entity_type', entity_type,
								'metric_ids', metric_ids,
								-- 'metric_names', metric_names,
								--'graph_type', graph_type,
								'meta_data', metadata,
								--'col_class', col_class,
								'col_span', col_span,
								'graph_sort', graph_sort,
								-- 'container_class', container_class,
								-- 'container_name', container_name,
								'metric_class', metric_class,
								'metric_name', metric_name,
								'deeplink_id' , deeplink_id,
								'metric_unit' , metric_unit
							) as obj 	 
						from layout_info li 
						where 
  							 li.entity_id in (?) 
							
							 and parent_entity_id = ? Order by metric_class ) tmp 
						group by  	
							entity_id ,
							parent_entity_id,
							graph_type ,
							container_class, 
							container_name,
							entity_type`, subQuery,
		//graphString,  -- and graph_type in ?
		parent_entity_id).Find(&layoutInfo).Error; red != nil {
		logging.Errorf("error %v", red)
		return payload, red
	}

	// res2B, _ := json.MarshalIndent(layoutInfo, " ", " ")
	// logging.Infof(string(res2B))
	// logging.Infof("\n")

	tableMap := make(map[string]map[string]int, 0)
	segregateMap := make(map[string]map[string][]int, 0)
	//mapMultiLineEntityTypeLayoutInfo := make(map[string]map[string]map[string][]entity.LayoutInfo, 0)

	// logging.Infof("layou extented start ")
	// jsonResp, err := json.MarshalIndent(layoutInfo, " ", "\t")
	// if err != nil {
	// 	log.Fatalf("error happend %s", err)
	// }
	// logging.Infof(string(jsonResp))
	// logging.Infof("layou end >==> ")

	for _, layout := range layoutInfo {

		logging.Infof("layout for each ")
		jsonResp, err := json.MarshalIndent(layout, " ", "\t")
		if err != nil {
			log.Fatalf("error happend %s", err)
		}
		logging.Infof(string(jsonResp))
		logging.Infof("layout forech end >==> ")

		addRecord := true
		//logging.Infof(i, layout)

		layoutMetric := make([]entity.LayoutInfo, 0)

		// if resultLayoutIds := dbCon.Select("layout_id",
		// 	"entity_id", "entity_name", "entity_type",
		// 	"metric_ids", "metric_names",
		// 	"graph_type", "metadata", "col_class", "col_span", "graph_sort",
		// 	"container_class", "container_name",
		// 	"metric_class", "metric_name").Where("entity_id = ? and graph_type = ?", layout.EntityId, layout.GraphType).Order("metric_class ASC").Find(&layoutMetric).Error; resultLayoutIds != nil {
		// 	logging.Infof("Error layout: ", resultLayoutIds)
		// 	return payload, resultLayoutIds
		// }

		err = json.Unmarshal(layout.LayoutInfoData, &layoutMetric)
		if err != nil {
			return payload, err
		}

		//if layout.GraphType == "table" {
		if layout.GraphType == "entity-table" {

			if _, ok := tableMap[layout.GraphType][layout.EntityType]; ok {
				// the key 'elliot' exists within the map
				// logging.Infof(mymap["elliot"])

				addRecord = false

			}
		}

		logging.Infof("%v", tableMap)

		if addRecord {
			sort, _ := strconv.ParseInt(layout.GraphSort, 0, 0)
			colSpan, _ := strconv.ParseInt(layout.ColSpan, 0, 0)
			pagesort, _ := strconv.ParseInt(layout.PageSort, 0, 0)
			payload.Layout = append(payload.Layout, model.AppComponentLayout{
				Type:  layout.GraphType,
				Title: layout.EntityType,
				ID: fmt.Sprintf("id-%s-%d",
					layout.GraphType, layout.LayoutId),
				Col: colSpan,
				//ReloadTime: 30,
				//DefaultInterval: "5m",
				SortValue:      sort,
				LayoutInfo:     layoutMetric,
				ContainerClass: layout.ContainerClass,
				ContainerName:  layout.ContainerName,
				LastNode:       flagLastNode,
				PageClass:      layout.PageClass,
				PageTitle:      layout.PageTitle,
				PageSort:       pagesort,
			})

			if val, ok := tableMap[layout.GraphType][layout.EntityType]; ok {
				logging.Infof("seg \n %d", val)
				tableMap[layout.GraphType][layout.EntityType] = len(payload.Layout)
			} else {
				if tableMap[layout.GraphType] == nil {
					tableMap[layout.GraphType] = map[string]int{}
				}

				tableMap[layout.GraphType][layout.EntityType] = len(payload.Layout)
			}

			if val, ok := segregateMap[layout.GraphType][layout.EntityType]; ok {

				logging.Infof("seg \n %d", val)

				segregateMap[layout.GraphType][layout.EntityType] = append(segregateMap[layout.GraphType][layout.EntityType], len(payload.Layout))
			} else {

				if segregateMap[layout.GraphType] == nil {
					segregateMap[layout.GraphType] = map[string][]int{}
				}

				segregateMap[layout.GraphType][layout.EntityType] = append(segregateMap[layout.GraphType][layout.EntityType], len(payload.Layout))
			}

			colMap.Data[strings.ToLower(layout.GraphType)] = utils.ColGraphTypeIncrement(colMap, strings.ToLower(layout.GraphType))
		} else {

			index := tableMap[layout.GraphType][layout.EntityType] - 1

			payload.Layout[index].LayoutInfo = append(payload.Layout[index].LayoutInfo, layoutMetric...)
			//payload.Layout[index].LayoutInfo = append(payload.Layout[index].LayoutInfo, layout.LayoutInfoData...)
		}

	}

	logging.Infof("========star========\n %v \n", segregateMap)

	for val, seg := range segregateMap {
		//logging.Infof(val, seg)
		//if strings.Compare(val, "multiLine") == 0 {
		if strings.Compare(val, "entity-multiline") == 0 {

			for valIndex, graph := range seg {
				logging.Infof("%s %v", valIndex, graph)

				//sort, _ := strconv.ParseInt(layout.GraphSort, 0, 0)
				flag := true
				for valDr, g := range graph {

					logging.Infof("%d %d", valDr, g-1)

					getPayload := payload.Layout[g-1]

					if flag {
						for _, layMulti := range getPayload.LayoutInfo {

							sort, _ := strconv.ParseInt(layMulti.GraphSort, 0, 0)
							colSpan, _ := strconv.ParseInt(layMulti.ColSpan, 0, 0)
							payload.Layout = append(payload.Layout, model.AppComponentLayout{
								Type:  getPayload.Type,
								Title: getPayload.Title,
								//ID:    fmt.Sprintf("id-%d-%s-%s", layMulti.LayoutId, layMulti.GraphType, layMulti.EntityType),
								ID:  fmt.Sprintf("id-%d-%s-%s", layMulti.LayoutId, getPayload.Type, getPayload.Title),
								Col: colSpan,
								//ReloadTime:      30,
								//DefaultInterval: "5m",
								SortValue:      sort,
								LayoutInfo:     []entity.LayoutInfo{layMulti},
								ContainerClass: getPayload.ContainerClass,
								ContainerName:  getPayload.ContainerName,
								PageClass:      getPayload.PageClass,
								PageTitle:      getPayload.PageTitle,
								PageSort:       getPayload.PageSort,
							})

							// colMap.Data[strings.ToLower(layMulti.GraphType)] = utils.ColGraphTypeIncrement(colMap, strings.ToLower(layMulti.GraphType))

							colMap.Data[strings.ToLower(getPayload.Type)] = utils.ColGraphTypeIncrement(colMap, strings.ToLower(getPayload.Type))

							//logging.Infof("==", layMulti.GraphType, layMulti.EntityType, layMulti.ColClass, "===\n")

						}
					} else {
						indexCount := len(getPayload.LayoutInfo)

						layoutCount := len(payload.Layout) - indexCount
						for i, layMulti := range getPayload.LayoutInfo {

							payload.Layout[layoutCount+i].LayoutInfo = append(payload.Layout[layoutCount+i].LayoutInfo, layMulti)

							//logging.Infof("= =", layMulti.GraphType, layMulti.EntityType, layMulti.ColClass, "= = =\n")
							//colMap.Data[strings.ToLower(layMulti.GraphType)] = utils.ColGraphTypeIncrement(colMap, strings.ToLower(layMulti.GraphType))
						}
					}

					//payload.Layout = remove(payload.Layout, g-1)
					//colMap.Data[strings.ToLower(layMulti.GraphType)] = utils.ColGraphTypeIncrement(colMap, strings.ToLower(layMulti.GraphType))
					flag = false

				}

			}

			// remove data

			// for valIndex, graph := range seg {
			// 	logging.Infof(valIndex, graph)

			// 	sort.Slice(graph, func(x, y int) bool {
			// 		return graph[y] < graph[x]
			// 	})

			// 	logging.Infof("reserve sort ", valIndex, graph)
			// 	for _, g := range graph {

			// 		payload.Layout = remove(payload.Layout, g-1)
			// 	}
			// }

			graphsInt := make([]int, 0)
			for valIndex, graph := range seg {
				logging.Infof("%s %v", valIndex, graph)
				graphsInt = append(graphsInt, graph...)

			}

			if len(graphsInt) > 0 {
				sort.Slice(graphsInt, func(x, y int) bool {
					return graphsInt[y] < graphsInt[x]
				})

				logging.Infof("reserve sort valIndex %v", graphsInt)
				for _, g := range graphsInt {

					payload.Layout = remove(payload.Layout, g-1)
				}
			}
		}

		//if strings.Compare(val, "singleLine") == 0 {
		//singleline
		if strings.Compare(val, "entity-singleline") == 0 {
			for valIndex, graph := range seg {
				logging.Infof("%s %d", valIndex, graph)

				//sort, _ := strconv.ParseInt(layout.GraphSort, 0, 0)
				//flag := true
				for valDr, g := range graph {

					logging.Infof("%d %d", valDr, g-1)

					getPayload := payload.Layout[g-1]

					//if flag {
					for _, layMulti := range getPayload.LayoutInfo {

						// sort, _ := strconv.ParseInt(layMulti.GraphSort, 0, 0)
						// colSpan, _ := strconv.ParseInt(layMulti.ColSpan, 0, 0)
						// payload.Layout = append(payload.Layout, model.AppComponentLayout{
						// 	Type:  layMulti.GraphType,
						// 	Title: layMulti.ColClass,
						// 	ID:    fmt.Sprintf("id-%d-%s-%s", layMulti.LayoutId, layMulti.GraphType, layMulti.EntityType),
						// 	Col:   colSpan,
						// 	//ReloadTime:      30,
						// 	//DefaultInterval: "5m",
						// 	SortValue:      sort,
						// 	LayoutInfo:     []entity.LayoutInfo{layMulti},
						// 	ContainerClass: layMulti.ContainerClass,
						// 	ContainerName:  layMulti.ContainerName})

						// colMap.Data[strings.ToLower(layMulti.GraphType)] = utils.ColGraphTypeIncrement(colMap, strings.ToLower(layMulti.GraphType))

						sort, _ := strconv.ParseInt(layMulti.GraphSort, 0, 0)
						colSpan, _ := strconv.ParseInt(layMulti.ColSpan, 0, 0)
						payload.Layout = append(payload.Layout, model.AppComponentLayout{
							Type:           getPayload.Type,
							Title:          getPayload.Title,
							ID:             fmt.Sprintf("id-%d-%s-%s", layMulti.LayoutId, getPayload.Type, getPayload.Title),
							Col:            colSpan,
							SortValue:      sort,
							LayoutInfo:     []entity.LayoutInfo{layMulti},
							ContainerClass: getPayload.ContainerClass,
							ContainerName:  getPayload.ContainerName,
							PageClass:      getPayload.PageClass,
							PageTitle:      getPayload.PageTitle,
							PageSort:       getPayload.PageSort,
						})

						colMap.Data[strings.ToLower(getPayload.Type)] = utils.ColGraphTypeIncrement(colMap, strings.ToLower(getPayload.Type))

						logging.Infof("== %s %s %s ===\n", layMulti.GraphType, layMulti.EntityType, layMulti.ColClass)

					}
					//}

					//payload.Layout = remove(payload.Layout, g-1)
					//colMap.Data[strings.ToLower(layMulti.GraphType)] = utils.ColGraphTypeIncrement(colMap, strings.ToLower(layMulti.GraphType))
					//flag = false

				}

			}

			// remove data
			for valIndex, graph := range seg {
				logging.Infof("%s %d", valIndex, graph)

				sort.Slice(graph, func(x, y int) bool {
					return graph[y] < graph[x]
				})

				logging.Infof("reserve sort %s %v", valIndex, graph)

				for _, g := range graph {
					payload.Layout = remove(payload.Layout, g-1)
				}
			}
		}

		//if strings.Compare(val, "gauge") == 0 {
		//metric-gauge
		if strings.Compare(val, "metric-gauge") == 0 {
			for valIndex, graph := range seg {
				logging.Infof("%s %d", valIndex, graph)

				//sort, _ := strconv.ParseInt(layout.GraphSort, 0, 0)
				//flag := true
				for valDr, g := range graph {

					logging.Infof("%d %d", valDr, g-1)

					getPayload := payload.Layout[g-1]

					//if flag {
					for _, layMulti := range getPayload.LayoutInfo {

						// sort, _ := strconv.ParseInt(layMulti.GraphSort, 0, 0)
						// colSpan, _ := strconv.ParseInt(layMulti.ColSpan, 0, 0)
						// payload.Layout = append(payload.Layout, model.AppComponentLayout{
						// 	Type:  layMulti.GraphType,
						// 	Title: layMulti.ColClass,
						// 	ID:    fmt.Sprintf("id-%d-%s-%s", layMulti.LayoutId, layMulti.GraphType, layMulti.EntityType),
						// 	Col:   colSpan,
						// 	//ReloadTime:      30,
						// 	//DefaultInterval: "5m",
						// 	SortValue:      sort,
						// 	LayoutInfo:     []entity.LayoutInfo{layMulti},
						// 	ContainerClass: layMulti.ContainerClass,
						// 	ContainerName:  layMulti.ContainerName})

						// colMap.Data[strings.ToLower(layMulti.GraphType)] = utils.ColGraphTypeIncrement(colMap, strings.ToLower(layMulti.GraphType))

						sort, _ := strconv.ParseInt(layMulti.GraphSort, 0, 0)
						colSpan, _ := strconv.ParseInt(layMulti.ColSpan, 0, 0)
						payload.Layout = append(payload.Layout, model.AppComponentLayout{
							Type:           getPayload.Type,
							Title:          getPayload.Title,
							ID:             fmt.Sprintf("id-%d-%s-%s", layMulti.LayoutId, getPayload.Type, getPayload.Title),
							Col:            colSpan,
							SortValue:      sort,
							LayoutInfo:     []entity.LayoutInfo{layMulti},
							ContainerClass: getPayload.ContainerClass,
							ContainerName:  getPayload.ContainerName,
							PageClass:      getPayload.PageClass,
							PageTitle:      getPayload.PageTitle,
							PageSort:       getPayload.PageSort,
						})

						colMap.Data[strings.ToLower(getPayload.Type)] = utils.ColGraphTypeIncrement(colMap, strings.ToLower(getPayload.Type))

						logging.Infof("== %s %s %s ===\n", layMulti.GraphType, layMulti.EntityType, layMulti.ColClass)

					}
					//}

					//payload.Layout = remove(payload.Layout, g-1)
					//colMap.Data[strings.ToLower(layMulti.GraphType)] = utils.ColGraphTypeIncrement(colMap, strings.ToLower(layMulti.GraphType))
					//flag = false

				}

			}

			// remove data
			for valIndex, graph := range seg {
				logging.Infof("%s %d", valIndex, graph)

				sort.Slice(graph, func(x, y int) bool {
					return graph[y] < graph[x]
				})

				logging.Infof("reserve sort %s %d", valIndex, graph)

				for _, g := range graph {
					payload.Layout = remove(payload.Layout, g-1)
				}
			}
		}
	}

	// res2B, _ := json.MarshalIndent(payload.Layout, " ", " ")
	// logging.Infof(string(res2B))
	// logging.Infof("=====================sd====s\n")

	logging.Infof("=======end=========\n")
	sort.Sort(model.BySortValue(payload.Layout))
	colMap = utils.UpdateRows(colMap)

	finalArr := utils.GetFinalColOrder(colMap)

	logging.Infof("col map %v \n %v \n", colMap, finalArr)

	// for i := range payload.Layout {
	// 	payload.Layout[i].Col = finalArr[i]
	// }

	//var payloadContainer model.AppComponent

	varContainerMap := make(map[string][]model.AppComponentLayout, 0)
	varContainerMapName := make(map[string]string, 0)

	for _, layoutData := range payload.Layout {

		var layoutInfoUpdatedata model.AppComponentLayout

		layoutInfoUpdatedata.Type = layoutData.Type
		layoutInfoUpdatedata.Title = layoutData.Title
		layoutInfoUpdatedata.ID = layoutData.ID
		layoutInfoUpdatedata.Col = layoutData.Col
		layoutInfoUpdatedata.LastNode = layoutData.LastNode
		layoutInfoUpdatedata.LayoutInfo = layoutData.LayoutInfo
		layoutInfoUpdatedata.SortValue = layoutData.SortValue
		layoutInfoUpdatedata.PageClass = layoutData.PageClass
		layoutInfoUpdatedata.PageTitle = layoutData.PageTitle
		layoutInfoUpdatedata.PageSort = layoutData.PageSort

		if _, ok := varContainerMap[layoutData.ContainerClass]; ok {
			// the key 'elliot' exists within the map
			varContainerMap[layoutData.ContainerClass] = append(varContainerMap[layoutData.ContainerClass], layoutInfoUpdatedata)
		} else {

			varContainerMap[layoutData.ContainerClass] = []model.AppComponentLayout{layoutInfoUpdatedata}
			varContainerMapName[layoutData.ContainerClass] = layoutData.ContainerName

		}
	}

	if len(varContainerMap) > 0 {
		payload.Layout = make([]model.AppComponentLayout, 0)
		for key, containers := range varContainerMap {
			payload.Layout = append(payload.Layout, model.AppComponentLayout{
				Type:  "container",
				Title: varContainerMapName[key],
				ID:    fmt.Sprintf("id-%s", key),
				Col:   12,
				//ReloadTime: 30,
				//DefaultInterval: "5m",
				SortValue: containers[0].SortValue,
				PageClass: containers[0].PageClass,
				PageTitle: containers[0].PageTitle,
				PageSort:  containers[0].PageSort,
				Children:  containers,
			})

		}
		sort.Sort(model.BySortValue(payload.Layout))

		varPageClassMap := make(map[string][]model.AppComponentLayout, 0)
		varPageClassMapName := make(map[string]string, 0)

		for _, layoutPageData := range payload.Layout {
			collapseFlag := false
			ChildrenData, ok := layoutPageData.Children.([]model.AppComponentLayout)
			if !ok {
				logging.Infof("unexpected structure in ChildrenData data")
			}
			var metadata []model.MetadataComponent

			err := json.Unmarshal(ChildrenData[0].LayoutInfo[0].Metadata, &metadata)
			if err != nil {
				logging.Errorf("Error decoding Metadata %v", err)

			}

			if metadata[0].Data.IsCollapsible == true {
				collapseFlag = true
			}

			var layoutInfoUpdatedata model.AppComponentLayout

			layoutInfoUpdatedata.Type = layoutPageData.Type
			layoutInfoUpdatedata.Title = layoutPageData.Title
			layoutInfoUpdatedata.ID = layoutPageData.ID
			layoutInfoUpdatedata.Col = layoutPageData.Col
			layoutInfoUpdatedata.LastNode = layoutPageData.LastNode
			layoutInfoUpdatedata.LayoutInfo = layoutPageData.LayoutInfo
			layoutInfoUpdatedata.SortValue = layoutPageData.SortValue
			layoutInfoUpdatedata.PageClass = layoutPageData.PageClass
			layoutInfoUpdatedata.PageTitle = layoutPageData.PageTitle
			layoutInfoUpdatedata.PageSort = layoutPageData.PageSort
			layoutInfoUpdatedata.IsCollapsible = collapseFlag
			layoutInfoUpdatedata.Children = layoutPageData.Children

			if _, ok := varPageClassMap[layoutPageData.PageClass]; ok {

				varPageClassMap[layoutPageData.PageClass] = append(varPageClassMap[layoutPageData.PageClass], layoutInfoUpdatedata)
			} else {

				varPageClassMap[layoutPageData.PageClass] = []model.AppComponentLayout{layoutInfoUpdatedata}
				varPageClassMapName[layoutPageData.PageClass] = layoutPageData.PageTitle

			}
		}

		payload.PageLayout = make([]model.AppPageLayout, 0)
		for key, containers := range varPageClassMap {
			payload.PageLayout = append(payload.PageLayout, model.AppPageLayout{
				PageTitle: varPageClassMapName[key],
				PageSort:  containers[0].PageSort,
				Layout:    containers,
			})

		}
		payload.Layout = make([]model.AppComponentLayout, 0)
		sort.Sort(model.ByPageSortValue(payload.PageLayout))

	}

	return payload, nil
}

func remove(s []model.AppComponentLayout, i int) []model.AppComponentLayout {

	//i := 1 // index of 11
	lastIdx := len(s) - 1

	logging.Infof("remove lendf \n %d \n last index %d \n", i, lastIdx)

	if len(s) > i {

		s[i] = s[lastIdx]
		s = s[:lastIdx]

	}

	return s

}

func PrettyPrint(v interface{}) (err error) {
	b, err := json.MarshalIndent(v, "", "  ")
	if err == nil {
		logging.Infof(string(b))
	}
	return
}
