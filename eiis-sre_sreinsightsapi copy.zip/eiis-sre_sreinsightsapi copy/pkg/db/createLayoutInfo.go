package db

import (
	"context"
	"encoding/json"
	"time"

	"github.aexp.com/amex-eng/go-paved-road/pkg/entity"
	"github.aexp.com/amex-eng/go-paved-road/pkg/logging"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type MetricQueryResult struct {
	EntityId        uuid.UUID       `json:"entity_id"`
	EntityName      string          `json:"entity_name"`
	EntityType      string          `json:"entity_type"`
	MetricIds       json.RawMessage `json:"metric_ids"`
	MetricNames     json.RawMessage `json:"metric_names"`
	GraphType       string          `json:"graph_type"`
	MetaValues      json.RawMessage `json:"meta_values"`
	Class           string          `json:"class"`
	Sort            string          `json:"sort"`
	ContainerClass  string          `json:"container_class"`
	ContainerName   string          `json:"container_name"`
	ColSpan         string          `json:"col_span"`
	MetricClassName string          `json:"metric_class_name"`
	MetricClass     string          `json:"metric_class"`
	DeeplinkId      uuid.UUID       `json:"deeplink_id"`
	PageClass       string          `json:"page_class"`
	PageTitle       string          `json:"page_title"`
	PageSort        string          `json:"page_sort"`
	MetricUnit      string          `json:"metric_unit"`
	ParentEntityId  uuid.UUID       `json:"parent_entity_id"`
}

func CreateLayoutInfo(entity_id uuid.UUID, getGorm *gorm.DB) {

	// dbCon := getGorm //getGormDB()

	context, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	dbCon := getGorm.WithContext(context)

	var result []MetricQueryResult
	red := dbCon.Raw(` WITH metricsinfo AS (
		SELECT
			m.metric_id,
			m.entity_id,
			e.entity_name,
			e.entity_type,
			e.deeplink_id,
			m.metric_name,
			m.metric_unit,
			(jsonb_each(metric_type)).key as graph_type,
			(jsonb_each(metric_type)).value->>'metric_class' as class,
			(jsonb_each(metric_type)).value->>'sort' as sort,
			(jsonb_each(metric_type)).value->>'container_class' as container_class,
			(jsonb_each(metric_type)).value->>'container_name' as container_name,
			(jsonb_each(metric_type)).value->>'metric_class' as metric_class,
			(jsonb_each(metric_type)).value->>'metric_name' as metric_class_name,
			(jsonb_each(metric_type)).value->>'col_span' as col_span,
			-- json_build_object('id' , m.metric_id::text,  'data' ,(jsonb_each(metric_type)).value) as meta_value
			json_build_object('id' , m.metric_id::text,  'data' ,json_build_object(
					'type', (jsonb_each(metric_type)).value->>'type',
					'fetch_type', (jsonb_each(metric_type)).value->>'fetch_type',
					'is_collapsible', ((jsonb_each(metric_type)).value->>'is_collapsible')::boolean,
					'min_threshold', m.min_threshold,
					'max_threshold', m.max_threshold
				)
			) as meta_value,
			-- page title field set
			(jsonb_each(metric_type)).value->>'page_class' as page_class,
			(jsonb_each(metric_type)).value->>'page_title' as page_title,
			(jsonb_each(metric_type)).value->>'page_sort' as page_sort
			FROM metric_info m
			JOIN entity_info e ON m.entity_id = e.entity_id and m.parent_entity_id = e.parent_entity_id
	),
	grouped_metrics AS (
		SELECT
			jsonb_agg(metric_id) as metric_ids,
			entity_id,
			entity_name,
			(array_agg(deeplink_id))[1] as deeplink_id,
			(array_agg(entity_type))[1] as entity_type,
			jsonb_agg(metric_name) as metric_names,
			(array_agg(metric_unit))[1] as metric_unit,
			jsonb_agg(meta_value) as meta_values,
			graph_type,
			--class,
			metric_class,
            sort,
			(array_agg(container_class))[1] as container_class,
			(array_agg(container_name))[1] as container_name,
			(array_agg(col_span))[1] as col_span,	
			--(array_agg(metric_class))[1] as metric_class,
			(array_agg(class))[1] as class,
			(array_agg(metric_class_name))[1] as metric_class_name,	
			-- 	page title 
			(array_agg(page_class))[1] as page_class,
			(array_agg(page_title))[1] as page_title,
			(array_agg(page_sort))[1] as page_sort

		FROM metricsinfo
		GROUP BY entity_id,entity_name,graph_type,metric_class,sort,container_class
	)
	SELECT
		entity_id,
		entity_name,
		entity_type,
		deeplink_id,
		metric_ids,
		metric_names,
		metric_unit,
		graph_type,
		meta_values,
		class,
		sort,
		container_class,
		container_name,
		col_span,
		metric_class_name,
		metric_class,
		-- page title 
		page_class,
		page_title,
		page_sort
	FROM grouped_metrics where entity_id = ?`, entity_id).Find(&result)

	if red.Error == nil {

		layOuts := make([]*entity.LayoutInfo, 0)
		insert := false
		for i, re := range result {

			insert = true
			logging.Infof("%d data %v", i, re.Class)

			layout := entity.LayoutInfo{
				EntityId:       re.EntityId,
				EntityName:     re.EntityName,
				MetricIds:      re.MetricIds,
				MetricNames:    re.MetricNames,
				Metadata:       re.MetaValues,
				ColClass:       re.MetricClassName,
				GraphType:      re.GraphType,
				GraphSort:      re.Sort,
				ContainerClass: re.ContainerClass,
				ContainerName:  re.ContainerName,
				EntityType:     re.EntityType,
				ColSpan:        re.ColSpan,
				MetricName:     re.MetricClassName,
				MetricClass:    re.MetricClass,
				DeeplinkId:     re.DeeplinkId,
				PageClass:      re.PageClass,
				PageTitle:      re.PageTitle,
				PageSort:       re.PageSort,
				MetricUnit:     re.MetricUnit,
				ParentEntityId: re.ParentEntityId,
			}

			layOuts = append(layOuts, &layout)

			// if result := dbCon.Create(&layout).Error; result != nil {
			// 	logging.Infof("some error", result)
			// }
		}

		if insert {
			if result := dbCon.Create(layOuts).Error; result != nil {
				logging.Errorf("some error %v", result)
			}
		}

	} else {
		logging.Errorf("%v", red.Error)
	}
}

type QueryEntities struct {
	EntityID       uuid.UUID
	ParentEntityId uuid.UUID
}

func CreateLayoutInfoParentEntityId(queryEntities QueryEntities, getGorm *gorm.DB) {

	//var entity_id uuid.UUID
	// dbCon := getGorm //getGormDB()
	context, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	dbCon := getGorm.WithContext(context)

	var result []MetricQueryResult
	red := dbCon.Raw(` WITH metricsinfo AS (
		SELECT
			m.metric_id,
			m.entity_id,
			e.entity_name,
			e.entity_type,
			e.deeplink_id,
			e.parent_entity_id,
			m.metric_name,
			m.metric_unit,
			(jsonb_each(metric_type)).key as graph_type,
			(jsonb_each(metric_type)).value->>'metric_class' as class,
			(jsonb_each(metric_type)).value->>'sort' as sort,
			(jsonb_each(metric_type)).value->>'container_class' as container_class,
			(jsonb_each(metric_type)).value->>'container_name' as container_name,
			(jsonb_each(metric_type)).value->>'metric_class' as metric_class,
			(jsonb_each(metric_type)).value->>'metric_name' as metric_class_name,
			(jsonb_each(metric_type)).value->>'col_span' as col_span,
			-- json_build_object('id' , m.metric_id::text,  'data' ,(jsonb_each(metric_type)).value) as meta_value
			json_build_object('id' , m.metric_id::text,  'data' ,json_build_object(
					'type', (jsonb_each(metric_type)).value->>'type',
					'fetch_type', (jsonb_each(metric_type)).value->>'fetch_type',
					'is_collapsible', ((jsonb_each(metric_type)).value->>'is_collapsible')::boolean,
					'min_threshold', m.min_threshold,
					'max_threshold', m.max_threshold,
					'metric_color', (jsonb_each(metric_type)).value->>'metric_color'
				)
			) as meta_value,
			-- page title field set
			(jsonb_each(metric_type)).value->>'page_class' as page_class,
			(jsonb_each(metric_type)).value->>'page_title' as page_title,
			(jsonb_each(metric_type)).value->>'page_sort' as page_sort
			FROM metric_info m
			JOIN entity_info e ON m.entity_id = e.entity_id and m.parent_entity_id = e.parent_entity_id
	),
	grouped_metrics AS (
		SELECT
			jsonb_agg(metric_id) as metric_ids,
			entity_id,
			entity_name,
			parent_entity_id,
			--(array_agg(parent_entity_id))[1] as parent_entity_id,
			(array_agg(deeplink_id))[1] as deeplink_id,
			(array_agg(entity_type))[1] as entity_type,
			jsonb_agg(metric_name) as metric_names,
			(array_agg(metric_unit))[1] as metric_unit,
			jsonb_agg(meta_value) as meta_values,
			graph_type,
			--class,
			metric_class,
            sort,
			(array_agg(container_class))[1] as container_class,
			(array_agg(container_name))[1] as container_name,
			(array_agg(col_span))[1] as col_span,	
			--(array_agg(metric_class))[1] as metric_class,
			(array_agg(class))[1] as class,
			(array_agg(metric_class_name))[1] as metric_class_name,	
			-- 	page title 
			(array_agg(page_class))[1] as page_class,
			(array_agg(page_title))[1] as page_title,
			(array_agg(page_sort))[1] as page_sort

		FROM metricsinfo
		GROUP BY entity_id,entity_name,graph_type,metric_class,sort,container_class,parent_entity_id
	)
	SELECT
		entity_id,
		entity_name,
		entity_type,
		deeplink_id,
		parent_entity_id,
		metric_ids,
		metric_names,
		metric_unit,
		graph_type,
		meta_values,
		class,
		sort,
		container_class,
		container_name,
		col_span,
		metric_class_name,
		metric_class,
		-- page title 
		page_class,
		page_title,
		page_sort
	FROM grouped_metrics where entity_id = ? and parent_entity_id = ? `, queryEntities.EntityID, queryEntities.ParentEntityId).Find(&result)

	if red.Error == nil {

		layOuts := make([]*entity.LayoutInfo, 0)
		insert := false
		for i, re := range result {

			insert = true
			logging.Infof("%d data %v", i, re.Class)

			layout := entity.LayoutInfo{
				EntityId:       re.EntityId,
				EntityName:     re.EntityName,
				MetricIds:      re.MetricIds,
				MetricNames:    re.MetricNames,
				Metadata:       re.MetaValues,
				ColClass:       re.MetricClassName,
				GraphType:      re.GraphType,
				GraphSort:      re.Sort,
				ContainerClass: re.ContainerClass,
				ContainerName:  re.ContainerName,
				EntityType:     re.EntityType,
				ColSpan:        re.ColSpan,
				MetricName:     re.MetricClassName,
				MetricClass:    re.MetricClass,
				DeeplinkId:     re.DeeplinkId,
				PageClass:      re.PageClass,
				PageTitle:      re.PageTitle,
				PageSort:       re.PageSort,
				MetricUnit:     re.MetricUnit,
				ParentEntityId: re.ParentEntityId,
			}

			layOuts = append(layOuts, &layout)

			// if result := dbCon.Create(&layout).Error; result != nil {
			// 	logging.Infof("some error", result)
			// }
		}

		if insert {
			if result := dbCon.Create(layOuts).Error; result != nil {
				logging.Errorf("some error %v", result)
			}
		}

	} else {
		logging.Errorf("%v", red.Error)
	}
}
