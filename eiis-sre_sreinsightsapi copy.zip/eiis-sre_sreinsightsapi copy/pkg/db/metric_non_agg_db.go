package db

import (
	"context"
	"time"

	"github.aexp.com/amex-eng/go-paved-road/pkg/entity"
	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type MetricNonAggregatedTableRepositoryDb struct {
	metric  model.MetricNonAggregatedTable
	getGorm *gorm.DB
}

func NewMetricNonAggregatedTableDb(gormDb *gorm.DB) MetricNonAggregatedTableRepositoryDb {

	var metric model.MetricNonAggregatedTable
	return MetricNonAggregatedTableRepositoryDb{metric, gormDb}
}

func (s MetricNonAggregatedTableRepositoryDb) GetMetricData(graphRequest *model.GraphRequest) (model.MetricNonAggregatedTable, error) {

	context, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	dbCon := s.getGorm.WithContext(context)

	metricsIds := make([]uuid.UUID, 0)
	entityIds := make([]uuid.UUID, 0)
	//valueData := make([]string, 0)
	for _, layout := range graphRequest.EntityId {

		metricsIds = append(metricsIds, layout.MetricIds...)
		entityIds = append(entityIds, layout.Id)

	}

	var metric model.MetricNonAggregatedTable

	var result []entity.MetricNonAggregated

	if resultApp := dbCon.Raw(graphRequest.GetQueryMetricNonAgg(), entityIds, metricsIds, graphRequest.After, graphRequest.Before).Find(&result).Error; resultApp != nil {
		return metric, resultApp
	}

	metric.MetricData = result

	return metric, nil

}
