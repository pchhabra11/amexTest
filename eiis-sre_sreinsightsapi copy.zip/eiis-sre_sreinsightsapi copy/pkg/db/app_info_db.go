package db

import (
	"context"
	"log"
	"net/url"
	"time"

	"github.aexp.com/amex-eng/go-paved-road/pkg/entity"
	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
	"gorm.io/gorm"
)

type AppinfoRepositoryDb struct {
	appinfo []model.Appinfo
	getGorm *gorm.DB
}

func (s AppinfoRepositoryDb) FindAll(params *url.Values) ([]model.Appinfo, error) {

	appinfo := make([]model.Appinfo, 0)

	// dbGorm := s.getGorm //getGormDB()
	context, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	dbGorm := s.getGorm.WithContext(context)

	//appinfoEntity, err := entity.GetAllAppInfosParams(dbGorm, params)

	appinfoEntity, err := entity.GetAllEntitiesParams(dbGorm, params)

	if err != nil {
		log.Fatalln(err)
	}

	for _, en := range appinfoEntity {
		//log.Printf("range data %d en %+v\n", i, en.EntityId)
		//log.Printf("data showing app_name %s, app_type %s, app_description %s", en.AppName, en.AppType, en.AppDescription)
		app := model.Appinfo{App_id: en.EntityId, App_name: en.EntityName, App_type: en.EntityType, App_description: en.EntityDescription, Metricinfo: en.MetricInfos, Components: en.Components}

		appinfo = append(appinfo, app)

	}

	return appinfo, nil

	//return s.appinfo, nil
}

func AllAppinfoRepositoryDb(gormDb *gorm.DB) AppinfoRepositoryDb {

	appinfo := make([]model.Appinfo, 0)

	// dbGorm := gormDb //getGormDB()

	context, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	dbGorm := gormDb.WithContext(context)

	//appinfoEntity, err := entity.GetAllAppInfos(dbGorm)

	appinfoEntity, err := entity.GetAllEntities(dbGorm)

	if err != nil {
		log.Fatalln(err)
	}

	for _, en := range appinfoEntity {
		//log.Printf("range data %d en %+v\n", i, en.EntityId)
		//log.Printf("data showing app_name %s, app_type %s, app_description %s", en.AppName, en.AppType, en.AppDescription)
		app := model.Appinfo{App_id: en.EntityId, App_name: en.EntityName, App_type: en.EntityType, App_description: en.EntityDescription, Components: en.MetricInfos}

		appinfo = append(appinfo, app)

	}

	return AppinfoRepositoryDb{appinfo, gormDb}

	// dbCon := GetDB()
	// rows, err := dbCon.Query(`SELECT "app_id","app_name", "app_type" , "app_description" FROM "app_info"`)
	// CheckError(err)

	// defer rows.Close()
	// for rows.Next() {

	// 	var app_id string
	// 	var app_name string
	// 	var app_type string
	// 	var app_description string

	// 	err = rows.Scan(&app_id, &app_name, &app_type, &app_description)
	// 	CheckError(err)

	// 	//fmt.Println(app_id, app_name, app_type, app_description)

	// 	app := model.Appinfo{App_id: app_id, App_name: app_name, App_type: app_type, App_description: app_description}

	// 	appinfo = append(appinfo, app)

	// }

	// appinfo := []Appinfo{
	// 	{App_id: 1, App_name: "EMN", App_type: "K8S", App_description: "ttesog app wpr"},
	// 	{App_id: 2, App_name: "EMN", App_type: "VMS", App_description: "will check "},
	// }
	//return AppinfoRepositoryDb{appinfo}
}

func CheckError(err error) {
	if err != nil {
		panic(err)
	}
}
