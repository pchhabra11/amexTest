package db

import (
	"context"
	"encoding/json"
	"log"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.aexp.com/amex-eng/go-paved-road/pkg/entity"
	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
	"github.com/google/uuid"

	"gorm.io/gorm"
)

const (
	METRIC_MULTILINE           = "metric-multiline"
	SELECTIVE_METRIC_MULTILINE = "selective-metric-multiline"
	ITSM_KEY                   = "itsm"
	ENTITY_KEY                 = "entity"
)

func getNewLayoutData(parent_entity_id string, dbConGorm *gorm.DB) (model.AppComponent, error) {

	context, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	dbCon := dbConGorm.WithContext(context)

	var payload model.AppComponent
	payload.Layout = make([]model.AppComponentLayout, 0)
	firstPage := false
	if len(strings.TrimSpace(parent_entity_id)) == 0 {
		firstPage = true
	}

	entityTypeIds := make([]uuid.UUID, 0)

	if firstPage {
		if resultCol := dbCon.Model(&entity.EntityInfo{}).Where("parent_entity_id = ?", "00000000-0000-0000-0000-000000000000").Pluck("EntityId", &entityTypeIds).Error; resultCol != nil {
			return payload, resultCol
		}
	} else {
		if resultCol := dbCon.Model(&entity.EntityInfo{}).Where(&entity.EntityInfo{ParentEntityId: uuid.MustParse(parent_entity_id)}).Distinct().Pluck("EntityId", &entityTypeIds).Error; resultCol != nil {
			return payload, resultCol
		}
	}

	if len(entityTypeIds) == 0 {
		if !firstPage {
			entityTypeIds = append(entityTypeIds, uuid.MustParse(parent_entity_id))
		}
	}

	var entityInfo entity.EntityInfo

	if firstPage {
		if resultCol := dbCon.Model(&entity.EntityInfo{}).Where("parent_entity_id = ?", "00000000-0000-0000-0000-000000000000").First(&entityInfo).Error; resultCol != nil {
			return payload, resultCol
		}

	} else {
		if resultCol := dbCon.Model(&entity.EntityInfo{}).Where(&entity.EntityInfo{EntityId: uuid.MustParse(parent_entity_id)}).First(&entityInfo).Error; resultCol != nil {
			return payload, resultCol
		}
	}

	subQuery := "00000000-0000-0000-0000-000000000000"

	if !firstPage {
		subQuery = parent_entity_id

	}

	flagLastNode := false
	if !entityInfo.HasChild {
		flagLastNode = true
		subQuery = parent_entity_id
	}

	//---------------New changes start here-----------------//
	metricLayoutInfo := make([]entity.MetricLayoutInfo, 0)

	if red := dbCon.Raw(`SELECT  
		m.metric_id::text,
		m.entity_id::text,
		(array_agg(m.parent_entity_id))[1] AS parent_entity_id, 
		(array_agg(entity_name))[1] AS entity_name, 
		(array_agg(entity_type))[1] AS entity_type, 
		(array_agg(has_child))[1] AS has_child, 
		(array_agg(deeplink_id))[1] AS deeplink_id, 
		(array_agg(metric_name))[1] AS metric_name,
		(array_agg(metric_unit))[1] AS metric_unit,
		((jsonb_each(metric_type)).value->>'sort')::int as sort, 
		(jsonb_each(metric_type)).value->>'page_sort' as page_sort,  
		(jsonb_agg(metric_type)) AS metric_type,
		(array_agg(min_threshold))[1] AS min_threshold, 
		(array_agg(max_threshold))[1] AS max_threshold
		FROM metric_info m
		JOIN entity_info e ON m.entity_id = e.entity_id and m.parent_entity_id = e.parent_entity_id
		where m.parent_entity_id = ?
		Group By m.entity_id,m.metric_id,sort,page_sort
		order by page_sort ASC,  sort ASC
		`, subQuery).Find(&metricLayoutInfo).Error; red != nil {
		return payload, red
	}

	//----------start new map------------

	response := model.LayoutResponse{
		Containers: []model.AppComponentLayout{},
	}

	containersMap := make(map[string]*model.AppComponentLayout)
	graphTypeMap := make(map[string]*model.AppComponentLayout)
	entityMap := make(map[string]*entity.LayoutInfo)
	containerOrder := make([]string, 0)

	//----------end new map---------------

	i := 0
	for _, layoutData := range metricLayoutInfo {

		metricType := make([]map[string]entity.GraphTypeInfo, 0)
		err := json.Unmarshal([]byte(layoutData.MetricType), &metricType)
		if err != nil {
			return payload, err
		}

		for _, metricVal := range metricType {

			for key, val := range metricVal { //graph-type loop

				col, _ := strconv.Atoi(val.ColSpan)
				sort, _ := strconv.Atoi(val.Sort)
				pagesort, _ := strconv.Atoi(val.PageSort)

				///--------Container List Map---------------------------/////

				containerTypeKey := val.ContainerClass
				if _, ok := containersMap[containerTypeKey]; !ok {
					var layoutInfoUpdatedata model.AppComponentLayout

					layoutInfoUpdatedata.Type = "container"
					layoutInfoUpdatedata.IsCollapsible = val.IsCollapsible
					layoutInfoUpdatedata.Title = val.ContainerName
					layoutInfoUpdatedata.ID = "id-" + val.ContainerClass
					layoutInfoUpdatedata.Col = 12
					layoutInfoUpdatedata.LastNode = flagLastNode
					layoutInfoUpdatedata.SortValue = int64(sort + 1)
					layoutInfoUpdatedata.PageClass = val.PageClass
					layoutInfoUpdatedata.PageTitle = val.PageTitle
					layoutInfoUpdatedata.PageSort = int64(pagesort + 1)

					response.Containers = append(response.Containers, layoutInfoUpdatedata)
					containersMap[containerTypeKey] = &response.Containers[len(response.Containers)-1]
					containerOrder = append(containerOrder, val.ContainerClass)
				}

				///--------Graph List Map---------------------------/////

				graphTypeKey := val.ContainerClass + "-" + key + "-" + val.Sort
				if strings.Contains(key, ENTITY_KEY) {
					graphTypeKey = val.ContainerClass + "-" + key + "-" + layoutData.EntityType
				}
				if _, ok := graphTypeMap[graphTypeKey]; !ok {
					var layoutInfoUpdatedata model.AppComponentLayout

					layoutInfoUpdatedata.Type = key
					layoutInfoUpdatedata.Title = layoutData.EntityType //val.Title
					layoutInfoUpdatedata.ID = "id-" + key + "-" + val.Sort
					layoutInfoUpdatedata.Col = int64(col)
					layoutInfoUpdatedata.LastNode = flagLastNode
					layoutInfoUpdatedata.SortValue = int64(sort + 1)
					layoutInfoUpdatedata.PageClass = val.PageClass
					layoutInfoUpdatedata.PageTitle = val.PageTitle
					layoutInfoUpdatedata.PageSort = int64(pagesort + 1)

					//sort
					index := sortIndex(containersMap[val.ContainerClass].NewChildren, val.Sort)
					graphTypes := containersMap[val.ContainerClass].NewChildren
					graphTypes = append(graphTypes[:index], append([]model.AppComponentLayout{layoutInfoUpdatedata}, graphTypes[index:]...)...)
					containersMap[val.ContainerClass].NewChildren = graphTypes
					graphTypeMap[graphTypeKey] = &containersMap[val.ContainerClass].NewChildren[index]
				}

				///--------Entity List Map---------------------------/////
				entityKey := graphTypeKey + "-" + layoutData.EntityId
				if strings.Contains(key, ITSM_KEY) || strings.Compare(key, METRIC_MULTILINE) == 0 || strings.Compare(key, SELECTIVE_METRIC_MULTILINE) == 0 {
					entityKey = entityKey + "-" + layoutData.MetricId
				}
				if _, ok := entityMap[entityKey]; !ok {
					var layoutInfoUpdatedatas entity.LayoutInfo
					layoutInfoUpdatedatas.LayoutId = int64(i)
					layoutInfoUpdatedatas.EntityId = uuid.MustParse(layoutData.EntityId)
					layoutInfoUpdatedatas.ParentEntityId = layoutData.ParentEntityId
					layoutInfoUpdatedatas.EntityType = layoutData.EntityType
					layoutInfoUpdatedatas.GraphType = layoutData.GraphType
					layoutInfoUpdatedatas.EntityName = layoutData.EntityName
					layoutInfoUpdatedatas.DeeplinkId = layoutData.DeeplinkId
					layoutInfoUpdatedatas.MetricName = layoutData.MetricName
					layoutInfoUpdatedatas.MetricClass = val.MetricClass
					layoutInfoUpdatedatas.MetricUnit = layoutData.MetricUnit
					layoutInfoUpdatedatas.GraphSort = val.Sort
					layoutInfoUpdatedatas.ColSpan = val.ColSpan
					layoutInfoUpdatedatas.PageClass = val.PageClass
					layoutInfoUpdatedatas.PageTitle = val.PageTitle
					layoutInfoUpdatedatas.PageSort = val.Sort

					//Metric-Id mapping
					metricIdArr := make([]string, 0)
					metricIdArr = append(metricIdArr, layoutData.MetricId)
					metricIds, err := json.Marshal(metricIdArr)
					if err != nil {
						log.Fatalf("error happend %s", err)
					}

					layoutInfoUpdatedatas.MetricIds = metricIds

					//Metadata mapping
					metaDataObj := []model.MetadataComponent{
						{
							ID: layoutData.MetricId,
							Data: struct {
								Type          string `json:"type"`
								FetchType     string `json:"fetch_type"`
								MaxThreshold  *int   `json:"max_threshold"`
								MinThreshold  *int   `json:"min_threshold"`
								IsCollapsible bool   `json:"is_collapsible"`
							}{
								Type:          val.Type,
								FetchType:     val.FetchType,
								MinThreshold:  layoutData.MinThreshold,
								MaxThreshold:  layoutData.MaxThreshold,
								IsCollapsible: val.IsCollapsible,
							},
						},
					}
					metaData, err := json.Marshal(metaDataObj)
					if err != nil {
						log.Fatalf("error happend %s", err)
					}
					layoutInfoUpdatedatas.Metadata = metaData

					graphTypeMap[graphTypeKey].LayoutInfo = append(graphTypeMap[graphTypeKey].LayoutInfo, layoutInfoUpdatedatas)
					entityMap[entityKey] = &graphTypeMap[graphTypeKey].LayoutInfo[len(graphTypeMap[graphTypeKey].LayoutInfo)-1]
				}
			}
			i++
		}
	}

	if len(containersMap) > 0 {
		varPageClassMap := make(map[string][]model.AppComponentLayout, 0)
		varPageClassMapName := make(map[string]string, 0)
		varPageClassMapSort := make(map[string]int64, 0)

		for _, containerClass := range containerOrder {
			container := containersMap[containerClass]
			if _, ok := varPageClassMap[container.PageClass]; ok {

				varPageClassMap[container.PageClass] = append(varPageClassMap[container.PageClass], *container)
			} else {
				varPageClassMap[container.PageClass] = []model.AppComponentLayout{*container}
				varPageClassMapName[container.PageClass] = container.PageTitle
				varPageClassMapSort[container.PageClass] = container.PageSort
			}
		}

		payload.PageLayout = make([]model.AppPageLayout, 0)
		for key, containers := range varPageClassMap {
			payload.PageLayout = append(payload.PageLayout, model.AppPageLayout{
				PageTitle: varPageClassMapName[key],
				PageSort:  varPageClassMapSort[key],
				Layout:    containers,
			})
		}

		payload.Layout = make([]model.AppComponentLayout, 0)
		sort.Sort(model.ByPageSortValue(payload.PageLayout))
	}

	return payload, nil
}

func sortIndex(containers []model.AppComponentLayout, sort string) int {
	sortValue, err := strconv.Atoi(sort)
	if err != nil {
		return len(containers) //in case sort is not present
	}
	for i, graphType := range containers {
		existingSortValue := graphType.SortValue
		if int64(sortValue) < existingSortValue {
			return i
		}
	}
	return len(containers)
}
