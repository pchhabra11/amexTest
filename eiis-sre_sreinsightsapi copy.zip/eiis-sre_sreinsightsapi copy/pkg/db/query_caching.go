package db

import (
	"context"
	"encoding/json"
	"strings"
	"time"

	"github.aexp.com/amex-eng/eiis-sre_redis-lib/pkg/queryCache"
	"github.aexp.com/amex-eng/go-paved-road/pkg/constant"
	"github.aexp.com/amex-eng/go-paved-road/pkg/logging"
	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
)

func getLayoutCacheData(parent_entity_id string, app *AppComponentRepositoryDb, skipRedis bool) (model.AppComponent, error) {
	var dbData model.AppComponent

	firstPage := false
	if len(strings.TrimSpace(parent_entity_id)) == 0 {
		firstPage = true
	}

	subQuery := "00000000-0000-0000-0000-000000000000"

	if !firstPage {
		subQuery = parent_entity_id
	}

	query := constant.CACHE_KEY + subQuery

	if skipRedis {
		err := refreshDBDataInCache(parent_entity_id, app, query)
		if err != nil {
			logging.Errorf("Error setting DB result to cache: %v", err)
			return dbData, err
		}
		logging.Infof("SkipRedis:Result from DB set to Cache:- Query: %s", query)
	} else {
		result, err := queryCache.GetQuery(query, constant.SORTED_SET_NAME_LRU)
		if err != nil {
			logging.Errorf("Error getting query result: %v", err)
			return dbData, err
		}
		if result == "" {
			err = refreshDBDataInCache(parent_entity_id, app, query)
			if err != nil {
				logging.Errorf("Error setting DB result to cache: %v", err)
				return dbData, err
			}
			logging.Infof("Cache Miss:Result from DB set to Cache:- Query: %s", query)
		} else {
			err := json.Unmarshal([]byte(result), &dbData)
			if err != nil {
				logging.Errorf("Error parsing query response: %v", err)
				return dbData, err
			}
			return dbData, nil
		}
	}

	dbData, err := getFormattedCachedData(query)
	if err != nil {
		logging.Errorf("Error getting cached query result: %v", err)
		return dbData, err
	}

	return dbData, nil
}

func getFormattedCachedData(query string) (model.AppComponent, error) {
	var dbData model.AppComponent

	result, _ := queryCache.GetQuery(query, constant.SORTED_SET_NAME_LRU)

	err := json.Unmarshal([]byte(result), &dbData)
	if err != nil {
		logging.Errorf("Error parsing query response: %v", err)
		return dbData, err
	}

	return dbData, nil
}

func refreshDBDataInCache(parent_entity_id string, app *AppComponentRepositoryDb, query string) error {
	var dbData model.AppComponent

	context, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	dbCon := app.getGorm.WithContext(context)

	dbData, err := getNewLayoutData(parent_entity_id, dbCon)
	if err != nil {
		logging.Errorf("Error getting query result: %v", err)
		return err
	}
	str, err := json.Marshal(dbData)
	if err != nil {
		logging.Errorf("Error parsing db result: %v", err)
		return err
	}

	if err = queryCache.SetQuery(query, string(str), constant.CACHETIMEOUT, constant.SORTED_SET_NAME_LRU); err != nil {
		logging.Errorf("Error setting query: %v", err)
		return err
	}

	return nil
}
