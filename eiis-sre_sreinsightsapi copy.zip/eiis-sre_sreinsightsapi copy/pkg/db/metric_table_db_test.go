package db

import (
	"net/url"
	"reflect"
	"testing"

	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
	"gorm.io/gorm"
)

func Test_getTableData(t *testing.T) {
	type args struct {
		getGorm *gorm.DB
		query   *url.Values
	}
	tests := []struct {
		name    string
		args    args
		want    model.MetricTable
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := getTableData(tt.args.getGorm, tt.args.query)
			if (err != nil) != tt.wantErr {
				t.Errorf("getTableData() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("getTableData() = %v, want %v", got, tt.want)
			}
		})
	}
}
