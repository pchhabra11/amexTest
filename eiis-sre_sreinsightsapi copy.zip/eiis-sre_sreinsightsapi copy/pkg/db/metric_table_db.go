package db

import (
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/url"
	"strings"
	"time"

	"github.aexp.com/amex-eng/go-paved-road/pkg/entity"
	"github.aexp.com/amex-eng/go-paved-road/pkg/logging"
	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type MetricTableRepositoryDb struct {
	metricTable model.MetricTable
	getGorm     *gorm.DB
}

type LayoutQueryResult struct {
	MetaAgg entity.JSON `json:"meta_agg"`
}

type MetaDataJson struct {
	Id   string `json:"id"`
	Data Ad     `json:"data"`
}
type Ad struct {
	Type      string `json:"type"`
	Class     string `json:"class"`
	FetchType string `json:"fetch_type"`
}

func (s MetricTableRepositoryDb) GetMetricTable(query *url.Values) (model.MetricTable, error) {

	var err error

	metricTable, err := getTableData(s.getGorm, query)

	if err != nil {
		return metricTable, err
	}

	return metricTable, nil
}

func NewMetricTableRepositoryDb(gormDb *gorm.DB) MetricTableRepositoryDb {

	content, err := ioutil.ReadFile("./pkg/jsondata/metric_table.json")

	if err != nil {
		log.Fatal("json file error", err)
	}

	var metricTable model.MetricTable
	errd := json.Unmarshal(content, &metricTable)

	if errd != nil {
		log.Fatal("json unmarshal error", errd)
	}

	return MetricTableRepositoryDb{metricTable, gormDb}
}

func getTableData(getGorm *gorm.DB, query *url.Values) (model.MetricTable, error) {

	context, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	dbCon := getGorm.WithContext(context)

	entity_id := query.Get("parent_id")
	entity_type := query.Get("entity_type")
	//checkHeader := query.Get("header")

	var metricTable model.MetricTable
	var metricTableVlaue model.MetricTableValue

	metricTableVlaue.DefaultVisible = make([]string, 0)
	metricTableVlaue.Content = make([][]model.MetricTableContent, 0)

	//dbCon := getGormDB()

	//dbCon := getGorm

	var layoutData []entity.LayoutInfo

	var entityIds []uuid.UUID

	if resultApp := dbCon.Model(&entity.EntityInfo{}).Where(&entity.EntityInfo{ParentEntityId: uuid.MustParse(entity_id), EntityType: entity_type}).Pluck("EntityId", &entityIds).Error; resultApp != nil {
		return metricTable, resultApp
	}

	logging.Infof("%v", entityIds)
	headerMap := make(map[string]string, 0)

	if err := dbCon.Where("entity_id in ? and graph_type = ?", entityIds, "table").Order("entity_id asc, col_class asc").Find(&layoutData).Error; err != nil {
		logging.Errorf("Error found %v", err)
		return metricTable, err
	}

	metricsIds := make([]uuid.UUID, 0)
	for _, layout := range layoutData {

		Ids := make([]uuid.UUID, 0)
		if err := json.Unmarshal(layout.MetricIds, &Ids); err != nil {
			logging.Errorf("Error found %v", err)
		}

		metricsIds = append(metricsIds, Ids...)
	}

	var metricsAggregatedPerMinutes []entity.MetricsAggregatedPerMinute

	if err := dbCon.Raw(` SELECT metrics_aggregated_per_minute.* 
							FROM metrics_aggregated_per_minute , 
				(SELECT entity_id, metric_id , max(aggregate_interval_start) as ains 
					FROM "metrics_aggregated_per_minute" WHERE metric_id IN ? 
					GROUP BY metric_id , entity_id) max_metricagg 
					WHERE  metrics_aggregated_per_minute.metric_id = max_metricagg.metric_id 
							and metrics_aggregated_per_minute.entity_id = max_metricagg.entity_id
							and metrics_aggregated_per_minute.aggregate_interval_start = max_metricagg.ains;`, metricsIds).Find(&metricsAggregatedPerMinutes).Error; err != nil {
		logging.Errorf("Error found %v", err)
	}

	for _, entitYID := range entityIds {

		if err := dbCon.Where("entity_id in ? and graph_type = ?", []uuid.UUID{entitYID}, "table").Order("entity_id asc, col_class asc").Find(&layoutData).Error; err != nil {
			logging.Errorf("Error found %v", err)
			return metricTable, err
		}

		if _, ok := headerMap["name"]; !ok {
			metricTableVlaue.DefaultVisible = append(metricTableVlaue.DefaultVisible, "name")
			metricTableVlaue.Header = append(metricTableVlaue.Header, model.MetricTableHeader{
				ID: "name", Header: "Name", SubHeader: "", Static: true,
			})
			headerMap["name"] = "name"
		}

		var content = make([]model.MetricTableContent, 0)

		content = append(content, model.MetricTableContent{
			Type: "string", Value: layoutData[0].EntityName, Redirect: fmt.Sprintf("component_id=%s", layoutData[0].EntityId.String()),
		})

		for _, layout := range layoutData {

			if _, ok := headerMap[layout.ColClass]; !ok {
				metricTableVlaue.DefaultVisible = append(metricTableVlaue.DefaultVisible, strings.ToLower(layout.ColClass))
				metricTableVlaue.Header = append(metricTableVlaue.Header, model.MetricTableHeader{
					Static: false, ID: strings.ToLower(layout.ColClass), Header: layout.ColClass, SubHeader: "", MetricIds: []string{string(layout.MetricIds)},
				})

				headerMap[layout.ColClass] = layout.ColClass
			}
			// else {
			// 	// will add mretic ids
			// }

			//logging.Infof("======================, ", i, "=================")
			//logging.Infof(i, layout.ColClass, "layout", string(layout.Metadata))

			var payload []uuid.UUID
			if errd := json.Unmarshal(layout.MetricIds, &payload); errd != nil {
				logging.Errorf("error %v", errd)
				return metricTable, errd
			}

			for j, meta := range payload {
				logging.Infof("Data %d %s", j, meta.String())
			}

			var x []MetaDataJson
			if errd := json.Unmarshal(layout.Metadata, &x); errd != nil {
				logging.Errorf("error %v", errd)
				return metricTable, errd
			}

			//logging.Infof(x)

			aggMeta := make([]string, 0)

			for j, meta := range x {

				logging.Infof("Data %d %v", j, meta)

				var metricsAggregatedPerMinute entity.MetricsAggregatedPerMinute

				if resultApp := dbCon.Model(&entity.MetricsAggregatedPerMinute{}).Where(&entity.MetricsAggregatedPerMinute{MetricId: uuid.MustParse(meta.Id)}).Last(&metricsAggregatedPerMinute).Error; resultApp != nil {
					logging.Errorf("Error while file data %v", resultApp)
				}

				//logging.Infof("data working", metricsAggregatedPerMinute.AvgValue)

				if len(aggMeta) > 0 {
					switch meta.Data.Type {
					case "total":
						aggMeta = append(aggMeta, fmt.Sprintf("%.2f", metricsAggregatedPerMinute.AvgValue))
					default:
						aggMeta = append([]string{fmt.Sprintf("%.2f", metricsAggregatedPerMinute.AvgValue)}, aggMeta...)
					}
				} else {
					aggMeta = append(aggMeta, fmt.Sprintf("%.2f", metricsAggregatedPerMinute.AvgValue))
				}

			}

			content = append(content, model.MetricTableContent{Type: "string", Value: strings.Join(aggMeta, " | "), Redirect: "-", MetricId: string(layout.MetricIds), EntityId: layout.EntityId.String()})

		}

		metricTableVlaue.Content = append(metricTableVlaue.Content, content)
	}

	metricTableVlaue.ReloadTime = 30
	metricTable = model.MetricTable{
		Type: "table",
		//Value: metricTableVlaue,
		MetricIds:  metricsIds,
		MetricData: metricsAggregatedPerMinutes,
	}

	return metricTable, nil
}

func (s MetricTableRepositoryDb) GetMetricTableJson(graphRequest *model.GraphRequest) (model.MetricTable, error) {

	var metricTable model.MetricTable
	var metricTableVlaue model.MetricTableValue

	//dbCon := getGormDB()
	//dbCon := s.getGorm

	context, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	dbCon := s.getGorm.WithContext(context)

	metricsIds := make([]uuid.UUID, 0)
	entityIds := make([]uuid.UUID, 0)
	for _, layout := range graphRequest.EntityId {
		metricsIds = append(metricsIds, layout.MetricIds...)
		entityIds = append(entityIds, layout.Id)
	}

	var metricsAggregatedPerMinutes []entity.MetricsAggregatedPerMinute

	// if err := dbCon.Raw(` SELECT
	// 							metrics_aggregated_per_minute.*
	// 						FROM
	// 							metrics_aggregated_per_minute ,
	// 							(SELECT entity_id, metric_id , max(aggregate_interval_start) as ains
	// 							FROM
	// 								"metrics_aggregated_per_minute"
	// 							WHERE
	// 								metric_id IN ?
	// 					 			and
	// 								aggregate_interval_start
	// 								between  to_timestamp(?) and  to_timestamp(?)
	// 							GROUP BY
	// 									metric_id , entity_id) max_metricagg
	// 						WHERE
	// 								metrics_aggregated_per_minute.metric_id = max_metricagg.metric_id
	// 								and metrics_aggregated_per_minute.entity_id = max_metricagg.entity_id
	// 								and metrics_aggregated_per_minute.aggregate_interval_start = max_metricagg.ains;`,
	// 	metricsIds, graphRequest.After, graphRequest.Before).Find(&metricsAggregatedPerMinutes).Error; err != nil {
	// 	logging.Infof("Error found", err)
	// }

	graphRequest.Interval = "1m"
	if err := dbCon.Raw(graphRequest.GetQueryTableString(), entityIds,
		metricsIds, graphRequest.After, graphRequest.Before).Find(&metricsAggregatedPerMinutes).Error; err != nil {
		logging.Errorf("Error found %v", err)
	}

	if len(metricsAggregatedPerMinutes) == 0 {
		for _, layout := range graphRequest.EntityId {
			for _, metricData := range layout.MetricIds {
				metricsAggregatedPerMinutes = append(metricsAggregatedPerMinutes, entity.MetricsAggregatedPerMinute{
					EntityId:               layout.Id,
					MetricId:               metricData,
					AggregateIntervalStart: time.Now(),
					AggregateIntervalEnd:   time.Now(),
					AvgValue:               0,
					MinValue:               0,
					MaxValue:               0,
					Count:                  0,
					OldestValue:            0,
					LatestValue:            0,
					Trend:                  0,
				})
			}

		}
	}

	// temprary fix
	// if len(metricsAggregatedPerMinutes) < len(metricsIds) {
	// 	for _, layout := range graphRequest.EntityId {
	// 		for _, metricData := range layout.MetricIds {
	// 			metricsAggregatedPerMinutes = append(metricsAggregatedPerMinutes, entity.MetricsAggregatedPerMinute{
	// 				EntityId:               uuid.MustParse(layout.Id),
	// 				MetricId:               metricData,
	// 				AggregateIntervalStart: time.Now(),
	// 				AggregateIntervalEnd:   time.Now(),
	// 				AvgValue:               0,
	// 				MinValue:               0,
	// 				MaxValue:               0,
	// 				Count:                  0,
	// 				OldestValue:            0,
	// 				LatestValue:            0,
	// 				Trend:                  0,
	// 			})
	// 		}

	// 	}
	// }

	metricTableVlaue.ReloadTime = 30
	metricTable = model.MetricTable{
		Type:       "entity-table",
		MetricIds:  metricsIds,
		MetricData: metricsAggregatedPerMinutes,
	}
	//logging.Errorf("current %d and sunbi %s", current, subtitle)

	return metricTable, nil
}

func (s MetricTableRepositoryDb) GetMetricTableMetric(graphRequest *model.GraphRequest) (model.MetricTable, error) {

	var metricTable model.MetricTable
	var metricTableVlaue model.MetricTableValue

	//dbCon := getGormDB()
	// dbCon := s.getGorm
	context, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	dbCon := s.getGorm.WithContext(context)
	metricsIds := make([]uuid.UUID, 0)
	entityIds := make([]uuid.UUID, 0)
	for _, layout := range graphRequest.EntityId {
		metricsIds = append(metricsIds, layout.MetricIds...)
		entityIds = append(entityIds, layout.Id)
	}

	metricsAggregatedPerMinutes := make([]entity.MetricsAggregatedPerMinute, 0)

	// if err := dbCon.Raw(` SELECT metrics_aggregated_per_minute.*
	// 						FROM metrics_aggregated_per_minute ,
	// 			(SELECT entity_id, metric_id , max(aggregate_interval_start) as ains
	// 				FROM "metrics_aggregated_per_minute" WHERE metric_id IN ?
	// 				GROUP BY metric_id , entity_id) max_metricagg
	// 				WHERE  metrics_aggregated_per_minute.metric_id = max_metricagg.metric_id
	// 						and metrics_aggregated_per_minute.entity_id = max_metricagg.entity_id
	// 						and metrics_aggregated_per_minute.aggregate_interval_start = max_metricagg.ains;`, metricsIds).Find(&metricsAggregatedPerMinutes).Error; err != nil {
	// 	logging.Infof("Error found", err)
	// }

	// if resultApp := dbCon.Model(graphRequest.GetModel()).Where("metric_id in ? and aggregate_interval_start between  to_timestamp(?) and  to_timestamp(?) ", metricsIds, graphRequest.After, graphRequest.Before).Order("aggregate_interval_start asc").Find(&metricsAggregatedPerMinutes).Error; resultApp != nil {
	// 	return metricTable, resultApp
	// }

	if resultApp := dbCon.Raw(graphRequest.GetQueryString(), entityIds, metricsIds, graphRequest.After, graphRequest.Before).Find(&metricsAggregatedPerMinutes).Error; resultApp != nil {
		return metricTable, resultApp
	}

	metricTableVlaue.ReloadTime = 30
	metricTable = model.MetricTable{
		Type:       "metric-table",
		MetricIds:  metricsIds,
		MetricData: metricsAggregatedPerMinutes,
	}
	//logging.Errorf("current %d and sunbi %s", current, subtitle)

	return metricTable, nil
}
