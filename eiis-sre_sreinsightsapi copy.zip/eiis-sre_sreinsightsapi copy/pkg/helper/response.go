package helper

import (
	"encoding/json"
	"net/http"

	"github.aexp.com/amex-eng/go-paved-road/pkg/logging"
	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
)

func Response(w http.ResponseWriter, responseData model.AppResponse) {
	w.Header().Add("Content-Type", "application/json")
	w.Header().Add("Access-Control-Allow-Headers", "*")
	w.Header().Add("Access-Control-Allow-Methods", "*")
	w.Header().Add("Access-Control-Allow-Origin", "*")
	jsonResp, err := json.Marshal(responseData)
	if err != nil {
		//log.Fatalf("error happend %s", err)
		logging.Errorf("error %+v", err)
		jsonResp, _ = json.Marshal(model.AppResponse{Status: 500, Message: err.Error()})
	}
	w.Write(jsonResp)
}
