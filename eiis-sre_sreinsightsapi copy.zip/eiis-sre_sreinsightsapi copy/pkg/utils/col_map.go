package utils

import (
	"strings"

	"github.aexp.com/amex-eng/go-paved-road/pkg/logging"
)

type GraphSort int

const (
	Table GraphSort = iota + 1
	Multiline
	Singleline
	Barcolumn
	Gauge
	MultilineMetric
	TableMetric
	DynamicMultilineMetric
)

func (g GraphSort) String() string {
	//return [...]string{"table", "multiLine", "singleLine", "barcolumn", "gauge", "multiLine_metric", "table_metric"}[g-1]
	return [...]string{"entity-table", "entity-multiline", "entity-singleline", "barcolumn", "metric-gauge", "metric-multiline", "metric-table", "dynamic-metric-multiline"}[g-1]
}

func (g GraphSort) EnumIndex() int {
	return int(g)
}

type ColMap struct {
	Data map[string]ColMapData
}

type ColMapData struct {
	//Type      string
	Count int
	Rows  []int
	//SortValue int
}

func GetFinalColOrder(colMap ColMap) []int {

	finalArr := make([]int, 0)

	for i := Table; i <= TableMetric; i++ {
		logging.Infof(" i : %v  \n  ", strings.ToLower(i.String()))
		key := strings.ToLower(i.String())
		if data, found := colMap.Data[key]; found {
			finalArr = append(finalArr, data.Rows...)
		}
	}

	return finalArr
}

func UpdateRows(colMap ColMap) ColMap {

	for keyV, data := range colMap.Data {

		logging.Infof(" colmap : %v  %v \n ", keyV, data)
		switch keyV {

		case "singleline", "multiline", "barcolumn", "multiline_metric", "entity-multiline", "entity-singleline", "metric-multiline", "dynamic-metric-multiline":
			colMap.Data[keyV] = ColGraphTypeColSingle(colMap.Data[keyV])
		case "gauge", "metric-gauge":
			colMap.Data[keyV] = ColGraphTypeColGauge(colMap.Data[keyV])
		case "table", "table_metric", "metric-table", "entity-table":
			colMap.Data[keyV] = ColGraphTypeColTable(colMap.Data[keyV])
		case "default":
			for i := 0; i < data.Count; i++ {
				//colMap.Data[keyV].Rows = append(colMap.Data[keyV].Rows, 12)
				data.Rows = append(data.Rows, 12)
				colMap.Data[keyV] = data
			}
		}

	}

	return colMap
}

func ColGraphTypeColGauge(colMap ColMapData) ColMapData {

	if colMap.Count <= 4 {
		switch colMap.Count {
		case 4:
			colMap.Rows = []int{3, 3, 3, 3}
		case 3:
			colMap.Rows = []int{4, 4, 4}
		case 2:
			colMap.Rows = []int{6, 6}
		default:
			colMap.Rows = []int{6}
		}

	}

	if colMap.Count > 4 {

		colMap.Rows = make([]int, 0)
		var flag = true

		// mod 3
		if colMap.Count%3 == 0 {
			for i := 0; i < colMap.Count; i++ {
				colMap.Rows = append(colMap.Rows, 4)
			}
			flag = false
		}

		// mod 4
		if colMap.Count%4 == 0 {

			if !flag {
				colMap.Rows = make([]int, 0)
			}
			for i := 0; i < colMap.Count; i++ {
				colMap.Rows = append(colMap.Rows, 3)
			}
			flag = false
		}

		// mod 4 > mod 3
		if flag {
			if colMap.Count%4 > colMap.Count%3 {
				for i := 0; i < colMap.Count; i++ {
					colMap.Rows = append(colMap.Rows, 4)
				}
			} else {
				for i := 0; i < colMap.Count; i++ {
					colMap.Rows = append(colMap.Rows, 3)
				}
			}
		}

	}

	return colMap
}

func ColGraphTypeColSingle(colMap ColMapData) ColMapData {

	if colMap.Count <= 2 {
		switch colMap.Count {
		case 2:
			colMap.Rows = []int{6, 6}
		default:
			colMap.Rows = []int{12}
		}

	}

	if colMap.Count > 2 {
		colMap.Rows = make([]int, 0)
		for i := 0; i < colMap.Count; i++ {
			colMap.Rows = append(colMap.Rows, 6)
		}
		if colMap.Count%2 != 0 {
			colMap.Rows[colMap.Count-1] = 12
		}

	}

	return colMap

}

func ColGraphTypeColTable(colMap ColMapData) ColMapData {

	for i := 0; i < colMap.Count; i++ {
		colMap.Rows = append(colMap.Rows, 12)
	}

	return colMap
}

func ColGraphTypeIncrement(dataColMap ColMap, keyValue string) ColMapData {

	if v, found := dataColMap.Data[keyValue]; found {
		v.Count = v.Count + 1
		dataColMap.Data[keyValue] = v
	} else {
		dataColMap.Data[keyValue] = ColMapData{
			Count: 1,
			Rows:  make([]int, 0),
		}
	}

	return dataColMap.Data[keyValue]
}
