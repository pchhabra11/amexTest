package constant

import "time"

const (
	SORTED_SET_NAME_LRU = "solveinsightsapi"
	MAX_CACHE_SIZE      = int64(6)
	CACHETIMEOUT        = time.Duration(24) * time.Hour
	CACHE_KEY           = SORTED_SET_NAME_LRU + "-entity_layout_detail-"
	WILDCARD_CACHE_KEY  = CACHE_KEY + "*"
)
