package api

import "github.aexp.com/amex-eng/go-paved-road/pkg/model"

type MetricBarColApi interface {
	GetMetricBarCol() (model.MetricBarCol, error)
}

type DefaulMetricBarColApi struct {
	repo model.MetricBarColRepository
}

func (s DefaulMetricBarColApi) GetMetricBarCol() (model.MetricBarCol, error) {
	return s.repo.GetMetricBarCol()
}

func NewMetricBarColApi(repository model.MetricBarColRepository) DefaulMetricBarColApi {
	return DefaulMetricBarColApi{repository}
}
