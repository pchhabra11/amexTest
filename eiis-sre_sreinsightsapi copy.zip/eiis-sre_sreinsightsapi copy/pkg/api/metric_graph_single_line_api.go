package api

import (
	"net/url"

	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
)

type MetricGraphSingleLineApi interface {
	GetMetricGraphSingleLine(queryValue *url.Values) (model.MetricGraphSingleLine, error)
	GetMetricGraphSingleLineJson(graphRequest *model.GraphRequest) (model.MetricGraphSingleLine, error)
}

type DefaulMetricGraphSingleLineApi struct {
	repo model.MetricGraphSingleLineRepository
}

func (s DefaulMetricGraphSingleLineApi) GetMetricGraphSingleLine(queryValue *url.Values) (model.MetricGraphSingleLine, error) {
	return s.repo.GetMetricGraphSingleLine(queryValue)
}

func (s DefaulMetricGraphSingleLineApi) GetMetricGraphSingleLineJson(graphRequest *model.GraphRequest) (model.MetricGraphSingleLine, error) {
	return s.repo.GetMetricGraphSingleLineJson(graphRequest)
}

func NewMetricGraphSingleLineApi(repository model.MetricGraphSingleLineRepository) DefaulMetricGraphSingleLineApi {
	return DefaulMetricGraphSingleLineApi{repository}
}
