package api

import (
	"net/url"

	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
)

type MetricGaugeApi interface {
	GetMetricGauge(queriesValue *url.Values) (model.MetricGauge, error)
	GetMetricGaugeJson(gaugeRequest *model.GraphRequest) (model.MetricGauge, error)
}

type DefaulMetricGaugeApi struct {
	repo model.MetricGaugeRepository
}

func (s DefaulMetricGaugeApi) GetMetricGauge(queriesValue *url.Values) (model.MetricGauge, error) {
	return s.repo.GetMetricGauge(queriesValue)
}

func NewMetricGaugeApi(repository model.MetricGaugeRepository) DefaulMetricGaugeApi {
	return DefaulMetricGaugeApi{repository}
}

func (s DefaulMetricGaugeApi) GetMetricGaugeJson(gaugeRequest *model.GraphRequest) (model.MetricGauge, error) {
	return s.repo.GetMetricGaugeJson(gaugeRequest)
}
