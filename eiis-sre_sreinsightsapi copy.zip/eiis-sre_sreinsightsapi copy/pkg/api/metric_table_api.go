package api

import (
	"net/url"

	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
)

type MetricTableApi interface {
	GetMetricTable(id *url.Values) (model.MetricTable, error)
	GetMetricTableJson(graphRequest *model.GraphRequest) (model.MetricTable, error)
	GetMetricTableMetric(graphRequest *model.GraphRequest) (model.MetricTable, error)
}

type DefaulMetricTableApi struct {
	repo model.MetricTableRepository
}

func (s DefaulMetricTableApi) GetMetricTable(id *url.Values) (model.MetricTable, error) {
	return s.repo.GetMetricTable(id)
}

func (s DefaulMetricTableApi) GetMetricTableJson(graphRequest *model.GraphRequest) (model.MetricTable, error) {
	return s.repo.GetMetricTableJson(graphRequest)
}

func (s DefaulMetricTableApi) GetMetricTableMetric(graphRequest *model.GraphRequest) (model.MetricTable, error) {
	return s.repo.GetMetricTableMetric(graphRequest)
}

func NewMetricTableApi(repository model.MetricTableRepository) DefaulMetricTableApi {
	return DefaulMetricTableApi{repository}
}
