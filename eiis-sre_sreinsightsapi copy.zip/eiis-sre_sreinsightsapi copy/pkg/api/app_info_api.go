package api

import (
	"net/url"

	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
)

type AppinfoApi interface {
	GetAllAppInfo(params *url.Values) ([]model.Appinfo, error)
}

type DefaulAppInfoApi struct {
	repo model.AppinfoRepository
}

func (s DefaulAppInfoApi) GetAllAppInfo(params *url.Values) ([]model.Appinfo, error) {
	return s.repo.FindAll(params)
}

func NewAppinfoApi(repository model.AppinfoRepository) DefaulAppInfoApi {
	return DefaulAppInfoApi{repository}
}
