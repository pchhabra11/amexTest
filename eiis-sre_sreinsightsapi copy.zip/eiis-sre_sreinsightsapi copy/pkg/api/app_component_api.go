package api

import (
	"net/url"

	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
)

type AppComponentApi interface {
	GetAllAppComp(level *url.Values) (model.AppComponent, error)
	GetMetricsMetadata(requested_entity_id string, entity_types []string) ([]model.MetricMetadataResponse, error)
}

type DefaulAppComponentApi struct {
	repo model.AppComponentRepository
}

func (s DefaulAppComponentApi) GetAllAppComp(level *url.Values) (model.AppComponent, error) {
	return s.repo.FindAllAppComp(level)
}
func (s DefaulAppComponentApi) GetMetricsMetadata(requested_entity_id string, entity_types []string) ([]model.MetricMetadataResponse, error) {
	return s.repo.GetMetricsMetadata(requested_entity_id, entity_types)
}

func NewAppComponentApi(repository model.AppComponentRepository) DefaulAppComponentApi {
	return DefaulAppComponentApi{repository}
}
