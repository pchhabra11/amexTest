package api

import "github.aexp.com/amex-eng/go-paved-road/pkg/model"

type MetricReqApi interface {
	GetMetricReq() (model.MetricReq, error)
}

type DefaulMetricReqApi struct {
	repo model.MetricReqRepository
}

func (s DefaulMetricReqApi) GetMetricReq() (model.MetricReq, error) {
	return s.repo.GetMetricReq()
}

func NewMetricReqApi(repository model.MetricReqRepository) DefaulMetricReqApi {
	return DefaulMetricReqApi{repository}
}
