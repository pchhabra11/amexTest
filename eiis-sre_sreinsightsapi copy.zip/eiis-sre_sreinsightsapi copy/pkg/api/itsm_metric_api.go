package api

import (
	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
)

type ItsmMetricApi interface {
	GetItsmMetric() (model.ItsmMetric, error)
	GetItsmMetricJson(graphRequest *model.GraphRequest) (model.ItsmMetric, error)
	// GetItsmMetricMetric(graphRequest *model.GraphRequest) (model.ItsmMetric, error)
}

type DefaulItsmMetricApi struct {
	repo model.ItsmMetricRepository
}

func (s DefaulItsmMetricApi) GetItsmMetric() (model.ItsmMetric, error) {
	return s.repo.GetItsmMetric()
}

func (s DefaulItsmMetricApi) GetItsmMetricJson(graphRequest *model.GraphRequest) (model.ItsmMetric, error) {
	return s.repo.GetItsmMetricJson(graphRequest)
}

// func (s DefaulItsmMetricApi) GetItsmMetricMetric(graphRequest *model.GraphRequest) (model.ItsmMetric, error) {
// 	return s.repo.GetItsmMetricMetric(graphRequest)
// }

func NewItsmMetricApi(repository model.ItsmMetricRepository) DefaulItsmMetricApi {
	return DefaulItsmMetricApi{repository}
}
