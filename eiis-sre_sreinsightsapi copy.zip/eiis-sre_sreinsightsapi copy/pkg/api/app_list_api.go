package api

import (
	"github.aexp.com/amex-eng/go-paved-road/pkg/entity"
	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
)

type ApplistApi interface {
	GetAllAppComp() (model.Applist, error)
	GetServiceMapData(serviceId string) ([]model.ServiceInfoRes, error)
	CheckServiceMap(serviceId string) (*model.ServiceInfo, error)
	// GetMetricsMetadata(requested_entity_id string, entity_types []string) ([]model.MetricMetadataResponse, error)
	GetJourneyDetails(params entity.JourneyParams) ([]entity.JourneyItsmDetailsRes, error)
	GetJourneyList() ([]entity.JourneyListRes, error)
}

type DefaulApplistApi struct {
	repo model.ApplistRepository
}

func (s DefaulApplistApi) GetAllAppComp() (model.Applist, error) {
	return s.repo.FindAllComp()
}

func (s DefaulApplistApi) GetServiceMapData(serviceId string) ([]model.ServiceInfoRes, error) {
	return s.repo.FindServiceMapData(serviceId)
}

// func (s DefaulApplistApi) GetMetricsMetadata(requested_entity_id string, entity_types []string) ([]model.MetricMetadataResponse, error) {
// 	return s.repo.FindMetricsMetadata(requested_entity_id, entity_types)
// }

func (s DefaulApplistApi) CheckServiceMap(serviceId string) (*model.ServiceInfo, error) {
	return s.repo.CheckServiceMapByServiceId(serviceId)
}

func (s DefaulApplistApi) GetJourneyDetails(params entity.JourneyParams) ([]entity.JourneyItsmDetailsRes, error) {
	return s.repo.FindJourneyDetails(params)
}

func (s DefaulApplistApi) GetJourneyList() ([]entity.JourneyListRes, error) {
	return s.repo.FindJourneyList()
}

func NewApplistApi(repository model.ApplistRepository) DefaulApplistApi {
	return DefaulApplistApi{repository}
}
