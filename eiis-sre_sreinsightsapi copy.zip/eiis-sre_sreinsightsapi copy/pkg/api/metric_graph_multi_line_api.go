package api

import "github.aexp.com/amex-eng/go-paved-road/pkg/model"

type MetricGraphMultiLineApi interface {
	GetMetricGraphMultiLine() (model.MetricGraphMultiLine, error)
	GetMetricGraphMultiLineJson(graphRequest *model.GraphRequest) (model.MetricGraphMultiLine, error)
	GetMetricGraphMultiLineMetric(graphRequest *model.GraphRequest) (model.MetricGraphMultiLine, error)
	GetMetricGraphMultiLineDynamic(graphRequest *model.GraphRequest) (model.PodMetricGraphMultiLine, error)
	GetMetricGraphMultiLineSelective(graphRequest *model.GraphRequest) (model.PodMetricGraphMultiLine, error)
}

type DefaulMetricGraphMultiLineApi struct {
	repo model.MetricGraphMultiLineRepository
}

func (s DefaulMetricGraphMultiLineApi) GetMetricGraphMultiLine() (model.MetricGraphMultiLine, error) {
	return s.repo.GetMetricGraphMultiLine()
}

func (s DefaulMetricGraphMultiLineApi) GetMetricGraphMultiLineJson(graphRequest *model.GraphRequest) (model.MetricGraphMultiLine, error) {
	return s.repo.GetMetricGraphMultiLineJson(graphRequest)
}

func (s DefaulMetricGraphMultiLineApi) GetMetricGraphMultiLineMetric(graphRequest *model.GraphRequest) (model.MetricGraphMultiLine, error) {
	return s.repo.GetMetricGraphMultiLineMetric(graphRequest)
}

func (s DefaulMetricGraphMultiLineApi) GetMetricGraphMultiLineDynamic(graphRequest *model.GraphRequest) (model.PodMetricGraphMultiLine, error) {
	return s.repo.GetMetricGraphMultiLineDynamic(graphRequest)
}

func NewMetricGraphMultiLineApi(repository model.MetricGraphMultiLineRepository) DefaulMetricGraphMultiLineApi {
	return DefaulMetricGraphMultiLineApi{repository}
}

func (s DefaulMetricGraphMultiLineApi) GetMetricGraphMultiLineSelective(graphRequest *model.GraphRequest) (model.PodMetricGraphMultiLine, error) {
	return s.repo.GetMetricGraphMultiLineSelective(graphRequest)
}
