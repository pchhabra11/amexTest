package api

import (
	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
)

type MetricNonAggregatedTableApi interface {
	GetMetricData(graphRequest *model.GraphRequest) (model.MetricNonAggregatedTable, error)
}

type DefaulMetricNonAggregatedTableApi struct {
	repo model.MetricNonAggregatedTableRepository
}

func (s DefaulMetricNonAggregatedTableApi) GetMetricData(graphRequest *model.GraphRequest) (model.MetricNonAggregatedTable, error) {
	return s.repo.GetMetricData(graphRequest)
}

func NewMetricNonAggregatedTableApi(repository model.MetricNonAggregatedTableRepository) DefaulMetricNonAggregatedTableApi {
	return DefaulMetricNonAggregatedTableApi{repository}
}
