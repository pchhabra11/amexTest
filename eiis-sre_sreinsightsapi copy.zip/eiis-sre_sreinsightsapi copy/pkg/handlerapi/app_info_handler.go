package handlerapi

import (
	"encoding/json"
	"log"
	"net/http"

	"github.aexp.com/amex-eng/go-paved-road/pkg/api"
	"github.aexp.com/amex-eng/go-paved-road/pkg/logging"
	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
	"github.com/julienschmidt/httprouter"
)

type AppInfoJson struct {
	App_id          int32  `json:"app_id"`
	App_name        string `json:"app_name"`
	App_type        string `json:"app_type"`
	App_description string `json:"app_description"`
}

type AppInfoHandler struct {
	Apiservice api.AppinfoApi
}

func (ap *AppInfoHandler) GetAllAppInfo(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {

	queryValues := r.URL.Query()
	logging.Infof("params by key value level : %s, app_id %s component_id : %s, metric_id : %s ", queryValues.Get("level"), queryValues.Get("app_id"), queryValues.Get("component_id"), queryValues.Get("metric_id"))

	//metricReq, err := ap.MetricReqservice.GetMetricReq()
	w.Header().Add("Content-Type", "application/json")
	w.Header().Add("Access-Control-Allow-Headers", "*")
	w.Header().Add("Access-Control-Allow-Methods", "*")
	w.Header().Add("Access-Control-Allow-Origin", "*")

	applist, err := ap.Apiservice.GetAllAppInfo(&queryValues)

	if err != nil {
		w.Header().Add("Content-Type", "application/json")
		//w.WriteHeader(http.)
		logging.Errorf("error %+v", err)
	}

	w.Header().Add("Content-Type", "application/json")

	jsonResp, err := json.Marshal(applist)
	if err != nil {
		log.Fatalf("error happend %s", err)
	}

	w.Write(jsonResp)

}

func (ap *AppInfoHandler) GetAllEntitiesInfo(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {

	queryValues := r.URL.Query()
	logging.Infof("params by key value level : %s, app_id %s component_id : %s, metric_id : %s ", queryValues.Get("level"), queryValues.Get("app_id"), queryValues.Get("component_id"), queryValues.Get("metric_id"))

	//metricReq, err := ap.MetricReqservice.GetMetricReq()
	w.Header().Add("Content-Type", "application/json")
	w.Header().Add("Access-Control-Allow-Headers", "*")
	w.Header().Add("Access-Control-Allow-Methods", "*")
	w.Header().Add("Access-Control-Allow-Origin", "*")

	applist, err := ap.Apiservice.GetAllAppInfo(&queryValues)
	responseData := model.AppResponse{Data: applist, Status: 200, Message: "success"}

	if err != nil {
		//w.Header().Add("Content-Type", "application/json")
		//w.WriteHeader(http.)
		logging.Errorf("error %+v", err)
		responseData.Status = 500
		responseData.Message = err.Error()
	}

	//jsonResp, err := json.Marshal(applist)
	if err != nil {
		//log.Fatalf("error happend %s", err)
		logging.Errorf("error %+v", err)
		responseData.Status = 500
		responseData.Message = err.Error()

	}

	jsonResp, err := json.Marshal(responseData)
	w.Write(jsonResp)

}
