package handlerapi

import (
	"encoding/json"
	"errors"
	"log"
	"net/http"
	"strconv"
	"strings"

	"github.aexp.com/amex-eng/go-paved-road/pkg/api"
	"github.aexp.com/amex-eng/go-paved-road/pkg/entity"
	"github.aexp.com/amex-eng/go-paved-road/pkg/helper"
	"github.aexp.com/amex-eng/go-paved-road/pkg/logging"
	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
	"github.com/google/uuid"
	"github.com/julienschmidt/httprouter"
)

type ApplistHandler struct {
	Applistservice api.ApplistApi
	//getDb          *gorm.DB
}

func (ap *ApplistHandler) GetAllAppComp(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {

	appinfo, err := ap.Applistservice.GetAllAppComp()

	responseData := model.AppResponse{Data: appinfo, Status: 200, Message: "success"}

	if err != nil {
		//w.Header().Add("Content-Type", "application/json")
		//w.WriteHeader(http.)
		log.Fatalf("error happend %s", err)
		logging.Errorf("error %+v", err)
		responseData.Status = 500
		responseData.Message = err.Error()
	}

	w.Header().Add("Content-Type", "application/json")
	w.Header().Add("Access-Control-Allow-Headers", "*")
	w.Header().Add("Access-Control-Allow-Methods", "*")
	w.Header().Add("Access-Control-Allow-Origin", "*")
	//w.Write(appinfo)

	jsonResp, err := json.Marshal(responseData)
	//jsonResp, err := json.Marshal(appinfo)
	if err != nil {
		log.Fatalf("error happend %s", err)
		logging.Errorf("error %+v", err)

		jsonResp, _ = json.Marshal(model.AppResponse{Status: 500, Message: err.Error()})
	}

	w.Write(jsonResp)

	// appinfo := []AppInfoJson{
	// 	{App_id: 1, App_name: "a", App_type: "aa", App_description: "aaa"},
	// 	{App_id: 2, App_name: "b", App_type: "bb", App_description: "bbb"},
	// }

	// json.NewEncoder(w).Encode(appinfo)

	// jsonResp, err := json.Marshal(appinfo)
	// if err != nil {
	// 	log.Fatalf("error happend %s", err)
	// }

	// w.Write(jsonResp)

}

func (ap *ApplistHandler) GetServiceMapData(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {
	serviceId := ps.ByName("service_id")
	var responseData model.AppResponse
	if serviceId != "" {
		if _, err := uuid.Parse(serviceId); err != nil {
			responseData = model.AppResponse{Status: 200, Message: "invalid service-id"}
			helper.Response(w, responseData)
			return
		}
	}
	data, err := ap.Applistservice.GetServiceMapData(serviceId)
	if err != nil {
		//log.Fatalf("error happend %s", err)
		logging.Errorf("error %+v", err)
		responseData = model.AppResponse{Status: 500, Message: err.Error()}
		helper.Response(w, responseData)
		return
	}
	responseData = model.AppResponse{Status: 200, Message: "success", Data: data}
	helper.Response(w, responseData)
}

// This a temporary workaround to get the Entity tree, will make it efficient using DB Recursion instead of API Recursion..
func (ap *AppComponentHandler) GetMetricsMetadata(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {

	queryValues := r.URL.Query()
	logging.Infof("requested_entity_id: %s requested_entity_types: %s", queryValues.Get("requested_entity_id"), queryValues.Get("requested_entity_types"))

	//available_entity_types := []string{"App", "ITSM", "EPaaS-Infra", "TIMS-Infra"}
	var responseData model.AppResponse

	requested_entity_id := queryValues.Get("requested_entity_id")
	requested_entity_types := queryValues.Get("requested_entity_types")

	logging.Infof("requested_entity_id: %v & requested_entity_types: %v", requested_entity_id, requested_entity_types)

	if requested_entity_id != "" {
		if _, err := uuid.Parse(requested_entity_id); err != nil {
			responseData = model.AppResponse{Status: 200, Message: "invalid requested_entity_id"}
			helper.Response(w, responseData)
			return
		}
	}

	if requested_entity_types == "" {
		logging.Errorf("error %+v", errors.New("check Query Params"))
		responseData = model.AppResponse{Status: 500, Message: "requested_entity_types QParam is empty"}
		helper.Response(w, responseData)
		return
	}
	requested_entity_types = strings.TrimLeft(requested_entity_types, "[")
	requested_entity_types = strings.TrimRight(requested_entity_types, "]")

	entity_types := strings.Split(requested_entity_types, ",")

	for idx, v := range entity_types {
		entity_types[idx] = strings.TrimSpace(v)

		// if !slices.Contains(available_entity_types, entity_types[idx]) {

		// 	responseData = model.AppResponse{Status: 500, Message: "requested_entity_types is invalid: " + v}
		// 	helper.Response(w, responseData)
		// 	return
		// }

	}

	// logging.Infof("entity_types: ", entity_types)

	data, err := ap.AppCompservice.GetMetricsMetadata(requested_entity_id, entity_types)
	if err != nil {
		//log.Fatalf("error happend %s", err)
		logging.Errorf("error %+v", err)
		responseData = model.AppResponse{Status: 500, Message: err.Error()}
		helper.Response(w, responseData)
		return
	}
	responseData = model.AppResponse{Status: 200, Message: "success", Data: data}
	helper.Response(w, responseData)

}

func (ap *ApplistHandler) CheckServiceMap(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {
	serviceId := ps.ByName("service_id")
	var responseData model.AppResponse
	if serviceId != "" {
		if _, err := uuid.Parse(serviceId); err != nil {
			responseData = model.AppResponse{Status: 200, Message: "invalid service-id"}
			helper.Response(w, responseData)
			return
		}
		data, err := ap.Applistservice.CheckServiceMap(serviceId)
		if err != nil {
			// log.Fatalf("error happend %s", err)
			logging.Errorf("error %+v", err)
			responseData = model.AppResponse{Status: 500, Message: err.Error()}
			helper.Response(w, responseData)
			return
		}
		responseData = model.AppResponse{Status: 200, Message: "success", Data: data}
		helper.Response(w, responseData)
		return
	}
	responseData = model.AppResponse{Status: 200, Message: "service_id is required"}
	helper.Response(w, responseData)
}

func (ap *ApplistHandler) GetJourneyDetails(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {
	urlQuery := r.URL.Query()
	var responseData model.AppResponse
	params := entity.JourneyParams{
		JourneyId: urlQuery.Get("journey_id"),
		Limit:     10,
		Offset:    1,
		StartDate: urlQuery.Get("start_date"),
		EndDate:   urlQuery.Get("end_date"),
	}
	if params.JourneyId == "" {
		responseData = model.AppResponse{Status: 400, Message: "journey_id is mandatory "}
		helper.Response(w, responseData)
		return
	}
	if _, err := uuid.Parse(params.JourneyId); err != nil {
		responseData = model.AppResponse{Status: 400, Message: "invalid journey-id"}
		helper.Response(w, responseData)
		return
	}

	offset := r.URL.Query().Get("offset")
	if offset != "" {
		params.Offset, _ = strconv.Atoi(offset)
	}

	limit := r.URL.Query().Get("limit")
	if limit != "" {
		params.Limit, _ = strconv.Atoi(limit)
	}

	data, err := ap.Applistservice.GetJourneyDetails(params)
	if err != nil {
		logging.Errorf("error %+v", err)
		responseData = model.AppResponse{Status: 500, Message: err.Error()}
		helper.Response(w, responseData)
		return
	}
	journeyResponseData := model.AppResponse{Status: 200, Message: "success", Data: data, Offset: params.Offset, Limit: params.Limit}
	helper.Response(w, journeyResponseData)
}

func (ap *ApplistHandler) GetJourneyList(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {

	var responseData model.AppResponse
	data, err := ap.Applistservice.GetJourneyList()
	if err != nil {
		logging.Errorf("error %+v", err)
		responseData = model.AppResponse{Status: 500, Message: err.Error()}
		helper.Response(w, responseData)
		return
	}
	responseData = model.AppResponse{Status: 200, Message: "success", Data: data}
	helper.Response(w, responseData)
}
