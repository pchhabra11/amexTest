package handlerapi

import (
	"encoding/json"
	"net/http"
	"time"

	"github.aexp.com/amex-eng/go-paved-road/pkg/api"
	"github.aexp.com/amex-eng/go-paved-road/pkg/logging"
	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
	"github.com/julienschmidt/httprouter"
)

type AppComponentHandler struct {
	AppCompservice api.AppComponentApi
}

func (ap *AppComponentHandler) GetAllAppComp(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {

	var start int64
	start = time.Now().UnixNano()

	queryValues := r.URL.Query()
	logging.Infof("app_id: %s time_range: %s drill_level: %s component_id: %s", queryValues.Get("app_id"), queryValues.Get("time_range"), queryValues.Get("drill_level"), queryValues.Get("component_id"))

	appinfo, err := ap.AppCompservice.GetAllAppComp(&queryValues)

	//logging.Infof(appinfo)
	//logging.Infof(err.Error())

	responseData := model.AppResponse{Data: appinfo, Status: 200, Message: "success"}
	responseData.Start = duration("Layout req started ", start, time.Now().UnixNano())
	responseData.TimeStart = timeCalculate(int64(0), true)
	logging.Infof(responseData.Start)

	if err != nil {
		//w.Header().Add("Content-Type", "application/json")
		//w.WriteHeader(http.)
		//log.Fatalf("error happend %s", err)
		logging.Errorf("error %+v", err)
		responseData.Status = 500
		responseData.Message = err.Error()
	}

	w.Header().Add("Content-Type", "application/json")
	w.Header().Add("Access-Control-Allow-Headers", "*")
	w.Header().Add("Access-Control-Allow-Methods", "*")
	w.Header().Add("Access-Control-Allow-Origin", "*")

	//w.Write(appinfo)
	responseData.TimeEnd = timeCalculate(int64(0), true)
	responseData.End = duration("Layout before write", start, time.Now().UnixNano())
	logging.Infof(responseData.End)
	jsonResp, err := json.Marshal(responseData)
	//jsonResp, err := json.Marshal(appinfo)
	if err != nil {
		//log.Fatalf("error happend %s", err)
		logging.Errorf("error %+v", err)
		jsonResp, _ = json.Marshal(model.AppResponse{Status: 500, Message: err.Error()})
	}

	w.Write(jsonResp)
	logging.Infof(duration("Layout After write", start, time.Now().UnixNano()))

}
