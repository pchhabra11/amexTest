package handlerapi

import (
	"encoding/json"
	"log"
	"net/http"

	"github.aexp.com/amex-eng/go-paved-road/pkg/api"
	"github.com/julienschmidt/httprouter"
)

type MetricTableHandler struct {
	AppCompservice api.MetricTableApi
}

func (ap *MetricTableHandler) GetMetricTable(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {

	queryValues := r.URL.Query()
	appinfo, err := ap.AppCompservice.GetMetricTable(&queryValues)

	if err != nil {
		//w.Header().Add("Content-Type", "application/json")
		//w.WriteHeader(http.)
		log.Fatalf("error happend %s", err)
	}

	w.Header().Add("Content-Type", "application/json")
	w.Header().Add("Access-Control-Allow-Headers", "*")
	w.Header().Add("Access-Control-Allow-Methods", "*")
	w.Header().Add("Access-Control-Allow-Origin", "*")
	//w.Write(appinfo)

	jsonResp, err := json.Marshal(appinfo)
	if err != nil {
		log.Fatalf("error happend %s", err)
	}

	w.Write(jsonResp)

}
