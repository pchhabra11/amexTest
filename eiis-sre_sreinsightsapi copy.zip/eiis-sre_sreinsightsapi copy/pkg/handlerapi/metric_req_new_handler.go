package handlerapi

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"time"

	"github.aexp.com/amex-eng/go-paved-road/pkg/api"
	"github.aexp.com/amex-eng/go-paved-road/pkg/logging"
	"github.aexp.com/amex-eng/go-paved-road/pkg/model"
	"github.com/julienschmidt/httprouter"
)

type MetricReqHandlerRef struct {
	MetricReqservice                api.MetricReqApi
	MetricBarColService             api.MetricBarColApi
	MetricGaugeService              api.MetricGaugeApi
	MetricGraphMultiLineService     api.MetricGraphMultiLineApi
	MetricGraphSingleLineService    api.MetricGraphSingleLineApi
	MetricTableService              api.MetricTableApi
	ItsmMetricService               api.ItsmMetricApi
	MetricNonAggregatedTableService api.MetricNonAggregatedTableApi
}

func (ap *MetricReqHandlerRef) GetMetricReqNew(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {

	var start int64
	start = time.Now().UnixNano()

	logging.Infof("enter reqirt amdd")
	// w.Header().Add("Access-Control-Allow-Origin", "*")
	// w.Header().Add("Access-Control-Allow-Methods", "POST , GET, OPTIONS, PUT, DELETE")
	// w.Header().Add("Access-Control-Allow-Headers", "Content-Type , X-Auth-Token, Origin, Authorization")
	// //metricReq, err := ap.MetricReqservice.GetMetricReq()
	// w.Header().Add("Content-Type", "application/json")

	w.Header().Add("Access-Control-Allow-Credentials", "true")

	w.Header().Add("Access-Control-Allow-Headers", "*")
	w.Header().Add("Access-Control-Allow-Methods", "*")
	w.Header().Add("Access-Control-Allow-Origin", "*")
	w.Header().Add("Access-Control-Expose-Headers", "*")
	w.Header().Add("Content-Type", "application/json")

	logging.Infof("header set")

	queryValues := r.URL.Query()
	logging.Infof("params by key value graphtype %s after : %s, before : %s,  interval : %s, graph_key: %s time_range :%s ", queryValues.Get("type"), queryValues.Get("after"), queryValues.Get("before"), queryValues.Get("interval"), queryValues.Get("graph_key"), queryValues.Get("time_range"))

	//metricReq, err := ap.MetricReqservice.GetMetricReq()
	// w.Header().Add("Content-Type", "application/json")
	// w.Header().Add("Access-Control-Allow-Headers", "*")
	// w.Header().Add("Access-Control-Allow-Methods", "*")
	// w.Header().Add("Access-Control-Allow-Origin", "*")
	// w.Header().Set("Access-Control-Allow-Origin", "*")

	var gReq model.GraphRequest
	var unmarshalErr *json.UnmarshalTypeError

	decoder := json.NewDecoder(r.Body)
	decoder.DisallowUnknownFields()
	err := decoder.Decode(&gReq)
	if err != nil {
		if errors.As(err, &unmarshalErr) {
			//errorResponse(w, "Bad Request. Wrong Type provided for field "+unmarshalErr.Field, http.StatusBadRequest)
			logging.Errorf("request json decode error %s", err)
		} else {
			//errorResponse(w, "Bad Request "+err.Error(), http.StatusBadRequest)
			logging.Errorf("request json decode error %s", err)
		}
		//return
	}

	logging.Infof("gReq== %v", gReq)

	responseData := model.AppResponse{Status: 200, Message: "success"}
	responseData.Start = duration("Metric req started ", start, time.Now().UnixNano())

	responseData.TimeFromClient = timeCalculate(gReq.CurrentTimestamp, false)

	responseData.TimeStart = timeCalculate(int64(0), true)

	logging.Infof(responseData.Start)

	switch queryValues.Get("type") {
	case "gauge", "metric-gauge", "gauge_agg":

		//metricReq model.MetricGauge
		metricReq, err := ap.MetricGaugeService.GetMetricGaugeJson(&gReq)
		if len(metricReq.MetricData) == 0 {
			responseData.Status = 204
			responseData.Message = "No data found"
		}

		metricReq.Type = queryValues.Get("type")
		responseData.ReqData = gReq.ReqData

		responseData.Data = metricReq
		if err != nil {
			//w.Header().Add("Content-Type", "application/json")
			//w.WriteHeader(http.)
			logging.Errorf("error happend %s", err)
			responseData.Status = 500
			responseData.Message = err.Error()
		}
		responseData.End = duration("Metric end started ", start, time.Now().UnixNano())
		//log.Print(metricReq)
		//jsonResp, err := json.Marshal(metricReq)

	case "singleLine", "entity-singleline":

		metricReq, err := ap.MetricGraphSingleLineService.GetMetricGraphSingleLineJson(&gReq)
		if len(metricReq.MetricData) == 0 {
			responseData.Status = 204
			responseData.Message = "No data found"
		}
		responseData.Data = metricReq
		if err != nil {
			//w.Header().Add("Content-Type", "application/json")
			//w.WriteHeader(http.)
			logging.Errorf("error happend %s", err)
			responseData.Status = 500
			responseData.Message = err.Error()
		}
		responseData.End = duration("Metric end started ", start, time.Now().UnixNano())
		// jsonResp, err := json.Marshal(metricReq)
		// if err != nil {
		// 	logging.Errorf("error happend %s", err)
		// 	jsonResp, _ = json.Marshal(model.AppResponse{Status: 500, Message: err.Error()})
		// }
		// w.Write(jsonResp)
	case "multiLine", "entity-multiline":
		metricReq, err := ap.MetricGraphMultiLineService.GetMetricGraphMultiLineJson(&gReq)
		if len(metricReq.MetricData) == 0 {
			responseData.Status = 204
			responseData.Message = "No data found"
		}
		responseData.Data = metricReq
		if err != nil {
			//w.Header().Add("Content-Type", "application/json")
			//w.WriteHeader(http.)
			logging.Errorf("error happend %s", err)
			responseData.Status = 500
			responseData.Message = err.Error()
		}
		responseData.End = duration("Metric end started ", start, time.Now().UnixNano())
		// jsonResp, err := json.Marshal(metricReq)
		// if err != nil {
		// 	logging.Errorf("error happend %s", err)
		// 	jsonResp, _ = json.Marshal(model.AppResponse{Status: 500, Message: err.Error()})
		// }
		// w.Write(jsonResp)

	case "multiLine_metric", "metric-multiline", "multiLine_ts":
		metricReq, err := ap.MetricGraphMultiLineService.GetMetricGraphMultiLineMetric(&gReq)
		if len(metricReq.MetricData) == 0 {
			responseData.Status = 204
			responseData.Message = "No data found"
		}

		metricReq.Type = queryValues.Get("type")
		responseData.ReqData = gReq.ReqData

		responseData.Data = metricReq
		if err != nil {
			//w.Header().Add("Content-Type", "application/json")
			//w.WriteHeader(http.)
			logging.Errorf("error happend %s", err)
			responseData.Status = 500
			responseData.Message = err.Error()
		}
		responseData.End = duration("Metric end started ", start, time.Now().UnixNano())
		// jsonResp, err := json.Marshal(metricReq)
		// if err != nil {
		// 	logging.Errorf("error happend %s", err)
		// 	jsonResp, _ = json.Marshal(model.AppResponse{Status: 500, Message: err.Error()})
		// }
		// w.Write(jsonResp)

	case "column", "column_1":
		metricReq, err := ap.MetricBarColService.GetMetricBarCol()
		// if len(metricReq.MetricData) == 0 {
		// 	responseData.Status = 204
		// }
		responseData.Data = metricReq
		if err != nil {
			//w.Header().Add("Content-Type", "application/json")
			//w.WriteHeader(http.)
			logging.Errorf("error happend %s", err)
			responseData.Status = 500
			responseData.Message = err.Error()
		}
		responseData.End = duration("Metric end started ", start, time.Now().UnixNano())
		// jsonResp, err := json.Marshal(metricReq)
		// if err != nil {
		// 	logging.Errorf("error happend %s", err)
		// 	jsonResp, _ = json.Marshal(model.AppResponse{Status: 500, Message: err.Error()})
		// }
		// w.Write(jsonResp)

	case "table", "entity-table", "table_agg":
		metricReq, err := ap.MetricTableService.GetMetricTableJson(&gReq)
		if len(metricReq.MetricData) == 0 {
			responseData.Status = 204
			responseData.Message = "No data found"
		}

		metricReq.Type = queryValues.Get("type")
		responseData.ReqData = gReq.ReqData

		responseData.Data = metricReq
		if err != nil {
			//w.Header().Add("Content-Type", "application/json")
			//w.WriteHeader(http.)
			logging.Errorf("error happend %s", err)
			responseData.Status = 500
			responseData.Message = err.Error()
		}
		responseData.End = duration("Metric end started ", start, time.Now().UnixNano())
		// jsonResp, err := json.Marshal(metricReq)
		// if err != nil {
		// 	logging.Errorf("error happend %s", err)
		// 	jsonResp, _ = json.Marshal(model.AppResponse{Status: 500, Message: err.Error()})
		// }
		// w.Write(jsonResp)

	case "table_metric", "metric-table":
		metricReq, err := ap.MetricTableService.GetMetricTableMetric(&gReq)
		if len(metricReq.MetricData) == 0 {
			responseData.Status = 204
			responseData.Message = "No data found"
		}
		responseData.Data = metricReq
		if err != nil {
			//w.Header().Add("Content-Type", "application/json")
			//w.WriteHeader(http.)
			logging.Errorf("error happend %s", err)
			responseData.Status = 500
			responseData.Message = err.Error()
		}
		responseData.End = duration("Metric end started ", start, time.Now().UnixNano())
		// jsonResp, err := json.Marshal(metricReq)
		// if err != nil {
		// 	logging.Errorf("error happend %s", err)
		// 	jsonResp, _ = json.Marshal(model.AppResponse{Status: 500, Message: err.Error()})
		// }
		// w.Write(jsonResp)

	case "itsm-metrics":
		metricReq, err := ap.ItsmMetricService.GetItsmMetricJson(&gReq)
		if len(metricReq.MetricData) == 0 {
			responseData.Status = 204
			responseData.Message = "No data found"
		}
		responseData.Data = metricReq
		if err != nil {
			logging.Errorf("error happend %s", err)
			responseData.Status = 500
			responseData.Message = err.Error()
		}
		responseData.End = duration("Metric end started ", start, time.Now().UnixNano())

	case "dynamic-metric-multiline":
		metricReq, err := ap.MetricGraphMultiLineService.GetMetricGraphMultiLineDynamic(&gReq)
		if len(metricReq.MetricData) == 0 {
			responseData.Status = 204
			responseData.Message = "No data found"
		}
		responseData.Data = metricReq
		if err != nil {
			//w.Header().Add("Content-Type", "application/json")
			//w.WriteHeader(http.)
			logging.Errorf("error happend %s", err)
			responseData.Status = 500
			responseData.Message = err.Error()
		}
		responseData.End = duration("Metric end started ", start, time.Now().UnixNano())

	case "metric-non-agg-table":
		metricReq, err := ap.MetricNonAggregatedTableService.GetMetricData(&gReq)
		if len(metricReq.MetricData) == 0 {
			responseData.Status = 204
			responseData.Message = "No data found"
		}
		responseData.Data = metricReq
		if err != nil {
			//w.Header().Add("Content-Type", "application/json")
			//w.WriteHeader(http.)
			logging.Errorf("error happend %s", err)
			responseData.Status = 500
			responseData.Message = err.Error()
		}
		responseData.End = duration("Metric end started ", start, time.Now().UnixNano())

	case "selective-metric-multiline":
		metricReq, err := ap.MetricGraphMultiLineService.GetMetricGraphMultiLineSelective(&gReq)
		if len(metricReq.MetricData) == 0 {
			responseData.Status = 204
			responseData.Message = "No data found"
		}
		responseData.Data = metricReq
		if err != nil {
			//w.Header().Add("Content-Type", "application/json")
			//w.WriteHeader(http.)
			logging.Errorf("error happend %s", err)
			responseData.Status = 500
			responseData.Message = err.Error()
		}
		responseData.End = duration("Metric end started ", start, time.Now().UnixNano())

	default:

		metricReq, err := ap.MetricReqservice.GetMetricReq()

		responseData.Data = metricReq

		if err != nil {
			//w.Header().Add("Content-Type", "application/json")
			//w.WriteHeader(http.)
			logging.Errorf("error happend %s", err)
			responseData.Status = 500
			responseData.Message = err.Error()
		}
		responseData.End = duration("Metric end started ", start, time.Now().UnixNano())
		// jsonResp, err := json.Marshal(metricReq)
		// if err != nil {
		// 	logging.Errorf("error happend %s", err)
		// 	jsonResp, _ = json.Marshal(model.AppResponse{Status: 500, Message: err.Error()})
		// }
		// w.Write(jsonResp)
	}

	responseData.TimeEnd = timeCalculate(int64(0), true)
	jsonResp, err := json.Marshal(responseData)
	//log.Print(jsonResp)
	if err != nil {
		logging.Errorf("error happend %s", err)
		jsonResp, _ = json.Marshal(model.AppResponse{Status: 500, Message: err.Error()})
	}

	logging.Infof(responseData.End)
	w.Write(jsonResp)
	logging.Infof(duration("Metric After write", start, time.Now().UnixNano()))
	//w.Write(metricReq)

}

func errorResponse(w http.ResponseWriter, message string, httpStatusCode int) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(httpStatusCode)
	resp := make(map[string]string)
	resp["message"] = message
	jsonResp, _ := json.Marshal(resp)
	w.Write(jsonResp)
}

func duration(msg string, start int64, end int64) string {
	var ms = (end - start) / int64(time.Millisecond)
	re := fmt.Sprintf("%v time: %d ms", msg, ms)
	return re
}

func timeCalculate(tUnixMilli int64, valR bool) time.Time {

	if valR {
		tUnixMilli = int64(time.Nanosecond) * time.Now().UnixNano() / int64(time.Millisecond)
	}

	tUnix := tUnixMilli / int64(time.Microsecond)
	tUnixNanoRemainder := (tUnixMilli % int64(time.Microsecond)) * int64(time.Millisecond)
	timeT := time.Unix(tUnix, tUnixNanoRemainder)
	logging.Infof("time.Time: %s\n", timeT)
	return timeT
}
