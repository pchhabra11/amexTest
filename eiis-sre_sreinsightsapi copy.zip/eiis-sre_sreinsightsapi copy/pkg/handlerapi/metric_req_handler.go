package handlerapi

import (
	"encoding/json"
	"net/http"

	"github.aexp.com/amex-eng/go-paved-road/pkg/api"
	"github.aexp.com/amex-eng/go-paved-road/pkg/logging"
	"github.com/julienschmidt/httprouter"
)

type MetricReqHandler struct {
	MetricReqservice             api.MetricReqApi
	MetricBarColService          api.MetricBarColApi
	MetricGaugeService           api.MetricGaugeApi
	MetricGraphMultiLineService  api.MetricGraphMultiLineApi
	MetricGraphSingleLineService api.MetricGraphSingleLineApi
	MetricTableService           api.MetricTableApi
}

func (ap *MetricReqHandler) GetMetricReq(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {

	queryValues := r.URL.Query()
	logging.Infof("params by key value graphtype %s after : %s, before : %s,  interval : %s, graph_key: %s time_range :%s ", queryValues.Get("type"), queryValues.Get("after"), queryValues.Get("before"), queryValues.Get("interval"), queryValues.Get("graph_key"), queryValues.Get("time_range"))

	// w.Header().Add("Access-Control-Allow-Origin", "*")
	// w.Header().Add("Access-Control-Allow-Methods", "POST , GET, OPTIONS, PUT, DELETE")
	// w.Header().Add("Access-Control-Allow-Headers", "Content-Type , X-Auth-Token, Origin, Authorization")
	// w.Header().Add("Content-Type", "application/json")

	//metricReq, err := ap.MetricReqservice.GetMetricReq()
	// var gr GaugeRequest
	// var unmarshalErr *json.UnmarshalTypeError

	// decoder := json.NewDecoder(r.Body)
	// decoder.DisallowUnknownFields()
	// err := decoder.Decode(&gr)
	// if err != nil {
	// 	if errors.As(err, &unmarshalErr) {
	// 		errorResponse(w, "Bad Request. Wrong Type provided for field "+unmarshalErr.Field, http.StatusBadRequest)
	// 		logging.Errorf("request json decode error %s", err)
	// 	} else {
	// 		errorResponse(w, "Bad Request "+err.Error(), http.StatusBadRequest)
	// 		logging.Errorf("request json decode error %s", err)
	// 	}
	// 	return
	// }

	// logging.Infof(gr)

	switch queryValues.Get("type") {
	case "gauge", "gauge_1", "gauge_2", "gauge_3", "gauge_4":
		//metricReq model.MetricGauge
		metricReq, err := ap.MetricGaugeService.GetMetricGauge(&queryValues)
		if err != nil {
			//w.Header().Add("Content-Type", "application/json")
			//w.WriteHeader(http.)
			logging.Errorf("error happend %s", err)
		}
		//log.Print(metricReq)
		jsonResp, err := json.Marshal(metricReq)

		//log.Print(jsonResp)
		if err != nil {
			logging.Errorf("error happend %s", err)
		}
		w.Write(jsonResp)
	case "singleLine", "single_line_1", "single_line_2":

		metricReq, err := ap.MetricGraphSingleLineService.GetMetricGraphSingleLine(&queryValues)
		if err != nil {
			//w.Header().Add("Content-Type", "application/json")
			//w.WriteHeader(http.)
			logging.Errorf("error happend %s", err)
		}
		jsonResp, err := json.Marshal(metricReq)
		if err != nil {
			logging.Errorf("error happend %s", err)
		}
		w.Write(jsonResp)
	case "multiLine", "multi_line_1", "multi_line_2":
		metricReq, err := ap.MetricGraphMultiLineService.GetMetricGraphMultiLine()
		if err != nil {
			//w.Header().Add("Content-Type", "application/json")
			//w.WriteHeader(http.)
			logging.Errorf("error happend %s", err)
		}
		jsonResp, err := json.Marshal(metricReq)
		if err != nil {
			logging.Errorf("error happend %s", err)
		}
		w.Write(jsonResp)

	case "column", "column_1":
		metricReq, err := ap.MetricBarColService.GetMetricBarCol()
		if err != nil {
			//w.Header().Add("Content-Type", "application/json")
			//w.WriteHeader(http.)
			logging.Errorf("error happend %s", err)
		}
		jsonResp, err := json.Marshal(metricReq)
		if err != nil {
			logging.Errorf("error happend %s", err)
		}
		w.Write(jsonResp)

	case "table", "table_1", "table_2", "table_3", "table_4", "app_1_name_space_1", "app_4_table_1":
		metricReq, err := ap.MetricTableService.GetMetricTable(&queryValues)
		if err != nil {
			//w.Header().Add("Content-Type", "application/json")
			//w.WriteHeader(http.)
			logging.Errorf("error happend %s", err)
		}
		jsonResp, err := json.Marshal(metricReq)
		if err != nil {
			logging.Errorf("error happend %s", err)
		}
		w.Write(jsonResp)

	default:

		metricReq, err := ap.MetricReqservice.GetMetricReq()
		if err != nil {
			//w.Header().Add("Content-Type", "application/json")
			//w.WriteHeader(http.)
			logging.Errorf("error happend %s", err)
		}
		jsonResp, err := json.Marshal(metricReq)
		if err != nil {
			logging.Errorf("error happend %s", err)
		}
		w.Write(jsonResp)
	}

	//w.Write(metricReq)

}
