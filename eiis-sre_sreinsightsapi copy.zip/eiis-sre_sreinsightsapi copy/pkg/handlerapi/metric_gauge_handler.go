package handlerapi

import (
	"encoding/json"
	"log"
	"net/http"

	"github.aexp.com/amex-eng/go-paved-road/pkg/api"
	"github.com/julienschmidt/httprouter"
)

type MetricGaugeHandler struct {
	AppCompservice api.MetricGaugeApi
}

func (ap *MetricGaugeHandler) GetMetricGauge(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {

	queryValues := r.URL.Query()
	appinfo, err := ap.AppCompservice.GetMetricGauge(&queryValues)

	if err != nil {
		//w.Header().Add("Content-Type", "application/json")
		//w.WriteHeader(http.)
		log.Fatalf("error happend %s", err)
	}

	w.Header().Add("Content-Type", "application/json")
	w.Header().Add("Access-Control-Allow-Headers", "*")
	w.Header().Add("Access-Control-Allow-Methods", "*")
	w.Header().Add("Access-Control-Allow-Origin", "*")
	//w.Write(appinfo)

	jsonResp, err := json.Marshal(appinfo)
	if err != nil {
		log.Fatalf("error happend %s", err)
	}

	w.Write(jsonResp)

}
