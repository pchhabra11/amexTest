---
name: Report a Bug
about: Create a bug report to help us improve
title: ''
labels: "bug"
assignees: ''

---

**Description**
A clear and concise description of what the bug is:

**To Reproduce**
Steps to reproduce the behavior:

**Expected behavior**
A clear and concise description of what you expected to happen.

**Version Details**
Please provide the project version information:

**Runtime Environment**
If applicable, please describe the OS, Device, Browser, etc. details:

**Screenshots AND/OR Logs**
If applicable, add screenshots or logs to help explain the problem:
Please do not add anything sensitive

**Additional context**
Add any other context about the problem here:

<!--- DO NOT REMOVE THIS LINE -->
