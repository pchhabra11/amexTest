---
name: Design Proposal
about: Propose a design or architectural change
title: ''
labels: proposal
assignees: ''

---

## Abstract

Short Description of the proposal

## Background

Introduction to the necessary background and problem statement this design proposal will solve.

## Proposal

Full proposal details, including any technical documentation, diagrams, code samples, etc.

## Trade Offs (if applicable)

Pros, Cons, what do we lose, what do we gain

<!--- DO NOT REMOVE THIS LINE -->
