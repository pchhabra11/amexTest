package main

import (
	"github.com/spf13/viper"
	"log"
	// Enable Remote Configs with Viper.
	_ "github.com/spf13/viper/remote"

	"github.aexp.com/amex-eng/go-steamroller/server"

	"github.aexp.com/amex-eng/go-paved-road/pkg/app"
	"github.aexp.com/amex-eng/go-paved-road/pkg/logging"
)

func main() {
	var err error

	// Create Config
	cfg := viper.New()

	// Set default config values
	//cfg.SetDefault("config_watch_interval", 15)
	//cfg.SetDefault("enable_metrics", true)
	//cfg.SetDefault("enable_tls", true)
	//cfg.SetDefault("listen_addr", "0.0.0.0:8443")
	//cfg.SetDefault("kvstore_healthcheck_interval", 60)
	//cfg.SetDefault("sql_healthcheck_interval", 60)

	cfg.SetConfigFile(".env")
	// Load Env and File Based Config
	//cfg.AddConfigPath("./config/" + os.Getenv("EPAAS_ENV"))
	//cfg.AddConfigPath("./config/" + os.Getenv("ENV"))
	//cfg.AutomaticEnv()
	err = cfg.ReadInConfig()
	if err != nil {
		switch err.(type) {
		case viper.ConfigFileNotFoundError:
			logging.Errorf("no config file found, loaded config from environment - %s", err)
		default:
			log.Fatalf("could not load configuration - %s", err)
		}
	}

	// Create new application server instance
	srv, err := server.New(server.Config{Config: cfg})
	if err != nil {
		log.Fatalf("could not create new server - %s", err)
	}
	defer srv.Stop()

	// Create internal app instance for handlers
	a := &app.Application{Server: srv}

	// Register Custom HTTP Handler
	srv.HTTPServer.RegisterHandler("GET", "/", a.CustomHandler)

	// Start custom application
	go a.Start()
	defer a.Shutdown()

	// Start application server
	err = srv.Start()
	if err != nil && err != server.ErrShutdown {
		log.Fatalf("server shutdown unexpectedly - %s", err)
	}
	logging.Errorf("server shutdown - %s", err)
}
